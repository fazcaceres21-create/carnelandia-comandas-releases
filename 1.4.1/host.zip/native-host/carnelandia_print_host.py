#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Carnelandia Comandas — Native Messaging host.

Método de impresión (documentado):
  macOS: genera un PDF tipográfico (Helvetica) con ReportLab si está disponible,
         o un PDF mínimo / texto UTF-8; envía a CUPS con `lp` usando SOLO el nombre
         de impresora de la configuración (nunca texto del cliente en el comando).
  Windows: usa win32print (pywin32) con WritePrinter de texto UTF-16 / Impresión GDI
           StartDoc/TextOut, o fallback a sumatra/PDF si se configura.
  Demo: guarda las copias como .txt UTF-8 en ~/CarnelandiaComandas/demo_prints/

No ejecuta shell con texto del cliente.
No cambia la impresora predeterminada del sistema.
Restringido a la extensión listada en el manifiesto Native Messaging.
"""

from __future__ import annotations

import json
import os
import platform
import struct
import subprocess
import sys
import tempfile
import traceback
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

APP_DIR = Path(__file__).resolve().parent
CONFIG_PATH = APP_DIR / "config" / "config.json"
DEMO_DIR = Path.home() / "CarnelandiaComandas" / "demo_prints"
LOG_DIR = Path.home() / "CarnelandiaComandas" / "logs"

# Protocolo extensión ↔ host. Debe alinearse con extension/shared/constants.js
HOST_VERSION = "1.4.1"
PROTOCOL_VERSION = 2
PROTOCOL_VERSION_MIN = 1
PROTOCOL_VERSION_MAX = 2

# ESC/POS full cut (GS V 0) — solo via datatype RAW; no asumir modelo sin config.
ESC_POS_FULL_CUT = bytes([0x1D, 0x56, 0x00])
ESC_POS_PARTIAL_CUT = bytes([0x1D, 0x56, 0x01])
ESC_POS_FEED_LINES = bytes([0x1B, 0x64, 0x04])  # ESC d 4


def log(msg: str) -> None:
    """Solo archivo. Nunca stdout/stderr de Native Messaging (rompe el protocolo)."""
    try:
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        with open(LOG_DIR / "host.log", "a", encoding="utf-8") as f:
            f.write(f"{datetime.now().isoformat()} {msg}\n")
    except Exception:
        try:
            fallback = APP_DIR / "logs"
            fallback.mkdir(parents=True, exist_ok=True)
            with open(fallback / "host.log", "a", encoding="utf-8") as f:
                f.write(f"{datetime.now().isoformat()} {msg}\n")
        except Exception:
            pass


def probe_windows_modules() -> Dict[str, Any]:
    """Importa uno a uno y conserva la excepcion real (no enmascarar como 'falta pywin32')."""
    names = ("pywintypes", "pythoncom", "win32api", "win32print", "win32con", "win32ui")
    out: Dict[str, Any] = {
        "executable": sys.executable,
        "version": sys.version,
        "modules": {},
    }
    for name in names:
        try:
            mod = __import__(name)
            out["modules"][name] = {
                "ok": True,
                "file": getattr(mod, "__file__", None),
                "error": None,
            }
        except Exception as exc:
            out["modules"][name] = {
                "ok": False,
                "file": None,
                "error": f"{type(exc).__name__}: {exc}",
            }
    out["win32print_ok"] = bool(out["modules"].get("win32print", {}).get("ok"))
    out["gdi_ok"] = bool(
        out["modules"].get("win32ui", {}).get("ok")
        and out["modules"].get("win32con", {}).get("ok")
    )
    return out


def log_windows_environment(tag: str = "env") -> Dict[str, Any]:
    info = probe_windows_modules()
    log(f"{tag} executable={info['executable']}")
    log(f"{tag} version={info['version']!r}")
    for name, meta in info["modules"].items():
        if meta["ok"]:
            log(f"{tag} IMPORT_OK {name} file={meta['file']}")
        else:
            log(f"{tag} IMPORT_FAIL {name} {meta['error']}")
    return info


def read_message() -> Optional[dict]:
    raw_len = sys.stdin.buffer.read(4)
    if not raw_len or len(raw_len) < 4:
        return None
    msg_len = struct.unpack("<I", raw_len)[0]
    data = sys.stdin.buffer.read(msg_len)
    if not data:
        return None
    return json.loads(data.decode("utf-8"))


def send_message(msg: dict) -> None:
    encoded = json.dumps(msg, ensure_ascii=False).encode("utf-8")
    sys.stdout.buffer.write(struct.pack("<I", len(encoded)))
    sys.stdout.buffer.write(encoded)
    sys.stdout.buffer.flush()


def load_config() -> dict:
    defaults = {
        "printerName": None,
        "paperWidthMm": 80,
        "demoModeDefault": False,
        # gdi | text_cp1252 | auto — ver docs/IMPRESION.md
        # auto: GDI si win32ui esta; si no, TEXT (win32print). Evita falso "falta pywin32".
        "windowsPrintMethod": "auto",
    }
    if CONFIG_PATH.exists():
        try:
            with open(CONFIG_PATH, encoding="utf-8") as f:
                data = json.load(f)
            defaults.update(data)
        except Exception as e:
            log(f"config read error: {e}")
    return defaults


def safe_printer_name(name: Optional[str]) -> Optional[str]:
    """Solo permitir nombres razonables de impresora del SO (sin metacaracteres shell)."""
    if not name or not isinstance(name, str):
        return None
    name = name.strip()
    if not name or len(name) > 200:
        return None
    # Bloquear caracteres peligrosos para argv/shell (usamos argv, pero defensa en profundidad)
    forbidden = set("\n\r\0;&|$`<>\"'\\")
    if any(c in forbidden for c in name):
        return None
    return name


def list_printers_macos() -> List[dict]:
    printers = []
    try:
        # lpstat -p lista impresoras; no usa input del usuario
        out = subprocess.check_output(["lpstat", "-p"], stderr=subprocess.DEVNULL, text=True)
        default = None
        try:
            d = subprocess.check_output(["lpstat", "-d"], stderr=subprocess.DEVNULL, text=True)
            if ":" in d:
                default = d.split(":", 1)[1].strip()
        except Exception:
            pass
        for line in out.splitlines():
            # printer NAME is ...
            parts = line.split()
            if len(parts) >= 2 and parts[0] == "printer":
                pname = parts[1]
                printers.append({"name": pname, "isDefault": pname == default})
    except Exception as e:
        log(f"list_printers_macos: {e}")
    return printers


def list_printers_windows() -> List[dict]:
    printers = []
    try:
        import win32print  # type: ignore

        default = win32print.GetDefaultPrinter()
        flags = win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS
        for p in win32print.EnumPrinters(flags):
            # tuple: (flags, desc, name, comment)
            name = p[2]
            printers.append({"name": name, "isDefault": name == default})
    except Exception as e:
        log(f"list_printers_windows: {e}")
    return printers


def list_printers() -> List[dict]:
    system = platform.system()
    if system == "Darwin":
        return list_printers_macos()
    if system == "Windows":
        return list_printers_windows()
    # Linux genérico (futuro / pruebas)
    return list_printers_macos()


def mm_to_points(mm: float) -> float:
    return mm * 72.0 / 25.4


def normalize_rows(copy: Any) -> List[dict]:
    """Filas estructuradas (preferidas) o texto plano como fallback."""
    if isinstance(copy, str):
        copy = {"text": copy}
    if not isinstance(copy, dict):
        copy = {"text": str(copy or "")}
    rows = copy.get("lines")
    if isinstance(rows, list) and rows:
        out = []
        for r in rows:
            if isinstance(r, dict):
                out.append(
                    {
                        "text": str(r.get("text") or ""),
                        "role": r.get("role") or "body",
                        "gapAfterMm": float(r.get("gapAfterMm") or 0.8),
                        "bold": bool(r.get("bold", True)),
                        "size": r.get("size") or "normal",
                    }
                )
            else:
                out.append(
                    {
                        "text": str(r),
                        "role": "body",
                        "gapAfterMm": 0.8,
                        "bold": True,
                        "size": "normal",
                    }
                )
        return out
    text = copy.get("text") or ""
    return [
        {
            "text": ln,
            "role": "body",
            "gapAfterMm": 1.2 if ln.strip() == "" else 0.6,
            "bold": True,
            "size": "normal",
        }
        for ln in text.split("\n")
    ]


def _font_candidates() -> List[Tuple[str, str]]:
    """(ruta, etiqueta) preferir Arial Bold / Helvetica Bold — no monoespaciada terminal."""
    if platform.system() == "Darwin":
        return [
            ("/System/Library/Fonts/Supplemental/Arial Bold.ttf", "TicketBold"),
            ("/Library/Fonts/Arial Bold.ttf", "TicketBold"),
            ("/System/Library/Fonts/Supplemental/Arial.ttf", "TicketReg"),
            ("/Library/Fonts/Arial.ttf", "TicketReg"),
        ]
    if platform.system() == "Windows":
        windir = os.environ.get("WINDIR", r"C:\Windows")
        return [
            (os.path.join(windir, "Fonts", "arialbd.ttf"), "TicketBold"),
            (os.path.join(windir, "Fonts", "arial.ttf"), "TicketReg"),
        ]
    return []


def font_size_for(size: str, width_mm: int) -> float:
    base = 13.0 if width_mm >= 80 else 11.5
    if size == "title":
        return base + 3
    if size == "large":
        return base + 1.5
    if size == "product":
        return base + 0.5
    return base


def build_pdf_reportlab(copy: dict, width_mm: int, path: Path) -> bool:
    try:
        from reportlab.lib.colors import black, white
        from reportlab.lib.units import mm
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.ttfonts import TTFont
        from reportlab.pdfgen import canvas
    except ImportError:
        return False

    rows = normalize_rows(copy)
    margin = 1.5 * mm  # márgenes mínimos
    page_w = width_mm * mm

    bold_name = "Helvetica-Bold"
    reg_name = "Helvetica"
    for fp, label in _font_candidates():
        if os.path.isfile(fp):
            try:
                pdfmetrics.registerFont(TTFont(label, fp))
                if "Bold" in fp or label.endswith("Bold"):
                    bold_name = label
                else:
                    reg_name = label
                    if bold_name == "Helvetica-Bold":
                        bold_name = label
            except Exception:
                continue

    # Altura estimada
    total_h = margin * 2
    for r in rows:
        fs = font_size_for(str(r.get("size") or "normal"), width_mm)
        total_h += fs * 1.15
        total_h += float(r.get("gapAfterMm") or 0) * mm
    page_h = max(60 * mm, total_h)

    c = canvas.Canvas(str(path), pagesize=(page_w, page_h))
    # Fondo totalmente blanco
    c.setFillColor(white)
    c.rect(0, 0, page_w, page_h, fill=1, stroke=0)
    c.setFillColor(black)

    y = page_h - margin
    usable_w = page_w - 2 * margin

    for r in rows:
        text = str(r.get("text") or "")
        fs = font_size_for(str(r.get("size") or "normal"), width_mm)
        font = bold_name if r.get("bold", True) else reg_name
        try:
            c.setFont(font, fs)
        except Exception:
            c.setFont("Helvetica-Bold", fs)
        y -= fs
        # Recorte suave si la línea es muy larga (el JS ya hace wrap)
        c.drawString(margin, y, text)
        gap = float(r.get("gapAfterMm") or 0) * mm
        y -= gap
        if y < margin + fs:
            c.showPage()
            c.setFillColor(white)
            c.rect(0, 0, page_w, page_h, fill=1, stroke=0)
            c.setFillColor(black)
            y = page_h - margin - fs

    c.save()
    return True


def build_pdf_minimal(copy: dict, width_mm: int, path: Path) -> None:
    """Fallback PDF Helvetica-Bold, fondo blanco implícito, texto negro."""

    def esc(s: str) -> str:
        out = []
        for ch in s:
            if ch in ("\\", "(", ")"):
                out.append("\\" + ch)
            else:
                try:
                    ch.encode("latin-1")
                    out.append(ch)
                except Exception:
                    out.append("?")
        return "".join(out)

    rows = normalize_rows(copy)
    font_size = 12 if width_mm >= 80 else 11
    line_h = font_size + 4
    page_w = int(mm_to_points(width_mm))
    page_h = max(200, 24 + int(sum(line_h + float(r.get("gapAfterMm") or 0) * 2.8 for r in rows)))
    content = [
        "BT",
        "/F1 {0} Tf".format(font_size),
        "0 0 0 rg",
        "8 {0} Td".format(page_h - 18),
    ]
    first = True
    for r in rows:
        safe = esc(str(r.get("text") or "")[:56])
        gap_pt = max(line_h, int(float(r.get("gapAfterMm") or 0.8) * 2.8 + font_size))
        if not first:
            content.append("0 -{0} Td".format(gap_pt))
        content.append("({0}) Tj".format(safe))
        first = False
    content.append("ET")
    stream = "\n".join(content).encode("latin-1", errors="replace")

    objects = []
    objects.append(b"1 0 obj<< /Type /Catalog /Pages 2 0 R >>endobj\n")
    objects.append(b"2 0 obj<< /Type /Pages /Kids [3 0 R] /Count 1 >>endobj\n")
    objects.append(
        "3 0 obj<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {w} {h}] /Contents 4 0 R /Resources<< /Font<< /F1 5 0 R >> >> >>endobj\n".format(
            w=page_w, h=page_h
        ).encode("ascii")
    )
    objects.append(
        b"4 0 obj<< /Length %d >>stream\n" % len(stream) + stream + b"\nendstream\nendobj\n"
    )
    objects.append(
        b"5 0 obj<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>endobj\n"
    )

    pdf = bytearray(b"%PDF-1.4\n")
    offsets = [0]
    for obj in objects:
        offsets.append(len(pdf))
        pdf.extend(obj)
    xref_pos = len(pdf)
    pdf.extend(f"xref\n0 {len(offsets)}\n".encode("ascii"))
    pdf.extend(b"0000000000 65535 f \n")
    for off in offsets[1:]:
        pdf.extend(f"{off:010d} 00000 n \n".encode("ascii"))
    pdf.extend(
        f"trailer<< /Size {len(offsets)} /Root 1 0 R >>\nstartxref\n{xref_pos}\n%%EOF\n".encode(
            "ascii"
        )
    )
    path.write_bytes(pdf)


def print_pdf_macos(pdf_path: Path, printer: str) -> Tuple[bool, str, str]:
    """Envía PDF a CUPS. outcome 'queued' — CUPS no garantiza salida física."""
    cmd = ["lp", "-d", printer, "-o", "document-format=application/pdf", str(pdf_path)]
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=60,
            check=False,
        )
        if proc.returncode != 0:
            # Reintento sin document-format por drivers antiguos
            proc = subprocess.run(
                ["lp", "-d", printer, str(pdf_path)],
                capture_output=True,
                text=True,
                timeout=60,
                check=False,
            )
        if proc.returncode != 0:
            return False, "printer_unavailable", proc.stderr.strip() or proc.stdout.strip() or "lp falló"
        return True, "queued", (proc.stdout or "").strip() or "Enviado a CUPS"
    except FileNotFoundError:
        return False, "error", "Comando lp no encontrado"
    except subprocess.TimeoutExpired:
        return False, "error", "Timeout al enviar a la cola (resultado incierto; no se reintenta)"


def print_copy_windows_gdi(copy: dict, width_mm: int, printer: str) -> Tuple[bool, str, str]:
    """
    Impresión vía GDI al spooler (nombre de impresora del SO).
    No abre puertos USB ni cambia la impresora predeterminada.
    No envía ESC/POS RAW. Outcome: queued (no confirma papel físico).
    """
    # Imports por separado: win32print puede estar OK y fallar win32ui (caso tipico).
    try:
        import win32print  # type: ignore
    except Exception as e:
        log(f"gdi import win32print FAIL: {type(e).__name__}: {e}")
        return (
            False,
            "error",
            f"No se pudo importar win32print con {sys.executable}: {type(e).__name__}: {e}",
        )
    try:
        import win32ui  # type: ignore
    except Exception as e:
        log(f"gdi import win32ui FAIL: {type(e).__name__}: {e}")
        return (
            False,
            "error",
            f"win32print OK pero fallo import win32ui: {type(e).__name__}: {e}. "
            f"Interprete: {sys.executable}. Probá windowsPrintMethod=text_cp1252 o auto, "
            f"o ejecuta: python -m pywin32_postinstall -install",
        )
    try:
        import win32con  # type: ignore
    except Exception as e:
        log(f"gdi import win32con FAIL: {type(e).__name__}: {e}")
        # Constantes minimas si solo falta win32con
        class _Con:  # type: ignore
            LOGPIXELSY = 90
            LOGPIXELSX = 88
            TRANSPARENT = 1

        win32con = _Con()  # type: ignore
        log("gdi usando constantes locales (win32con ausente)")

    try:
        hprinter = win32print.OpenPrinter(printer)
    except Exception as e:
        return (
            False,
            "printer_unavailable",
            f'No se pudo abrir la impresora "{printer}": {e}',
        )

    try:
        hdc = win32ui.CreateDC()
        hdc.CreatePrinterDC(printer)
        try:
            dpi_y = hdc.GetDeviceCaps(win32con.LOGPIXELSY) or 203
            dpi_x = hdc.GetDeviceCaps(win32con.LOGPIXELSX) or 203
        except Exception:
            dpi_y, dpi_x = 203, 203

        def mm_to_px(mm: float, dpi: int) -> int:
            return max(1, int(mm * dpi / 25.4))

        margin_x = mm_to_px(1.5, dpi_x)
        hdc.StartDoc("Carnelandia Comanda")
        hdc.StartPage()
        try:
            hdc.SetTextColor(0x000000)
            hdc.SetBkMode(win32con.TRANSPARENT)
        except Exception:
            pass

        rows = normalize_rows(copy)
        y = mm_to_px(1.5, dpi_y)
        for r in rows:
            size = str(r.get("size") or "normal")
            if size == "title":
                height = mm_to_px(5.5, dpi_y)
            elif size in ("large", "product"):
                height = mm_to_px(5.0, dpi_y)
            else:
                height = mm_to_px(4.5, dpi_y)
            if width_mm < 70:
                height = max(mm_to_px(3.8, dpi_y), height - 2)

            font = win32ui.CreateFont(
                {
                    "name": "Arial",
                    "height": height,
                    "weight": 700 if r.get("bold", True) else 400,
                    "charset": 1,
                }
            )
            hdc.SelectObject(font)
            hdc.TextOut(margin_x, y, str(r.get("text") or ""))
            gap_mm = float(r.get("gapAfterMm") or 0.8)
            y += height + mm_to_px(gap_mm, dpi_y)

        hdc.EndPage()
        hdc.EndDoc()
        hdc.DeleteDC()
        return (
            True,
            "queued",
            f'Enviado a la cola de "{printer}" (spooler GDI). No confirma salida fisica del papel.',
        )
    except Exception as e:
        log(f"gdi runtime error: {traceback.format_exc()}")
        return False, "error", f"Error GDI al imprimir: {type(e).__name__}: {e}"
    finally:
        try:
            win32print.ClosePrinter(hprinter)
        except Exception:
            pass


def _ticket_body_text(copy: dict) -> str:
    rows = normalize_rows(copy)
    lines_out: List[str] = []
    for r in rows:
        lines_out.append(str(r.get("text") or ""))
        gap = float(r.get("gapAfterMm") or 0)
        if gap >= 2.5:
            lines_out.append("")
    return "\r\n".join(lines_out) + "\r\n\r\n"


def print_copy_windows_text(
    copy: dict, width_mm: int, printer: str, encoding: str = "cp1252"
) -> Tuple[bool, str, str]:
    """
    Texto al spooler (datatype TEXT). No ESC/POS.
    encoding: cp1252 (español Windows) | utf-16le (algunos drivers Unicode).
    """
    try:
        import win32print  # type: ignore
    except Exception as e:
        log(f"text import win32print FAIL: {type(e).__name__}: {e}")
        return (
            False,
            "error",
            f"No se pudo importar win32print con {sys.executable}: {type(e).__name__}: {e}",
        )

    body = _ticket_body_text(copy)
    enc = (encoding or "cp1252").lower().strip()
    try:
        if enc in ("utf-16le", "utf16le", "utf-16"):
            payload = body.encode("utf-16le")  # sin BOM; muchos drivers TEXT lo aceptan
            enc_label = "utf-16le"
        else:
            payload = body.encode("cp1252", errors="replace")
            enc_label = "cp1252"
    except Exception as e:
        return False, "error", f"No se pudo codificar {enc}: {e}"

    try:
        hprinter = win32print.OpenPrinter(printer)
    except Exception as e:
        return (
            False,
            "printer_unavailable",
            f'No se pudo abrir la impresora "{printer}": {e}',
        )

    try:
        job_info = ("Carnelandia Comanda", None, "TEXT")
        win32print.StartDocPrinter(hprinter, 1, job_info)
        try:
            win32print.StartPagePrinter(hprinter)
            win32print.WritePrinter(hprinter, payload)
            win32print.EndPagePrinter(hprinter)
        finally:
            win32print.EndDocPrinter(hprinter)
        return (
            True,
            "queued",
            f'Enviado como texto {enc_label} a la cola de "{printer}". '
            f"No confirma papel fisico. Acentos: cp1252 cubre ñ/tildes latinas; "
            f"si salen mal, el driver Generic/Text Only limita el mapa de caracteres.",
        )
    except Exception as e:
        log(f"text WritePrinter error enc={enc_label}: {e}")
        return False, "error", f"Error TEXT/{enc_label}: {e}"
    finally:
        try:
            win32print.ClosePrinter(hprinter)
        except Exception:
            pass


def print_copy_windows_text_cp1252(
    copy: dict, width_mm: int, printer: str
) -> Tuple[bool, str, str]:
    return print_copy_windows_text(copy, width_mm, printer, encoding="cp1252")


def print_copy_windows(
    copy: dict, width_mm: int, printer: str, method: str = "auto"
) -> Tuple[bool, str, str]:
    method = (method or "auto").lower().strip()
    env = log_windows_environment("print")
    log(f"print method_requested={method} printer={printer!r} width={width_mm}")

    if method in ("text_cp1252", "text"):
        return print_copy_windows_text(copy, width_mm, printer, encoding="cp1252")
    if method == "text_utf16":
        return print_copy_windows_text(copy, width_mm, printer, encoding="utf-16le")

    if method == "gdi":
        ok, outcome, info = print_copy_windows_gdi(copy, width_mm, printer)
        if ok:
            return ok, outcome, info
        if env.get("win32print_ok"):
            log(f"GDI no disponible ({info}); degradacion automatica a text cp1252")
            return print_copy_windows_text(copy, width_mm, printer, encoding="cp1252")
        return ok, outcome, info

    # auto: GDI (Unicode tipografico) -> TEXT cp1252 -> TEXT utf-16le
    if env.get("gdi_ok"):
        ok, outcome, info = print_copy_windows_gdi(copy, width_mm, printer)
        if ok:
            return ok, outcome, info
        log(f"GDI fallo en runtime ({info}); intento text cp1252")
    else:
        log("GDI deps ausentes; uso text cp1252")

    ok, outcome, info = print_copy_windows_text(copy, width_mm, printer, encoding="cp1252")
    if ok:
        return ok, outcome, info
    log(f"text cp1252 fallo ({info}); intento utf-16le")
    return print_copy_windows_text(copy, width_mm, printer, encoding="utf-16le")


def build_accent_test_copy(width_mm: int = 80) -> dict:
    """Copia de prueba con tildes/Ñ — no usa texto de clientes."""
    lines = [
        {"text": "CARNELANDIA", "role": "brand", "gapAfterMm": 0.5, "bold": True, "size": "title"},
        {"text": "PRUEBA DE COLA", "role": "brand", "gapAfterMm": 1, "bold": True, "size": "large"},
        {"text": "ÑOQUIS / JALAPEÑO / MARÍA", "role": "product", "gapAfterMm": 3, "bold": True, "size": "product"},
        {"text": "DIRECCIÓN: SAN MARTÍN 1250", "role": "address", "gapAfterMm": 2, "bold": True, "size": "large"},
        {"text": "1 KG DE VACÍO", "role": "product", "gapAfterMm": 3, "bold": True, "size": "product"},
        {"text": "NO CONFIRMA PAPEL FISICO", "role": "footer", "gapAfterMm": 2, "bold": True, "size": "normal"},
    ]
    text = "\n".join(r["text"] for r in lines) + "\n"
    return {
        "copyType": "PREPARACIÓN",
        "text": text,
        "lines": lines,
        "widthMm": width_mm,
    }


def send_cut_windows(printer: str, cut_mode: str = "escpos_full") -> Tuple[bool, str]:
    """
    Envia avance de papel y/o corte. Preferir RAW ESC/POS si el driver lo acepta.
    Generic/Text Only a veces ignora RAW: entonces form-feed / saltos.
    No cambia impresora predeterminada.
    """
    mode = (cut_mode or "escpos_full").lower().strip()
    try:
        import win32print  # type: ignore
    except Exception as e:
        return False, f"win32print: {e}"

    payload = b""
    if mode in ("escpos_full", "escpos", "full"):
        payload = ESC_POS_FEED_LINES + ESC_POS_FULL_CUT
        dtype = "RAW"
    elif mode in ("escpos_partial", "partial"):
        payload = ESC_POS_FEED_LINES + ESC_POS_PARTIAL_CUT
        dtype = "RAW"
    elif mode in ("formfeed", "ff"):
        payload = b"\n\n\n\n\x0c"
        dtype = "TEXT"
    elif mode in ("feed", "none_feed"):
        payload = b"\r\n\r\n\r\n\r\n"
        dtype = "TEXT"
    else:
        payload = ESC_POS_FEED_LINES + ESC_POS_FULL_CUT
        dtype = "RAW"

    try:
        h = win32print.OpenPrinter(printer)
    except Exception as e:
        return False, f"OpenPrinter cut: {e}"
    try:
        win32print.StartDocPrinter(h, 1, ("Carnelandia Cut", None, dtype))
        try:
            win32print.StartPagePrinter(h)
            win32print.WritePrinter(h, payload)
            win32print.EndPagePrinter(h)
        finally:
            win32print.EndDocPrinter(h)
        return True, f"cut queued mode={mode} dtype={dtype}"
    except Exception as e:
        # Fallback feed TEXT si RAW falla
        if dtype == "RAW":
            try:
                win32print.StartDocPrinter(h, 1, ("Carnelandia Feed", None, "TEXT"))
                try:
                    win32print.StartPagePrinter(h)
                    win32print.WritePrinter(h, b"\r\n\r\n\r\n\r\n\r\n")
                    win32print.EndPagePrinter(h)
                finally:
                    win32print.EndDocPrinter(h)
                return True, f"RAW cut fallo ({e}); feed TEXT enviado"
            except Exception as e2:
                return False, f"cut/feed fallo: {e} / {e2}"
        return False, f"cut fallo: {e}"
    finally:
        try:
            win32print.ClosePrinter(h)
        except Exception:
            pass


def _py_upper(s: str) -> str:
    try:
        return str(s or "").upper()
    except Exception:
        return str(s or "")


def build_print_job_from_messages(
    messages: list,
    ticket_number: Optional[str] = None,
    paper_width_mm: int = 80,
    contact_name: str = "",
    order_id: str = "",
    is_reprint: bool = False,
) -> dict:
    """Construye 2 copias (PREPARACION + CONTROL) en el host para el agente HTTP."""
    width = 32 if paper_width_mm == 58 else 48
    # Usar ancho tipografico grande del proyecto
    width = 24 if paper_width_mm == 58 else 32
    num = ticket_number or "0001"
    body_lines = []
    for m in messages or []:
        t = _py_upper(m.get("text") if isinstance(m, dict) else m)
        if t:
            body_lines.append(t)
            body_lines.append("")

    def one_copy(copy_type: str) -> dict:
        lines_struct = []
        header = [
            ("CARNELANDIA", "title"),
            ("COMANDA", "title"),
            (_py_upper(copy_type), "large"),
            (f"Nº {num}", "large"),
        ]
        if is_reprint:
            header.insert(2, ("*** REIMPRESIÓN ***", "large"))
        if contact_name:
            header.append((f"CHAT: {_py_upper(contact_name)}", "normal"))
        if order_id:
            header.append((f"PEDIDO: {_py_upper(order_id)}", "normal"))
        for text, size in header:
            lines_struct.append(
                {
                    "text": text.center(width) if size in ("title", "large") else text,
                    "role": "meta",
                    "gapAfterMm": 1,
                    "bold": True,
                    "size": size,
                }
            )
        for bl in body_lines:
            if not bl:
                continue
            # wrap simple
            rest = bl
            while len(rest) > width:
                lines_struct.append(
                    {
                        "text": rest[:width],
                        "role": "product",
                        "gapAfterMm": 0,
                        "bold": True,
                        "size": "product",
                    }
                )
                rest = rest[width:]
            lines_struct.append(
                {
                    "text": rest,
                    "role": "product",
                    "gapAfterMm": 3,
                    "bold": True,
                    "size": "product",
                }
            )
        for footer in (
            "PREPARÓ: _______________",
            "PESOS REALES:",
            "_________________________",
            "FIN COMANDA",
        ):
            lines_struct.append(
                {
                    "text": footer,
                    "role": "footer",
                    "gapAfterMm": 1.5,
                    "bold": True,
                    "size": "normal",
                }
            )
        text = "\n".join(x["text"] for x in lines_struct) + "\n"
        return {
            "copyType": copy_type,
            "text": text,
            "lines": lines_struct,
            "widthMm": paper_width_mm,
            "ticketNumber": num,
        }

    return {
        "ticketNumber": num,
        "paperWidthMm": paper_width_mm,
        "copies": [
            one_copy("PREPARACIÓN"),
            one_copy("CONTROL DE CAJA"),
        ],
        "orderId": order_id,
    }


def handle_self_check(config: dict) -> dict:
    """Chequeo interno del host (sin imprimir). Resultado en JSON + log archivo."""
    system = platform.system()
    result: Dict[str, Any] = {
        "ok": True,
        "action": "self_check",
        "protocolVersion": PROTOCOL_VERSION,
        "version": HOST_VERSION,
        "platform": system,
        "executable": sys.executable,
        "checks": {},
    }
    if system != "Windows":
        result["checks"]["windows"] = {"ok": False, "detail": f"SO={system}"}
        result["ok"] = False
        result["message"] = "self_check pensado para Windows de caja"
        log(f"self_check non-windows: {system}")
        return result

    env = log_windows_environment("self_check")
    result["checks"]["win32print"] = {
        "ok": env.get("win32print_ok"),
        "detail": env["modules"].get("win32print"),
    }
    result["checks"]["gdi"] = {
        "ok": env.get("gdi_ok"),
        "detail": {
            "win32ui": env["modules"].get("win32ui"),
            "win32con": env["modules"].get("win32con"),
        },
    }
    printers = list_printers_windows()
    result["checks"]["printers"] = {
        "ok": True,
        "count": len(printers),
        "names": [p.get("name") for p in printers],
    }
    cfg_name = safe_printer_name(config.get("printerName"))
    names = {p.get("name") for p in printers}
    result["checks"]["configured_printer"] = {
        "ok": bool(cfg_name and cfg_name in names) if names else bool(cfg_name),
        "configured": cfg_name,
        "present_in_system": (cfg_name in names) if cfg_name else False,
    }
    if not env.get("win32print_ok"):
        result["ok"] = False
        result["message"] = "win32print no importa con este interprete"
    elif cfg_name and names and cfg_name not in names:
        result["ok"] = False
        result["message"] = f'Impresora configurada "{cfg_name}" no esta en el sistema'
    else:
        path = "gdi+text" if env.get("gdi_ok") else "text_only"
        result["message"] = f"self_check OK — ruta={path} executable={sys.executable}"
        result["printPath"] = path
    log(f"self_check result ok={result['ok']} msg={result.get('message')}")
    return result


def handle_test_print(msg: dict, config: dict) -> dict:
    """
    Envia UNA copia de prueba a la cola. Outcome queued != papel fisico.
    No reintenta automaticamente.
    """
    if platform.system() != "Windows":
        return {
            "ok": False,
            "code": "error",
            "message": "test_print solo en Windows",
            "protocolVersion": PROTOCOL_VERSION,
        }
    printer = safe_printer_name(msg.get("printerName") or config.get("printerName"))
    if not printer:
        return {
            "ok": False,
            "code": "printer_unavailable",
            "message": "Sin impresora para prueba",
            "protocolVersion": PROTOCOL_VERSION,
        }
    width = int(msg.get("paperWidthMm") or config.get("paperWidthMm") or 80)
    method = str(msg.get("windowsPrintMethod") or config.get("windowsPrintMethod") or "auto")
    copy = build_accent_test_copy(width)
    log(f"test_print start printer={printer!r} method={method}")
    ok, outcome, info = print_copy_windows(copy, width, printer, method=method)
    # Una sola vez: no reintentar si outcome incierto
    if not ok:
        log(f"test_print FAIL: {info}")
        return {
            "ok": False,
            "code": outcome if outcome != "queued" else "error",
            "message": info,
            "outcome": outcome,
            "protocolVersion": PROTOCOL_VERSION,
        }
    log(f"test_print queued: {info}")
    return {
        "ok": True,
        "outcome": "queued",
        "message": info + " (prueba: 1 copia, no es confirmacion fisica)",
        "protocolVersion": PROTOCOL_VERSION,
        "testPrint": True,
    }


def save_demo(copies: List[dict], ticket_number: str) -> Path:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    name = f"ticket_{ticket_number}_{stamp}.txt"
    parts = []
    for c in copies:
        parts.append(f"===== {c.get('copyType', '')} =====\n")
        parts.append(c.get("text", ""))
        parts.append("\n\n")
    body = "".join(parts)
    candidates = [DEMO_DIR, APP_DIR / "demo_prints", Path(tempfile.gettempdir()) / "CarnelandiaComandas"]
    last_err: Optional[Exception] = None
    for base in candidates:
        try:
            base.mkdir(parents=True, exist_ok=True)
            path = base / name
            path.write_text(body, encoding="utf-8")
            return path
        except Exception as e:
            last_err = e
            continue
    raise RuntimeError(f"No se pudo guardar demo: {last_err}")


def check_protocol(msg: dict) -> Optional[dict]:
    """Si la extensión envía protocolVersion incompatible, error claro."""
    if "protocolVersion" not in msg:
        return None  # hosts antiguos / self-test local
    try:
        v = int(msg.get("protocolVersion"))
    except (TypeError, ValueError):
        return {
            "ok": False,
            "code": "protocol_mismatch",
            "message": "protocolVersion inválido",
            "protocolVersion": PROTOCOL_VERSION,
        }
    if v < PROTOCOL_VERSION_MIN or v > PROTOCOL_VERSION_MAX:
        return {
            "ok": False,
            "code": "protocol_mismatch",
            "message": (
                f"Protocolo incompatible: la extensión envió {v}, "
                f"este componente admite {PROTOCOL_VERSION_MIN}–{PROTOCOL_VERSION_MAX}. "
                "Actualizar la extensión NO actualiza el componente nativo."
            ),
            "protocolVersion": PROTOCOL_VERSION,
        }
    return None


def handle_print(msg: dict, config: dict) -> dict:
    copies = msg.get("copies") or []
    if not copies:
        return {"ok": False, "code": "error", "message": "Sin copias", "protocolVersion": PROTOCOL_VERSION}

    demo = bool(msg.get("demoMode", config.get("demoModeDefault", True)))
    width = int(msg.get("paperWidthMm") or config.get("paperWidthMm") or 80)
    if width not in (58, 80):
        width = 80

    printer = safe_printer_name(msg.get("printerName") or config.get("printerName"))

    if demo:
        path = save_demo(copies, str(msg.get("ticketNumber") or "0000"))
        # También generar PDF demo (sin enviar a impresora) para revisar tipografía
        demo_pdf_dir = DEMO_DIR / "pdf"
        demo_pdf_dir.mkdir(parents=True, exist_ok=True)
        pdf_paths = []
        for i, copy in enumerate(copies):
            pdf_path = demo_pdf_dir / f"ticket_{msg.get('ticketNumber')}_{i+1}.pdf"
            if not build_pdf_reportlab(copy, width, pdf_path):
                build_pdf_minimal(copy, width, pdf_path)
            pdf_paths.append(str(pdf_path))
        log(f"demo saved {path} pdfs={pdf_paths}")
        return {
            "ok": True,
            "outcome": "demo_saved",
            "message": f"Demo guardado en {path}",
            "path": str(path),
            "pdfPaths": pdf_paths,
            "protocolVersion": PROTOCOL_VERSION,
        }

    if not printer:
        return {
            "ok": False,
            "code": "printer_unavailable",
            "message": "No hay impresora configurada. Seleccionála una vez en el popup.",
            "protocolVersion": PROTOCOL_VERSION,
        }

    known = {p["name"] for p in list_printers()}
    if known and printer not in known:
        return {
            "ok": False,
            "code": "printer_unavailable",
            "message": f'Impresora "{printer}" no encontrada en el sistema.',
            "protocolVersion": PROTOCOL_VERSION,
        }

    system = platform.system()
    results = []

    for copy in copies:
        # Nunca pasar texto del cliente a shell: solo archivo / API
        if system == "Darwin":
            with tempfile.TemporaryDirectory() as td:
                pdf_path = Path(td) / "ticket.pdf"
                if not build_pdf_reportlab(copy, width, pdf_path):
                    build_pdf_minimal(copy, width, pdf_path)
                ok, outcome, info = print_pdf_macos(pdf_path, printer)
                results.append((ok, outcome, info))
                if not ok:
                    break
        elif system == "Windows":
            method = str(
                msg.get("windowsPrintMethod")
                or config.get("windowsPrintMethod")
                or "auto"
            )
            ok, outcome, info = print_copy_windows(copy, width, printer, method=method)
            results.append((ok, outcome, info))
            if not ok:
                break
            # Avance + corte entre copias y despues de la ultima (configurable)
            do_cut = bool(
                msg.get("cutBetweenCopies", config.get("cutBetweenCopies", True))
            )
            if do_cut:
                cut_mode = str(msg.get("cutMode") or config.get("cutMode") or "escpos_full")
                cok, cinfo = send_cut_windows(printer, cut_mode)
                log(f"cut after copy ok={cok} mode={cut_mode} info={cinfo}")
                if not cok and cut_mode.startswith("escpos"):
                    # No marcar fallo de comanda por corte; registrar aviso
                    results.append((True, "queued", f"aviso corte: {cinfo}"))
        else:
            return {
                "ok": False,
                "code": "error",
                "message": f"SO no soportado aún: {system}",
                "protocolVersion": PROTOCOL_VERSION,
            }

    if not results or not results[-1][0]:
        ok, outcome, info = results[-1] if results else (False, "error", "Sin resultado")
        return {
            "ok": False,
            "code": outcome if outcome != "queued" else "error",
            "message": info,
            "protocolVersion": PROTOCOL_VERSION,
        }

    return {
        "ok": True,
        "outcome": "queued",
        "message": results[-1][2],
        "copiesSent": len(results),
        "protocolVersion": PROTOCOL_VERSION,
    }


def handle(msg: dict) -> dict:
    config = load_config()
    mismatch = check_protocol(msg)
    if mismatch and msg.get("action") != "ping":
        # En ping devolvemos ok con protocolVersion para que la extensión compare
        return mismatch
    action = msg.get("action")
    if action == "ping":
        return {
            "ok": True,
            "message": "Carnelandia host activo",
            "platform": platform.system(),
            "version": HOST_VERSION,
            "protocolVersion": PROTOCOL_VERSION,
            "executable": sys.executable,
        }
    if action == "list_printers":
        return {"ok": True, "printers": list_printers(), "protocolVersion": PROTOCOL_VERSION}
    if action == "self_check":
        return handle_self_check(config)
    if action == "test_print":
        if mismatch:
            return mismatch
        return handle_test_print(msg, config)
    if action == "check_updates":
        try:
            from carnelandia_updater import check_for_updates  # type: ignore

            return check_for_updates(config, apply=bool(msg.get("apply")))
        except Exception as e:
            return {
                "ok": False,
                "code": "error",
                "message": f"Actualizador no disponible: {e}",
                "protocolVersion": PROTOCOL_VERSION,
                "hostVersion": HOST_VERSION,
            }
    if action == "print":
        if mismatch:
            return mismatch
        return handle_print(msg, config)
    return {"ok": False, "code": "error", "message": f"Acción desconocida: {action}"}


def main() -> int:
    log("host start")
    while True:
        try:
            msg = read_message()
            if msg is None:
                break
            log(f"action={msg.get('action')}")
            send_message(handle(msg))
        except Exception as e:
            log(traceback.format_exc())
            try:
                send_message({"ok": False, "code": "error", "message": str(e)})
            except Exception:
                break
    return 0


if __name__ == "__main__":
    # Modo CLI para pruebas sin Chrome
    if len(sys.argv) > 1 and sys.argv[1] == "--self-test":
        cfg = load_config()
        sample = {
            "action": "print",
            "demoMode": True,
            "ticketNumber": "0099",
            "paperWidthMm": 80,
            "copies": [
                {
                    "copyType": "PREPARACIÓN",
                    "text": "CARNELANDIA\nVacío 1kg\nDirección: San Martín 1250\nÑandú / jalapeño\n",
                },
                {
                    "copyType": "CONTROL DE CAJA",
                    "text": "CARNELANDIA\nCONTROL\n",
                },
            ],
        }
        print(json.dumps(handle(sample), ensure_ascii=False, indent=2))
        print(json.dumps(handle({"action": "ping"}), ensure_ascii=False, indent=2))
        print(json.dumps({"printers": list_printers()}, ensure_ascii=False, indent=2))
        sys.exit(0)
    sys.exit(main())
