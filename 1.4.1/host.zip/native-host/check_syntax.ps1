﻿#Requires -Version 5.1
# Comprueba sintaxis de install_windows.ps1 SIN ejecutar la instalacion.
# Uso: powershell -NoProfile -ExecutionPolicy Bypass -File .\check_syntax.ps1

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Target = Join-Path $Root "install_windows.ps1"

Write-Host ("Analizando: " + $Target)

if (-not (Test-Path -LiteralPath $Target)) {
  Write-Host "ERROR: no existe install_windows.ps1" -ForegroundColor Red
  exit 1
}

$tokens = $null
$errors = $null
$ast = [System.Management.Automation.Language.Parser]::ParseFile(
  $Target,
  [ref]$tokens,
  [ref]$errors
)

if ($null -eq $errors -or $errors.Count -eq 0) {
  Write-Host "OK: sintaxis valida para Windows PowerShell (Parser)." -ForegroundColor Green
  exit 0
}

Write-Host ("ERROR: " + $errors.Count + " problema(s) de analisis:") -ForegroundColor Red
foreach ($e in $errors) {
  $line = $e.Extent.StartLineNumber
  $col = $e.Extent.StartColumnNumber
  Write-Host ("  Linea " + $line + ", col " + $col + ": " + $e.Message) -ForegroundColor Red
}
exit 1
