#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Actualizador del componente nativo + carpeta extension empaquetada.

- Descarga un manifiesto HTTPS con version, urls y SHA-256.
- Verifica integridad antes de reemplazar.
- Conserva config/config.json (impresora, cutMode, etc.).
- No aplica si el agente reporta impresión en curso.
- Guarda respaldo recuperable en ~/CarnelandiaComandas/backups/

La extensión cargada como «descomprimida» NO se auto-actualiza por Chrome:
tras reemplazar archivos hace falta Recargar en chrome://extensions
(o publicar en Chrome Web Store). Este script NO promete hot-reload de MV3.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import sys
import tempfile
import traceback
import urllib.request
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

APP_DIR = Path(__file__).resolve().parent
DATA_DIR = Path.home() / "CarnelandiaComandas"
BACKUP_DIR = DATA_DIR / "backups"
CHANNEL_FILE = DATA_DIR / "update_channel.txt"
STATE_FILE = DATA_DIR / "update_state.json"
QUEUE_PATH = DATA_DIR / "queue" / "state.json"

# Clave: el canal debe ser HTTPS. Ejemplo:
# https://ejemplo.com/carnelandia/update-manifest.json


def _log(msg: str) -> None:
    try:
        log = DATA_DIR / "logs" / "updater.log"
        log.parent.mkdir(parents=True, exist_ok=True)
        with open(log, "a", encoding="utf-8") as f:
            f.write(f"{datetime.now().isoformat()} {msg}\n")
    except Exception:
        pass


def channel_url(config: Optional[dict] = None) -> str:
    if config and config.get("updateChannelUrl"):
        return str(config["updateChannelUrl"]).strip()
    if CHANNEL_FILE.is_file():
        return CHANNEL_FILE.read_text(encoding="utf-8").strip()
    return ""


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def printing_in_progress() -> bool:
    try:
        if QUEUE_PATH.is_file():
            data = json.loads(QUEUE_PATH.read_text(encoding="utf-8"))
            # El agente guarda printing solo en memoria; usamos uncertain/pending
            # y un flag opcional. También consultamos health del agente.
        import urllib.request

        req = urllib.request.Request(
            "http://127.0.0.1:17355/v1/status", method="GET"
        )
        with urllib.request.urlopen(req, timeout=2) as resp:
            st = json.loads(resp.read().decode("utf-8"))
            if st.get("printing"):
                return True
    except Exception:
        pass
    return False


def fetch_manifest(url: str) -> Dict[str, Any]:
    if not url.startswith("https://") and not url.startswith("http://127.0.0.1"):
        raise ValueError("El canal debe ser HTTPS (o http://127.0.0.1 para pruebas)")
    req = urllib.request.Request(url, headers={"User-Agent": "CarnelandiaUpdater/1.4"})
    with urllib.request.urlopen(req, timeout=30) as resp:
        raw = resp.read()
    data = json.loads(raw.decode("utf-8"))
    if not isinstance(data, dict) or "version" not in data:
        raise ValueError("Manifiesto inválido")
    return data


def download_verify(url: str, expected_sha256: str, dest: Path) -> None:
    req = urllib.request.Request(url, headers={"User-Agent": "CarnelandiaUpdater/1.4"})
    with urllib.request.urlopen(req, timeout=120) as resp:
        data = resp.read()
    got = hashlib.sha256(data).hexdigest().lower()
    exp = (expected_sha256 or "").lower().strip()
    if not exp or got != exp:
        raise ValueError(f"SHA-256 no coincide: esperado {exp}, obtenido {got}")
    dest.write_bytes(data)


def backup_tree(src: Path, label: str) -> Path:
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    dest = BACKUP_DIR / f"{label}_{stamp}"
    if src.is_dir():
        shutil.copytree(src, dest)
    else:
        dest.mkdir(parents=True)
        shutil.copy2(src, dest / src.name)
    return dest


def preserve_and_extract_host(zip_path: Path, host_root: Path) -> Dict[str, Any]:
    config_path = host_root / "config" / "config.json"
    old_config = None
    if config_path.is_file():
        old_config = config_path.read_text(encoding="utf-8")

    bak = backup_tree(host_root, "host_pre_update")
    with tempfile.TemporaryDirectory() as td:
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(td)
        td_path = Path(td)
        # Buscar carpeta native-host dentro del zip
        candidates = list(td_path.rglob("carnelandia_print_host.py"))
        if not candidates:
            raise ValueError("El zip no contiene carnelandia_print_host.py")
        new_host = candidates[0].parent
        # Copiar archivos .py / bat / requirements; no borrar nm-manifest ni config
        for item in new_host.iterdir():
            if item.name == "config":
                continue
            if item.name == "nm-manifest":
                continue
            target = host_root / item.name
            if item.is_dir():
                if target.exists():
                    shutil.rmtree(target)
                shutil.copytree(item, target)
            else:
                shutil.copy2(item, target)

    if old_config:
        config_path.parent.mkdir(parents=True, exist_ok=True)
        config_path.write_text(old_config, encoding="utf-8")

    return {"backup": str(bak), "configPreserved": bool(old_config)}


def apply_extension_zip(zip_path: Path, extension_root: Path) -> Dict[str, Any]:
    bak = backup_tree(extension_root, "extension_pre_update")
    with tempfile.TemporaryDirectory() as td:
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(td)
        td_path = Path(td)
        candidates = list(td_path.rglob("manifest.json"))
        if not candidates:
            raise ValueError("Zip de extensión sin manifest.json")
        new_ext = candidates[0].parent
        for item in new_ext.iterdir():
            target = extension_root / item.name
            if item.is_dir():
                if target.exists():
                    shutil.rmtree(target)
                shutil.copytree(item, target)
            else:
                shutil.copy2(item, target)
    return {
        "backup": str(bak),
        "needsChromeReload": True,
        "message": "Archivos de extensión reemplazados. Abrí chrome://extensions y pulsá Recargar. Chrome NO auto-actualiza extensiones en modo desarrollador.",
    }


def check_for_updates(config: dict, apply: bool = False) -> dict:
    from carnelandia_print_host import HOST_VERSION, PROTOCOL_VERSION

    url = channel_url(config)
    if not url:
        return {
            "ok": True,
            "updateAvailable": False,
            "message": "Sin canal de actualización configurado. Escribí la URL HTTPS en config.updateChannelUrl o en %USERPROFILE%\\CarnelandiaComandas\\update_channel.txt",
            "hostVersion": HOST_VERSION,
            "protocolVersion": PROTOCOL_VERSION,
        }
    try:
        manifest = fetch_manifest(url)
    except Exception as e:
        return {
            "ok": False,
            "code": "error",
            "message": f"No se pudo leer el manifiesto: {e}",
            "hostVersion": HOST_VERSION,
            "protocolVersion": PROTOCOL_VERSION,
        }

    remote_ver = str(manifest.get("version") or "")
    available = remote_ver != HOST_VERSION
    result = {
        "ok": True,
        "updateAvailable": available,
        "remoteVersion": remote_ver,
        "hostVersion": HOST_VERSION,
        "protocolVersion": PROTOCOL_VERSION,
        "remoteProtocolVersion": manifest.get("protocolVersion"),
        "releaseNotes": manifest.get("notes") or "",
        "extensionUpdate": bool(manifest.get("extensionZipUrl")),
        "needsChromeReload": False,
        "message": (
            f"Hay versión {remote_ver} (local {HOST_VERSION})"
            if available
            else f"Host al día ({HOST_VERSION})"
        ),
    }
    if not apply or not available:
        return result

    if printing_in_progress():
        result["ok"] = False
        result["code"] = "busy"
        result["message"] = "Impresión en curso: la actualización se pospuso."
        return result

    try:
        host_url = manifest.get("hostZipUrl")
        host_sha = manifest.get("hostZipSha256")
        if not host_url or not host_sha:
            raise ValueError("Manifiesto sin hostZipUrl/hostZipSha256")
        with tempfile.TemporaryDirectory() as td:
            zpath = Path(td) / "host.zip"
            download_verify(host_url, host_sha, zpath)
            info = preserve_and_extract_host(zpath, APP_DIR)
            result["hostApplied"] = info
            result["message"] = (
                f"Host actualizado a {remote_ver}. Reiniciá el agente (start_agent.bat). "
                "Chrome puede seguir usando Native Messaging; si falla, reiniciá Chrome."
            )

            ext_url = manifest.get("extensionZipUrl")
            ext_sha = manifest.get("extensionZipSha256")
            ext_root = APP_DIR.parent / "extension"
            if ext_url and ext_sha and ext_root.is_dir():
                ez = Path(td) / "ext.zip"
                download_verify(ext_url, ext_sha, ez)
                einfo = apply_extension_zip(ez, ext_root)
                result["extensionApplied"] = einfo
                result["needsChromeReload"] = True
                result["message"] += " " + einfo["message"]

        STATE_FILE.write_text(
            json.dumps(
                {
                    "lastApplied": remote_ver,
                    "at": datetime.now().isoformat(),
                    "manifestUrl": url,
                },
                indent=2,
            ),
            encoding="utf-8",
        )
    except Exception as e:
        _log(traceback.format_exc())
        result["ok"] = False
        result["code"] = "error"
        result["message"] = f"Fallo al aplicar actualización: {e}. Usá el respaldo en {BACKUP_DIR}"
    return result


def main() -> int:
    import argparse

    # Allow import host
    sys.path.insert(0, str(APP_DIR))
    parser = argparse.ArgumentParser(description="Carnelandia updater")
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--channel", default="")
    args = parser.parse_args()
    config = {}
    cfg = APP_DIR / "config" / "config.json"
    if cfg.is_file():
        config = json.loads(cfg.read_text(encoding="utf-8"))
    if args.channel:
        CHANNEL_FILE.parent.mkdir(parents=True, exist_ok=True)
        CHANNEL_FILE.write_text(args.channel.strip(), encoding="utf-8")
        config["updateChannelUrl"] = args.channel.strip()
    out = check_for_updates(config, apply=bool(args.apply))
    print(json.dumps(out, ensure_ascii=False, indent=2))
    return 0 if out.get("ok") else 1


if __name__ == "__main__":
    sys.exit(main())
