@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo Carnelandia - diagnostico de impresion
echo No envia trabajos a la impresora.
echo.

if exist "%~dp0carnelandia_print_host_windows.bat" (
  echo Usando el mismo lanzador que Chrome Native Messaging...
  for /f "usebackq tokens=*" %%A in (`findstr /i /c:"python" "%~dp0carnelandia_print_host_windows.bat"`) do (
    echo Linea wrapper: %%A
  )
)

REM Preferir el python del wrapper si se puede extraer; si no, py -3 / python
set "PYEXE="
where py >nul 2>&1
if not errorlevel 1 (
  for /f "delims=" %%P in ('py -3 "%~dp0print_python_exe.py" 2^>nul') do set "PYEXE=%%P"
)
if not defined PYEXE (
  where python >nul 2>&1
  if not errorlevel 1 (
    for /f "delims=" %%P in ('python "%~dp0print_python_exe.py" 2^>nul') do set "PYEXE=%%P"
  )
)

if not defined PYEXE (
  echo ERROR: no se encontro Python.
  pause
  exit /b 1
)

echo Interprete: %PYEXE%
echo.
"%PYEXE%" "%~dp0diagnose_print_path.py"
set ERR=%ERRORLEVEL%
echo.
echo Revisá el TXT en %%USERPROFILE%%\CarnelandiaComandas\logs\
echo Tambien host.log si ya imprimiste desde Chrome.
pause
exit /b %ERR%
