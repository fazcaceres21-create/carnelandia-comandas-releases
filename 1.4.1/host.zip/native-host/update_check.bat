@echo off
cd /d "%~dp0"
echo Carnelandia - consultar actualizaciones (sin aplicar)
where py >nul 2>&1
if %ERRORLEVEL%==0 (
  py -3 carnelandia_updater.py --check
  goto :done
)
python carnelandia_updater.py --check
:done
echo.
echo Para aplicar (si no hay impresion en curso): update_apply.bat
pause
