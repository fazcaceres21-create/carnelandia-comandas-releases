#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Diagnostico de doble clic: escribe un TXT con el mismo interprete del host.
NO envia trabajos a la impresora. NO escribe el informe a stdout de Native Messaging.
"""
from __future__ import print_function

import os
import sys
import traceback
from datetime import datetime


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    out_dirs = [
        os.path.join(os.path.expanduser("~"), "CarnelandiaComandas", "logs"),
        os.path.join(here, "logs"),
        os.environ.get("TEMP") or os.environ.get("TMP") or here,
    ]

    lines = []
    lines.append("Carnelandia Comandas - diagnostico de impresion")
    lines.append("fecha=%s" % (datetime.now().isoformat(),))
    lines.append("script=%s" % (os.path.abspath(__file__),))
    lines.append("sys.executable=%s" % (sys.executable,))
    lines.append("sys.version=%s" % (sys.version.replace("\n", " "),))
    lines.append("cwd=%s" % (os.getcwd(),))
    lines.append("sys.path:")
    for p in sys.path:
        lines.append("  %s" % (p,))

    # Wrapper bat si existe
    wrapper = os.path.join(here, "carnelandia_print_host_windows.bat")
    lines.append("wrapper_bat_exists=%s" % (os.path.isfile(wrapper),))
    if os.path.isfile(wrapper):
        try:
            with open(wrapper, "r", encoding="utf-8", errors="replace") as f:
                lines.append("--- wrapper.bat ---")
                lines.append(f.read())
                lines.append("--- fin wrapper ---")
        except Exception as exc:
            lines.append("wrapper_read_error=%s" % (exc,))

    # Imports (misma ruta que impresion)
    for name in ("pywintypes", "pythoncom", "win32api", "win32print", "win32con", "win32ui"):
        try:
            mod = __import__(name)
            lines.append(
                "IMPORT_OK %s file=%s" % (name, getattr(mod, "__file__", "?"))
            )
        except Exception as exc:
            lines.append(
                "IMPORT_FAIL %s %s: %s" % (name, type(exc).__name__, exc)
            )
            lines.append(traceback.format_exc())

    # Simular decision de metodo
    try:
        import win32print  # noqa: F401

        win32print_ok = True
    except Exception:
        win32print_ok = False
    try:
        import win32ui  # noqa: F401
        import win32con  # noqa: F401

        gdi_ok = True
    except Exception as exc:
        gdi_ok = False
        lines.append("GDI_UNAVAILABLE %s" % (exc,))

    if win32print_ok and gdi_ok:
        lines.append("RECOMMENDED_METHOD=gdi_or_auto")
    elif win32print_ok:
        lines.append("RECOMMENDED_METHOD=text_cp1252_or_auto")
        lines.append(
            "NOTA: listar impresoras funciona con win32print;"
            " el mensaje 'Falta pywin32' al imprimir suele ser fallo de win32ui."
        )
    else:
        lines.append("RECOMMENDED_METHOD=none_fix_pywin32")

    lines.append("NO se envio ningun trabajo a la impresora.")

    report = "\r\n".join(lines) + "\r\n"
    saved = None
    last_err = None
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    fname = "diagnostico_impresion_%s.txt" % (stamp,)
    for d in out_dirs:
        try:
            if not os.path.isdir(d):
                os.makedirs(d)
            path = os.path.join(d, fname)
            with open(path, "w", encoding="utf-8") as f:
                f.write(report)
            saved = path
            break
        except Exception as exc:
            last_err = exc

    # Consola solo en modo diagnostico interactivo (doble clic / cmd), no Native Messaging
    if saved:
        print("Diagnostico guardado en:")
        print(saved)
        print("")
        print(report)
        return 0

    print("ERROR: no se pudo guardar el diagnostico: %s" % (last_err,))
    print(report)
    return 1


if __name__ == "__main__":
    sys.exit(main())
