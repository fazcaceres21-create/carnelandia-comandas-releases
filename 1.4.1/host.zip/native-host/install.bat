@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo ============================================
echo  Carnelandia Comandas - instalador Windows
echo ============================================
echo.

where powershell >nul 2>&1
if errorlevel 1 (
  echo ERROR: No se encuentra powershell.exe en el PATH.
  pause
  exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_windows.ps1" %*
set PS_EXIT=%ERRORLEVEL%

if %PS_EXIT%==0 goto OK_DONE

echo.
echo ============================================
echo  LA INSTALACION FALLO - codigo %PS_EXIT%
echo  Corrige el error de arriba y vuelve a
echo  ejecutar install.bat  (se puede reintentar)
echo ============================================
pause
exit /b %PS_EXIT%

:OK_DONE
echo.
echo Instalacion finalizada.
pause
exit /b 0
