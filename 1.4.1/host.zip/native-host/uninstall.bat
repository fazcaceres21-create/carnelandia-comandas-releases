@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Carnelandia Comandas — desinstalacion del host nativo
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall_windows.ps1"
echo.
pause
