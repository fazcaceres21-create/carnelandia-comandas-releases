#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Imprime la ruta de sys.executable. Usado por install_windows.ps1 (sin -c)."""
from __future__ import print_function
import sys

print(sys.executable)
