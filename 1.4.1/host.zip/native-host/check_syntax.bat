@echo off
setlocal
cd /d "%~dp0"
echo Comprobacion de sintaxis (no instala nada)...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0check_syntax.ps1"
set "PS_EXIT=%ERRORLEVEL%"
echo.
if not "%PS_EXIT%"=="0" (
  echo FALLO la comprobacion de sintaxis.
  pause
  exit /b %PS_EXIT%
)
echo Sintaxis OK. Ya podes ejecutar install.bat
pause
exit /b 0
