#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Verifica las dependencias reales de impresion Windows con ESTE interprete.
Comprueba win32print, win32ui, win32con, pythoncom, pywintypes.
Usado por install_windows.ps1 y diagnose_print_path.py.
Exit 0 = ruta de impresion viable (al menos win32print).
Exit 2 = falta win32print (impresion imposible).
Exit 3 = win32print OK pero falta win32ui/win32con (GDI no; TEXT si).
"""
from __future__ import print_function

import os
import sys


def try_import(name):
    try:
        __import__(name)
        mod = sys.modules[name]
        path = getattr(mod, "__file__", "(builtin/dll)")
        return True, str(path), None
    except Exception as exc:
        return False, None, "%s: %s" % (type(exc).__name__, exc)


def main():
    print("sys.executable=%s" % (sys.executable,))
    print("sys.version=%s" % (sys.version.replace("\n", " "),))
    print("cwd=%s" % (os.getcwd(),))
    try:
        import site

        print("USER_SITE=%s" % (getattr(site, "USER_SITE", None),))
        print("ENABLE_USER_SITE=%s" % (getattr(site, "ENABLE_USER_SITE", None),))
    except Exception as exc:
        print("site_error=%s" % (exc,))

    modules = ["pywintypes", "pythoncom", "win32api", "win32print", "win32con", "win32ui"]
    results = {}
    for name in modules:
        ok, path, err = try_import(name)
        results[name] = (ok, path, err)
        if ok:
            print("IMPORT_OK %s -> %s" % (name, path))
        else:
            print("IMPORT_FAIL %s -> %s" % (name, err))

    if not results["win32print"][0]:
        sys.stderr.write(
            "FAIL: win32print no importa con este Python.\n"
            "El host nativo usa sys.executable de arriba; pip debe instalarse CON ese mismo exe.\n"
        )
        return 2

    # Enumerar impresoras (misma API que el host)
    try:
        import win32print

        flags = 2 | 4
        printers = win32print.EnumPrinters(flags)
        print("impresoras=%d" % (len(printers),))
        for item in printers:
            try:
                print(" - %s" % (item[2],))
            except Exception:
                print(" - %s" % (item,))
    except Exception as exc:
        sys.stderr.write("FAIL: EnumPrinters: %s\n" % (exc,))
        return 2

    gdi_ok = results["win32ui"][0] and results["win32con"][0]
    if gdi_ok:
        print("PRINT_PATH=gdi_and_text")
        print("OK dependencias de impresion completas")
        return 0

    print("PRINT_PATH=text_only")
    print(
        "WARN: win32print OK pero falta win32ui y/o win32con."
        " La impresion GDI fallara; el host debe usar text_cp1252 o auto."
    )
    if results["win32ui"][2]:
        print("DETAIL_win32ui=%s" % (results["win32ui"][2],))
    if results["win32con"][2]:
        print("DETAIL_win32con=%s" % (results["win32con"][2],))
    sys.stderr.write(
        "WARN: GDI incompleto. Ejecuta: python -m pywin32_postinstall -install\n"
        "O configura windowsPrintMethod=auto|text_cp1252 en config.json\n"
    )
    # Exit 0: impresion TEXT sigue siendo viable (no bloquear instalador)
    return 0


if __name__ == "__main__":
    sys.exit(main())
