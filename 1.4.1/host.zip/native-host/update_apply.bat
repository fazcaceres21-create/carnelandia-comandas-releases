@echo off
cd /d "%~dp0"
echo Carnelandia - aplicar actualizacion del canal
echo Solo si NO hay cobro/impresion en curso.
where py >nul 2>&1
if %ERRORLEVEL%==0 (
  py -3 carnelandia_updater.py --apply
  goto :done
)
python carnelandia_updater.py --apply
:done
echo.
echo Si se actualizo la extension: chrome://extensions -> Recargar.
echo Si se actualizo el host: cierra start_agent y vuelve a abrirlo; si hace falta, reinicia Chrome.
pause
