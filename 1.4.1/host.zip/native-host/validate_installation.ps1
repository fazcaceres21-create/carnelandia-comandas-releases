﻿#Requires -Version 5.1
# Validacion integral del componente Windows. NO declara exito si falta algo critico.
# No imprime a la cola salvo -TestQueue (opcional, 1 trabajo de prueba).
# Uso: powershell -NoProfile -ExecutionPolicy Bypass -File .\validate_installation.ps1
#      .\validate_installation.ps1 -TestQueue

param(
  [switch]$TestQueue
)

$ErrorActionPreference = "Continue"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$ReportDir = Join-Path $env:USERPROFILE "CarnelandiaComandas\logs"
New-Item -ItemType Directory -Force -Path $ReportDir | Out-Null
$Stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$ReportPath = Join-Path $ReportDir ("validacion_" + $Stamp + ".txt")

$lines = New-Object System.Collections.Generic.List[string]
$fail = 0

function Add-Line([string]$t) { [void]$lines.Add($t); Write-Host $t }
function Fail([string]$t) {
  $script:fail++
  Add-Line ("FAIL: " + $t)
}
function Pass([string]$t) { Add-Line ("PASS: " + $t) }
function Info([string]$t) { Add-Line ("INFO: " + $t) }

Add-Line "Carnelandia Comandas - VALIDACION"
Add-Line ("fecha=" + (Get-Date -Format "o"))
Add-Line ("root=" + $Root)
Add-Line ""

# --- Archivos ---
$need = @(
  "carnelandia_print_host.py",
  "verify_pywin32.py",
  "diagnose_print_path.py",
  "print_python_exe.py",
  "config\config.json"
)
foreach ($n in $need) {
  $p = Join-Path $Root $n
  if (Test-Path -LiteralPath $p) { Pass ("archivo " + $n) }
  else { Fail ("falta archivo " + $n) }
}

$Wrapper = Join-Path $Root "carnelandia_print_host_windows.bat"
$Manifest = Join-Path $Root "nm-manifest\com.carnelandia.comandas.json"
$RegPath = "HKCU:\Software\Google\Chrome\NativeMessagingHosts\com.carnelandia.comandas"

if (Test-Path -LiteralPath $Wrapper) { Pass "wrapper bat existe" } else { Fail "falta carnelandia_print_host_windows.bat (ejecuta install.bat)" }

# --- Python desde wrapper o PATH ---
$PythonExe = $null
if (Test-Path -LiteralPath $Wrapper) {
  $batText = Get-Content -LiteralPath $Wrapper -Raw -ErrorAction SilentlyContinue
  if ($batText -match '"([^"]+python[^"]*\.exe)"') {
    $PythonExe = $Matches[1]
    Info ("python del wrapper=" + $PythonExe)
  }
}
if (-not $PythonExe -or -not (Test-Path -LiteralPath $PythonExe)) {
  try {
    $PythonExe = (& py -3 (Join-Path $Root "print_python_exe.py") 2>$null | Select-Object -Last 1)
  } catch { }
}
if (-not $PythonExe -or -not (Test-Path -LiteralPath $PythonExe)) {
  Fail "no se pudo resolver python.exe del host"
} else {
  Pass ("interprete=" + $PythonExe)
}

# --- verify_pywin32 con ese interprete ---
if ($PythonExe -and (Test-Path -LiteralPath $PythonExe)) {
  $verifyPy = Join-Path $Root "verify_pywin32.py"
  $vout = & $PythonExe $verifyPy 2>&1 | Out-String
  Add-Line "--- verify_pywin32 ---"
  Add-Line $vout
  if ($LASTEXITCODE -eq 0) { Pass "verify_pywin32 exit 0" }
  else { Fail ("verify_pywin32 exit " + $LASTEXITCODE) }
  if ($vout -match "IMPORT_FAIL win32print") { Fail "win32print no importa" }
  if ($vout -match "IMPORT_FAIL win32ui") {
    Info "win32ui falla: impresion usara TEXT (auto). Opcional: python -m pywin32_postinstall -install"
  }
}

# --- Registro Chrome ---
if (Test-Path $RegPath) {
  $regVal = (Get-ItemProperty -Path $RegPath)."(default)"
  Info ("registro NM=" + $regVal)
  if ($regVal -and (Test-Path -LiteralPath $regVal)) { Pass "registro apunta a manifiesto existente" }
  else { Fail "registro NM invalido o manifiesto ausente" }
} else {
  Fail "falta clave NativeMessagingHosts en HKCU (Chrome)"
}

if (Test-Path -LiteralPath $Manifest) {
  $man = Get-Content -LiteralPath $Manifest -Raw
  Add-Line "--- manifiesto ---"
  Add-Line $man
  if ($man -match 'chrome-extension://([a-p]{32})/') {
    Pass ("allowed_origins ID=" + $Matches[1])
  } else {
    Fail "allowed_origins sin ID de extension valido"
  }
  if ($man -match '"path"\s*:\s*"([^"]+)"') {
    $mpath = $Matches[1] -replace '\\\\', '\'
    if (Test-Path -LiteralPath $mpath) { Pass ("path manifiesto existe: " + $mpath) }
    else { Fail ("path manifiesto no existe: " + $mpath) }
  }
} else {
  Fail "falta nm-manifest (ejecuta install.bat)"
}

# --- self_check via host (mismo interprete; archivo auxiliar sin -c) ---
if ($PythonExe -and (Test-Path -LiteralPath (Join-Path $Root "carnelandia_print_host.py"))) {
  $tmp = Join-Path $env:TEMP ("carnelandia_self_check_" + $Stamp + ".py")
  $code2 = "import json,sys`r`n" +
    "sys.path.insert(0, r'''" + $Root + "''')`r`n" +
    "import carnelandia_print_host as h`r`n" +
    "r=h.handle({'action':'self_check','protocolVersion':1})`r`n" +
    "print(json.dumps(r,ensure_ascii=False,indent=2))`r`n" +
    "sys.exit(0 if r.get('ok') else 1)`r`n"
  [System.IO.File]::WriteAllText($tmp, $code2)
  $sout = & $PythonExe $tmp 2>&1 | Out-String
  Add-Line "--- self_check ---"
  Add-Line $sout
  if ($LASTEXITCODE -eq 0) { Pass "self_check OK" } else { Fail "self_check fallo" }
  Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
}

# --- Test queue opcional ---
if ($TestQueue) {
  Info "TestQueue: enviando 1 copia de prueba a la cola (NO confirma papel fisico)"
  $tmp2 = Join-Path $env:TEMP ("carnelandia_test_print_" + $Stamp + ".py")
  $code3 = "import json,sys`r`n" +
    "sys.path.insert(0, r'''" + $Root + "''')`r`n" +
    "import carnelandia_print_host as h`r`n" +
    "r=h.handle({'action':'test_print','protocolVersion':1})`r`n" +
    "print(json.dumps(r,ensure_ascii=False,indent=2))`r`n" +
    "sys.exit(0 if r.get('ok') else 1)`r`n"
  [System.IO.File]::WriteAllText($tmp2, $code3)
  $tout = & $PythonExe $tmp2 2>&1 | Out-String
  Add-Line "--- test_print ---"
  Add-Line $tout
  if ($LASTEXITCODE -eq 0) { Pass "test_print: enviado a la cola (queued)" }
  else { Fail "test_print no pudo encolar" }
  Remove-Item -LiteralPath $tmp2 -Force -ErrorAction SilentlyContinue
} else {
  Info "Omitido test de cola. Para incluirlo: validate_installation.ps1 -TestQueue"
}

Add-Line ""
if ($fail -eq 0) {
  Add-Line "RESULTADO=EXITO (requisitos del componente OK)"
  Add-Line "Siguiente: Chrome popup -> demo OFF -> pasos 1-4 diagnostico -> WhatsApp imprimir."
  Add-Line "Recuerda: queued != papel fisico."
} else {
  Add-Line ("RESULTADO=FALLO checks_fallidos=" + $fail)
  Add-Line "Ejecuta install.bat (mismo ID de extension) y vuelve a VALIDAR.bat"
}

[System.IO.File]::WriteAllText($ReportPath, ($lines -join "`r`n"), (New-Object System.Text.UTF8Encoding $false))
Write-Host ""
Write-Host ("Informe: " + $ReportPath)

if ($fail -eq 0) { exit 0 } else { exit 1 }
