@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo ============================================
echo  Carnelandia - VALIDACION del componente
echo  No declara exito si falta algo critico
echo ============================================
echo.
where powershell >nul 2>&1
if errorlevel 1 (
  echo ERROR: falta powershell.exe
  pause
  exit /b 1
)

set "EXTRA="
if /I "%~1"=="-TestQueue" set "EXTRA=-TestQueue"
if /I "%~1"=="/TestQueue" set "EXTRA=-TestQueue"

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0validate_installation.ps1" %EXTRA%
set ERR=%ERRORLEVEL%
echo.
if %ERR%==0 (
  echo VALIDACION OK - podes usar Chrome
) else (
  echo VALIDACION FALLO - lee el informe en
  echo %%USERPROFILE%%\CarnelandiaComandas\logs\
)
pause
exit /b %ERR%
