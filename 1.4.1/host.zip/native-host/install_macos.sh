#!/bin/bash
# Instala el Native Messaging host para Chrome/Chromium en macOS.
# NO configura servicios de inicio automático.
# NO cambia la impresora predeterminada.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
HOST_PY="$ROOT/carnelandia_print_host.py"
WRAPPER="$ROOT/carnelandia_print_host_macos.sh"
NM_DIR="$HOME/Library/Application Support/Google/Chrome/NativeMessagingHosts"
MANIFEST_NAME="com.carnelandia.comandas.json"

chmod +x "$HOST_PY"

# Wrapper: asegura python3 del sistema
cat > "$WRAPPER" << EOF
#!/bin/bash
exec /usr/bin/python3 "$HOST_PY"
EOF
chmod +x "$WRAPPER"

echo "=== Carnelandia Comandas — instalación macOS ==="
echo "1) Cargá la extensión en Chrome (chrome://extensions → Modo desarrollador → Cargar descomprimida)."
echo "2) Abrí el popup de la extensión y copiá el ID."
read -r -p "Pegá el ID de la extensión: " EXT_ID
if [[ -z "$EXT_ID" ]]; then
  echo "ID vacío. Abortando."
  exit 1
fi

mkdir -p "$NM_DIR"
MANIFEST="$NM_DIR/$MANIFEST_NAME"
cat > "$MANIFEST" << EOF
{
  "name": "com.carnelandia.comandas",
  "description": "Carnelandia Comandas — impresión térmica local",
  "path": "$WRAPPER",
  "type": "stdio",
  "allowed_origins": [
    "chrome-extension://$EXT_ID/"
  ]
}
EOF

# Opcional: Chromium / Chrome Canary paths
for ALT in \
  "$HOME/Library/Application Support/Chromium/NativeMessagingHosts" \
  "$HOME/Library/Application Support/Google/Chrome Canary/NativeMessagingHosts"
do
  if [[ -d "$(dirname "$ALT")" ]]; then
    mkdir -p "$ALT"
    cp "$MANIFEST" "$ALT/$MANIFEST_NAME"
    echo "También instalado en: $ALT"
  fi
done

echo ""
echo "Manifiesto escrito en:"
echo "  $MANIFEST"
echo "Host: $WRAPPER"
echo ""
echo "Opcional: pip3 install --user reportlab   # mejor Unicode en PDF"
echo "Reiniciá Chrome, abrí el popup → Probar componente nativo."
echo "Dejá Modo demostración activo hasta verificar la térmica."
