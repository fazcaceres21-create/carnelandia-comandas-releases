﻿#Requires -Version 5.1
# Carnelandia Comandas - instalador Native Messaging (Windows PowerShell 5.1)
# NO cambia impresora predeterminada, USB, ni StarPOS.
# Las llamadas a Python usan archivos .py auxiliares (sin codigo embebido en la linea de comando).

param(
  [string]$ExtensionId = "",
  [string]$PrinterName = "Generic / Text Only",
  [ValidateSet("gdi", "text_cp1252", "auto")]
  [string]$PrintMethod = "auto"
)

$ErrorActionPreference = "Stop"

function Write-Step {
  param([string]$Message)
  Write-Host ""
  Write-Host ("==> " + $Message) -ForegroundColor Cyan
}

function Write-Fail {
  param([string]$Message)
  Write-Host ("ERROR: " + $Message) -ForegroundColor Red
}

function Write-Ok {
  param([string]$Message)
  Write-Host ("OK: " + $Message) -ForegroundColor Green
}

function Exit-Fail {
  param([string]$Message)
  Write-Fail $Message
  exit 1
}

function Escape-JsonString {
  param([string]$Value)
  if ($null -eq $Value) { return "" }
  $s = $Value.Replace("\", "\\").Replace('"', '\"')
  return $s
}

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$HostPy = Join-Path $Root "carnelandia_print_host.py"
$PrintExePy = Join-Path $Root "print_python_exe.py"
$VerifyPy = Join-Path $Root "verify_pywin32.py"
$ConfigDir = Join-Path $Root "config"
$ConfigPath = Join-Path $ConfigDir "config.json"
$Wrapper = Join-Path $Root "carnelandia_print_host_windows.bat"
$ManifestName = "com.carnelandia.comandas.json"
$ManifestDir = Join-Path $Root "nm-manifest"
$ManifestPath = Join-Path $ManifestDir $ManifestName
$ReqFile = Join-Path $Root "requirements.txt"
$utf8NoBom = New-Object System.Text.UTF8Encoding $false

Write-Host "============================================"
Write-Host " Carnelandia Comandas - instalador Windows"
Write-Host "============================================"
Write-Host ("Carpeta host: " + $Root)

if (-not (Test-Path -LiteralPath $HostPy)) {
  Exit-Fail ("No se encuentra carnelandia_print_host.py en: " + $HostPy)
}
if (-not (Test-Path -LiteralPath $PrintExePy)) {
  Exit-Fail ("No se encuentra print_python_exe.py en: " + $PrintExePy)
}
if (-not (Test-Path -LiteralPath $VerifyPy)) {
  Exit-Fail ("No se encuentra verify_pywin32.py en: " + $VerifyPy)
}

# --- Python 3 ---
Write-Step "Buscando Python 3"
$PythonExe = $null

function Try-Resolve-Python {
  param(
    [string]$Launcher,
    [string[]]$PrefixArgs
  )
  $cmd = Get-Command $Launcher -ErrorAction SilentlyContinue
  if ($null -eq $cmd) { return $null }

  try {
    $verArgs = $PrefixArgs + @("--version")
    $verText = & $Launcher @verArgs 2>&1 | Out-String
    if ($verText -notmatch "Python 3\.") {
      return $null
    }

    # Archivo .py auxiliar: evita codigo Python embebido y comillas anidadas
    $runArgs = $PrefixArgs + @($PrintExePy)
    $exeLine = & $Launcher @runArgs 2>&1 | Out-String
    $candidate = ""
    $outLines = @($exeLine -split "`r?`n" | Where-Object { $_.Trim() -ne "" })
    if ($outLines.Count -gt 0) {
      $candidate = $outLines[$outLines.Count - 1].Trim()
    }

    if (($candidate.Length -gt 0) -and (Test-Path -LiteralPath $candidate)) {
      Write-Ok $verText.Trim()
      return $candidate
    }
  } catch {
    return $null
  }
  return $null
}

$PythonExe = Try-Resolve-Python -Launcher "py" -PrefixArgs @("-3")
if ($null -eq $PythonExe) {
  $PythonExe = Try-Resolve-Python -Launcher "python" -PrefixArgs @()
}
if ($null -eq $PythonExe) {
  $PythonExe = Try-Resolve-Python -Launcher "python3" -PrefixArgs @()
}

if ($null -eq $PythonExe) {
  Write-Fail "No se encontro Python 3 en el PATH."
  Write-Host "1) Descargar https://www.python.org/downloads/windows/"
  Write-Host "2) Instalar marcando Add python.exe to PATH"
  Write-Host "3) Cerrar esta ventana, abrir otra y volver a ejecutar install.bat"
  exit 1
}

Write-Ok ("python.exe = " + $PythonExe)

# --- Dependencias: omitir pip si verify ya pasa (reparacion parcial) ---
Write-Step "Comprobando si pywin32 ya sirve con este Python"
$preOk = $false
try {
  $preOut = & $PythonExe $VerifyPy 2>&1 | Out-String
  if ($LASTEXITCODE -eq 0 -and ($preOut -notmatch "IMPORT_FAIL win32print")) {
    $preOk = $true
    Write-Ok "verify previo OK — se omite pip (instalacion parcial detectada)"
    Write-Host $preOut
  }
} catch { }

if (-not $preOk) {
  Write-Step "Instalando dependencias (pywin32, reportlab)"
  if (-not (Test-Path -LiteralPath $ReqFile)) {
    $reqBody = "pywin32>=306`r`nreportlab>=4.0`r`n"
    [System.IO.File]::WriteAllText($ReqFile, $reqBody, $utf8NoBom)
  }
  $pipExit = 0
  try {
    & $PythonExe -m pip install --user -r $ReqFile
    $pipExit = $LASTEXITCODE
  } catch {
    Exit-Fail ("pip lanzo excepcion: " + $_.Exception.Message)
  }
  if ($null -eq $pipExit) { $pipExit = 0 }
  if ($pipExit -ne 0) {
    Exit-Fail ("pip fallo con codigo " + $pipExit)
  }
  Write-Ok "Dependencias instaladas"
} else {
  Write-Ok "pip no necesario en este pase"
}

# Post-install siempre si win32ui falta (no reinstala el wheel)
Write-Step "pywin32_postinstall (DLLs win32ui)"
try {
  & $PythonExe -m pywin32_postinstall -install
  Write-Ok "pywin32_postinstall ejecutado"
} catch {
  Write-Host ("Aviso postinstall: " + $_.Exception.Message) -ForegroundColor Yellow
}

Write-Step "Verificacion final de impresion (mismo Python del host)"
$verifyExit = 0
$verifyOut = ""
try {
  $verifyOut = & $PythonExe $VerifyPy 2>&1 | Out-String
  $verifyExit = $LASTEXITCODE
} catch {
  Exit-Fail ("Fallo verify_pywin32.py: " + $_.Exception.Message)
}
Write-Host $verifyOut
if ($null -eq $verifyExit) { $verifyExit = 1 }
if ($verifyExit -ne 0) {
  Exit-Fail ("Verificacion final fallo (codigo " + $verifyExit + "). Corre diagnose.bat y mira IMPORT_FAIL.")
}
Write-Ok "Dependencias OK con este interprete"

# --- Extension ID ---
Write-Step "ID de la extension Chrome"
if ([string]::IsNullOrWhiteSpace($ExtensionId)) {
  Write-Host ""
  Write-Host "1) Abri Chrome -> chrome://extensions"
  Write-Host "2) Activa Modo de desarrollador"
  Write-Host "3) Carga la carpeta extension del paquete (si aun no esta)"
  Write-Host "4) Abri el popup de Carnelandia y COPIA el ID (boton Copiar ID)"
  Write-Host ""
  $ExtensionId = Read-Host "Pega el ID de la extension (32 caracteres)"
}

$ExtensionId = $ExtensionId.Trim().ToLowerInvariant()
if ($ExtensionId.StartsWith("chrome-extension://")) {
  $ExtensionId = $ExtensionId.Substring("chrome-extension://".Length)
}
$ExtensionId = $ExtensionId.TrimEnd("/")

if ($ExtensionId -notmatch '^[a-p]{32}$') {
  Exit-Fail ("ID invalido: '" + $ExtensionId + "'. Debe ser el ID que muestra Chrome (32 letras a-p). No inventes uno.")
}
Write-Ok ("Extension ID = " + $ExtensionId)

# --- Wrapper .bat (idempotente) ---
Write-Step "Creando lanzador del host"
# Mismo python.exe absoluto del instalador. No tocar PYTHONNOUSERSITE.
# cd al directorio del host para imports relativos de config.
$batLines = @(
  "@echo off",
  "REM Carnelandia Comandas - Native Messaging host (Windows)",
  "REM Generado por install_windows.ps1 - no editar a mano",
  ("cd /d `"" + $Root + "`""),
  ("`"" + $PythonExe + "`" `"" + $HostPy + "`"")
)
$batText = [string]::Join("`r`n", $batLines) + "`r`n"
[System.IO.File]::WriteAllText($Wrapper, $batText, $utf8NoBom)
Write-Ok $Wrapper

# --- Config (conserva impresora / cut / canal si ya existia) ---
Write-Step "Escribiendo config (impresora de caja)"
if (-not (Test-Path -LiteralPath $ConfigDir)) {
  New-Item -ItemType Directory -Force -Path $ConfigDir | Out-Null
}

$pn = $PrinterName
$pm = $PrintMethod
$paper = 80
$cutBetween = $true
$cutMode = "escpos_full"
$updateUrl = ""
if (Test-Path -LiteralPath $ConfigPath) {
  try {
    $prev = Get-Content -LiteralPath $ConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($prev.printerName) { $pn = [string]$prev.printerName }
    if ($prev.windowsPrintMethod) { $pm = [string]$prev.windowsPrintMethod }
    if ($prev.paperWidthMm) { $paper = [int]$prev.paperWidthMm }
    if ($null -ne $prev.cutBetweenCopies) { $cutBetween = [bool]$prev.cutBetweenCopies }
    if ($prev.cutMode) { $cutMode = [string]$prev.cutMode }
    if ($prev.updateChannelUrl) { $updateUrl = [string]$prev.updateChannelUrl }
    Write-Host "Config anterior conservada (impresora / corte / canal)."
  } catch {
    Write-Host "Aviso: no se pudo leer config previa; se escribe nueva." -ForegroundColor Yellow
  }
}
# Parametro de instalador solo pisa si el usuario lo paso distinto del default
# y no habia config previa con printerName — ya mezclado arriba.
$pnEsc = Escape-JsonString $pn
$pmEsc = Escape-JsonString $pm
$cutModeEsc = Escape-JsonString $cutMode
$updateEsc = Escape-JsonString $updateUrl
$cutJson = "true"
if (-not $cutBetween) { $cutJson = "false" }
$configJson = @"
{
  "printerName": "$pnEsc",
  "paperWidthMm": $paper,
  "demoModeDefault": false,
  "windowsPrintMethod": "$pmEsc",
  "cutBetweenCopies": $cutJson,
  "cutMode": "$cutModeEsc",
  "updateChannelUrl": "$updateEsc",
  "notes": "No cambia la impresora predeterminada del SO. StarPOS intacto."
}
"@
[System.IO.File]::WriteAllText($ConfigPath, $configJson.Trim() + "`r`n", $utf8NoBom)
Write-Ok ("Impresora preferida en config: " + $pn + " (metodo " + $pm + ", corte " + $cutMode + ")")

# --- Manifiesto Native Messaging ---
Write-Step "Registrando Native Messaging en Chrome (usuario actual)"
if (-not (Test-Path -LiteralPath $ManifestDir)) {
  New-Item -ItemType Directory -Force -Path $ManifestDir | Out-Null
}

$pathJson = Escape-JsonString $Wrapper
$origin = "chrome-extension://" + $ExtensionId + "/"
$originJson = Escape-JsonString $origin

$manifestJson = @"
{
  "name": "com.carnelandia.comandas",
  "description": "Carnelandia Comandas - impresion termica local",
  "path": "$pathJson",
  "type": "stdio",
  "allowed_origins": [
    "$originJson"
  ]
}
"@
[System.IO.File]::WriteAllText($ManifestPath, $manifestJson.Trim() + "`r`n", $utf8NoBom)
Write-Ok ("Manifiesto: " + $ManifestPath)

$RegPath = "HKCU:\Software\Google\Chrome\NativeMessagingHosts\com.carnelandia.comandas"
New-Item -Path $RegPath -Force | Out-Null
Set-ItemProperty -Path $RegPath -Name "(default)" -Value $ManifestPath
Write-Ok ("Registro: " + $RegPath)

$EdgeParent = "HKCU:\Software\Microsoft\Edge\NativeMessagingHosts"
if (Test-Path $EdgeParent) {
  $EdgeKey = Join-Path $EdgeParent "com.carnelandia.comandas"
  try {
    New-Item -Path $EdgeKey -Force | Out-Null
    Set-ItemProperty -Path $EdgeKey -Name "(default)" -Value $ManifestPath
    Write-Host "Tambien registrado en Edge (si lo usan)."
  } catch {
    Write-Host ("Aviso Edge: " + $_.Exception.Message) -ForegroundColor Yellow
  }
}

# --- Self-test del host (script + argumento --self-test) ---
Write-Step "Autoprueba del host (--self-test)"
try {
  $selfOut = & $PythonExe $HostPy --self-test 2>&1 | Out-String
  Write-Host $selfOut
  if ($LASTEXITCODE -ne 0) {
    Write-Host "Aviso: self-test devolvio codigo distinto de 0. El registro del host ya quedo hecho." -ForegroundColor Yellow
  } else {
    Write-Ok "Self-test ejecutado"
  }
} catch {
  Write-Host ("Aviso: self-test con error: " + $_.Exception.Message) -ForegroundColor Yellow
  Write-Host "El registro del host ya quedo hecho; podes continuar con Chrome." -ForegroundColor Yellow
}

# --- Agente HTTP (autoimpresion Pedidos) ---
Write-Step "Registrando agente local al inicio de sesion"
$AgentBat = Join-Path $Root "start_agent.bat"
$StartupDir = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Startup"
$StartupLnk = Join-Path $StartupDir "CarnelandiaComandasAgent.cmd"
if (Test-Path -LiteralPath $AgentBat) {
  $cmdText = "@echo off`r`nstart `"`" /MIN `"" + $AgentBat + "`"`r`n"
  [System.IO.File]::WriteAllText($StartupLnk, $cmdText, $utf8NoBom)
  Write-Ok ("Inicio automatico: " + $StartupLnk)
  try {
    Start-Process -FilePath $AgentBat -WindowStyle Minimized
    Write-Ok "Agente iniciado ahora (puerto 17355)"
  } catch {
    Write-Host ("Aviso: no se pudo iniciar agente: " + $_.Exception.Message) -ForegroundColor Yellow
  }
} else {
  Write-Host "Aviso: falta start_agent.bat" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host " Instalacion del componente nativo LISTA" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
Write-Host ""
Write-Host "SIGUIENTE (en esta PC):"
Write-Host "1) CERRA todas las ventanas de Chrome y volve a abrirlo"
Write-Host "2) chrome://extensions -> recargar Carnelandia Comandas"
Write-Host "3) Popup -> desactivar Modo demostracion"
Write-Host ("4) Popup -> Actualizar lista -> elegir " + $pn)
Write-Host "5) Popup -> Probar componente nativo -> debe decir OK"
Write-Host "6) Confirmar agente: popup -> Estado agente (o http://127.0.0.1:17355/v1/health)"
Write-Host "7) WhatsApp Web -> interruptor auto verde + impresion manual siguen disponibles"
Write-Host ""
Write-Host "Actualizar extension (modo desarrollador): reemplazar carpeta + Recargar."
Write-Host "Actualizar host por internet: configurar update_channel.txt y ejecutar update_check.bat"
Write-Host "Desinstalar host: uninstall.bat"
Write-Host ""

exit 0
