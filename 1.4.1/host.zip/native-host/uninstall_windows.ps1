﻿#Requires -Version 5.1
# Quita el registro Native Messaging de Carnelandia. No desinstala Python ni la extension.
$ErrorActionPreference = "Continue"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host "Desinstalando registro Native Messaging de Carnelandia..."

$keys = @(
  "HKCU:\Software\Google\Chrome\NativeMessagingHosts\com.carnelandia.comandas",
  "HKCU:\Software\Microsoft\Edge\NativeMessagingHosts\com.carnelandia.comandas"
)
foreach ($k in $keys) {
  if (Test-Path $k) {
    Remove-Item -Path $k -Recurse -Force
    Write-Host ("Eliminado: " + $k)
  }
}

$wrapper = Join-Path $Root "carnelandia_print_host_windows.bat"
if (Test-Path -LiteralPath $wrapper) {
  Remove-Item -LiteralPath $wrapper -Force
  Write-Host ("Eliminado lanzador: " + $wrapper)
}

$manifest = Join-Path $Root "nm-manifest\com.carnelandia.comandas.json"
if (Test-Path -LiteralPath $manifest) {
  Remove-Item -LiteralPath $manifest -Force
  Write-Host ("Eliminado manifiesto: " + $manifest)
}

Write-Host ""
Write-Host "Listo. La carpeta del proyecto y Python quedan intactos."
Write-Host "Para quitar la extension: chrome://extensions -> Quitar."
Write-Host "Reinicia Chrome."
exit 0
