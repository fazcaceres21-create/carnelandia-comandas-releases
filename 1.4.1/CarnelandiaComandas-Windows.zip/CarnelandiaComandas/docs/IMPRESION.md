# Método de impresión por sistema

## Principios

- Usar impresoras **ya instaladas** en el sistema operativo.
- **No** asumir ESC/POS ni enviar RAW sin comprobar compatibilidad.
- **No** construir comandos de shell con texto del cliente.
- El nombre de impresora sale de la configuración (popup), validado contra caracteres peligrosos y contra la lista del SO.
- Distinguir **enviado a la cola** (`queued`) de **confirmación física** (casi nunca disponible en térmicas de consumo vía CUPS/spooler).

## macOS

1. El host genera un **PDF** del ticket (ReportLab + fuente del sistema con soporte de tildes/ñ si está instalado; si no, PDF mínimo con Helvetica).
2. Se envía a CUPS con `lp -d <impresora> <archivo.pdf>` usando argv (sin shell).
3. Resultado típico: `queued`. CUPS aceptó el trabajo; **no** garantiza que el papel haya salido.

Requisito opcional: `pip3 install --user reportlab` para mejor Unicode.

## Windows 10 (caja Carnelandia)

Impresora comprobada en el local: **`Generic / Text Only`** (USB, winprint, datatype RAW en el driver).  
Este proyecto **no** abre el puerto USB007 ni cambia el controlador ni la impresora predeterminada.

1. **Método por defecto `gdi`**: `CreatePrinterDC` + `TextOut` Unicode con **Arial Bold**, tipografía grande, márgenes ~1,5 mm. El spooler convierte según el driver.
2. **Alternativa `text_cp1252`**: envío de texto Windows-1252 con datatype **TEXT** (no ESC/POS). Útil si GDI falla o los acentos se corrompen con el genérico.
3. **`auto`**: intenta GDI y, si falla, cp1252.
4. Resultado típico: **`queued`**. No afirmamos salida física del papel.
5. Config: `native-host/config/config.json` → `windowsPrintMethod`.
6. **Corte entre copias (1.4):** tras cada copia se envía un trabajo aparte con avance + corte. Default `cutMode: escpos_full` (`GS V` por datatype **RAW**). Si el driver ignora RAW, hay fallback a saltos TEXT. Alternativas en config: `escpos_partial`, `formfeed`, `feed`. **Validar en la térmica real**; no se asume un modelo concreto.

Requisito: `pip install pywin32 reportlab` (el `install.bat` lo hace).

Si los acentos siguen mal con Generic/Text Only, hace falta el **modelo** de la comandera para evaluar driver del fabricante.

## Modo demostración

- No envía a impresora.
- Guarda `.txt` UTF-8 en `~/CarnelandiaComandas/demo_prints/` (si el host está instalado) o simula en la extensión / página demo.
- Outcome: `demo_saved`.

## Qué no hacemos

- Cambiar la impresora predeterminada del sistema.
- Tocar la configuración de StarPOS.
- Reintentar automáticamente trabajos con resultado incierto (timeout, error ambiguo).
- Afirmar “impreso” solo porque la cajera hizo clic.
