# Integración Pedidos ↔ Comandas (estado)

## Implementado en código

- Cola en servidor Pedidos (`lib/print-queue.ts` + APIs enqueue/pull/ack).
- Enqueue al tocar **ENVIAR PEDIDO POR WHATSAPP** (mismo `CP-<uuid>` que WhatsApp).
- Agente Windows: poll HTTPS saliente autenticado + impresión + ack.
- Parsers Comandas aceptan `CARNELANDIA_PEDIDO_WEB_V1`.

## Publicado

- App Pedidos viva: https://carnelandia-pedidos.fly.dev (**aún sin** el código de cola hasta el próximo `fly deploy`).
- Canal updates Comandas: ver `docs/ACTUALIZACIONES.md` (GitHub Releases/Pages).

## Pendiente de vos / caja

1. **Deploy Pedidos** con el código nuevo + `fly secrets set PRINT_AGENT_TOKEN=…`
2. En la PC: copiar ese token a `remote_queue.json` o `config.remoteQueueToken`
3. Probar pedido real con Chrome minimizado

## Confirmación vs impresión

| Evento | Confirma pedido humano | Habilita impresión auto |
|--------|------------------------|-------------------------|
| Resumen en pantalla | No | No |
| Botón ENVIAR + enqueue OK | Intent del cliente | **Sí** |
| Enviar en WhatsApp | Sí (operativo) | No (ya habilitada) |
