# Actualizaciones por internet — extensión + Native Host

## Principio

Son **dos componentes distintos**:

| Componente | Ubicación | ¿Chrome lo actualiza solo? |
|------------|-----------|----------------------------|
| Extensión MV3 | Carpeta `extension/` cargada en modo desarrollador, o Chrome Web Store | **No** en modo desarrollador. **Sí** solo si se publica en CWS. |
| Native Host + agente | `native-host/` + registro Windows + `start_agent.bat` | **No**. Usa el actualizador propio (`carnelandia_updater.py`). |

**Actualizar la extensión no actualiza el host.** Protocolo actual: **2** (`PROTOCOL_VERSION`).

---

## Qué hace el canal implementado (v1.4)

1. Publicás un **manifiesto HTTPS** (ejemplo: `releases/update-manifest.example.json`).
2. En la PC del negocio:  
   `%USERPROFILE%\CarnelandiaComandas\update_channel.txt`  
   con la URL del manifiesto, **o** `config.updateChannelUrl`.
3. `update_check.bat` → consulta versión / SHA-256 (no aplica).
4. `update_apply.bat` → si no hay impresión en curso:
   - Descarga zip del host, verifica **SHA-256**.
   - Respalda en `%USERPROFILE%\CarnelandiaComandas\backups\`.
   - Reemplaza archivos del host **conservando** `config/config.json` (impresora, corte, canal).
   - Opcional: zip de extensión → reemplaza archivos → **exige Recargar** en `chrome://extensions`.
5. Cola de pedidos (`queue/state.json`), token del agente e interruptor auto viven fuera del zip → **se conservan**.

### Qué NO es automático

| Pieza | Realidad |
|-------|----------|
| Extensión unpacked | Tras `update_apply`, hay que **Recargar** manualmente (o reiniciar Chrome). Chrome **prohíbe** auto-update de extensiones en modo desarrollador. |
| Host / agente | El apply deja archivos nuevos; hay que **reiniciar el agente** (`start_agent.bat`). Si Native Messaging falla, **reiniciar Chrome**. |
| Durante cobro | Si el agente reporta `printing=true`, el apply **se pospone**. |

No se promete “sin tocar nada” mientras la extensión siga en modo desarrollador.

---

## Canal recomendado a medio plazo

1. **Host**: este actualizador + HTTPS + SHA-256 (y Authenticode del instalador cuando haya `.msi` firmado).
2. **Extensión**: publicar en [Chrome Web Store](CHROME_WEB_STORE.md) → ahí sí Chrome actualiza solo. Hasta entonces: zip + Recargar, o política Enterprise.

---

## Publicar desde tu Mac

```bash
# Genera zips + manifiesto con hashes (editá la URL base)
python3 scripts/build_release.py --base-url https://TU-DOMINIO/carnelandia/releases/1.4.0/
```

Subí `host.zip`, `extension.zip` y `update-manifest.json` al hosting.  
En la caja: una sola vez `update_channel.txt` = URL del manifiesto. Después: `update_check` / `update_apply` (o popup «Buscar actualizaciones» solo consulta; apply sigue siendo el `.bat` para no sorprender en cobro).

---

## Recuperación

Si un apply falla: carpetas en `CarnelandiaComandas\backups\host_pre_update_*` / `extension_pre_update_*`. Copiá de vuelta sobre `native-host` / `extension` y reiniciá agente + Recargar extensión.
