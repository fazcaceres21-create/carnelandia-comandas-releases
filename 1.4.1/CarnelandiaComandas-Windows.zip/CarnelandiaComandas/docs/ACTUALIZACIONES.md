# Actualizaciones por internet — canal real

## Enlaces publicados (GitHub)

| Recurso | URL |
|---------|-----|
| **Instalación inicial Windows** | https://github.com/fazcaceres21-create/carnelandia-comandas-releases/releases/download/v1.4.1/CarnelandiaComandas-1.4.1.zip |
| Página / índice | https://fazcaceres21-create.github.io/carnelandia-comandas-releases/ |
| Release | https://github.com/fazcaceres21-create/carnelandia-comandas-releases/releases/tag/v1.4.1 |
| **Manifiesto updates (SHA-256)** | https://github.com/fazcaceres21-create/carnelandia-comandas-releases/releases/download/v1.4.1/update-manifest.json |

En la PC del negocio:

```
%USERPROFILE%\CarnelandiaComandas\update_channel.txt
```

contenido = URL del manifiesto de arriba.

Luego: `native-host\update_check.bat` / `update_apply.bat`.

## Qué se actualiza solo vs qué requiere acción

| Componente | Automático |
|------------|------------|
| Host + agente (tras `update_apply`) | Descarga + verifica hash + respaldo; reiniciar agente |
| Extensión modo desarrollador | Archivos pueden reemplazarse; **hay que Recargar** en chrome://extensions |
| Chrome Web Store | No publicado aún |

Config, impresora, interruptor auto, cola local y printed IDs **se conservan** (fuera del zip / `config.json` preservado).
