@echo off
REM Detiene agentes Carnelandia (viejos y nuevos) SIN reiniciar Windows.
setlocal EnableExtensions
echo Deteniendo agentes Carnelandia...

REM Ventana iniciada con start "CarnelandiaAgent"
taskkill /F /FI "WINDOWTITLE eq CarnelandiaAgent*" >nul 2>&1

REM Procesos Python cuyo comando incluye carnelandia_agent
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
  "$n=0; Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '^(python|pythonw|py)(\.exe)?$' -and $_.CommandLine -match 'carnelandia_agent' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue; $n++ }; Write-Host ('Procesos agente detenidos: ' + $n)"

REM PID registrado por el agente actual
if exist "%USERPROFILE%\CarnelandiaComandas\agent.pid" (
  for /f "usebackq delims=" %%P in ("%USERPROFILE%\CarnelandiaComandas\agent.pid") do (
    taskkill /F /PID %%P >nul 2>&1
  )
  del /F /Q "%USERPROFILE%\CarnelandiaComandas\agent.pid" >nul 2>&1
)

echo Listo. Podes iniciar de nuevo con start_agent.bat
exit /b 0
