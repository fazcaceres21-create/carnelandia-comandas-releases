@echo off
REM Carnelandia Comandas - agente HTTP local (autoimpresion Pedidos)
cd /d "%~dp0"
REM Evitar 2 agentes a la vez (causa 4 tickets)
call "%~dp0stop_agent.bat"
timeout /t 1 /nobreak >nul
where py >nul 2>&1
if %ERRORLEVEL%==0 (
  start "CarnelandiaAgent" /MIN py -3 carnelandia_agent.py
  goto :eof
)
where python >nul 2>&1
if %ERRORLEVEL%==0 (
  start "CarnelandiaAgent" /MIN python carnelandia_agent.py
  goto :eof
)
echo ERROR: No se encontro Python 3.
pause
