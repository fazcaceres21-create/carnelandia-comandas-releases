(function () {
  'use strict';
  const C = globalThis.CARNELANDIA;

  const paperWidth = document.getElementById('paperWidth');
  const demoMode = document.getElementById('demoMode');
  const autoPrint = document.getElementById('autoPrint');
  const printerName = document.getElementById('printerName');
  const hostStatus = document.getElementById('hostStatus');
  const extId = document.getElementById('extId');
  const demoBanner = document.getElementById('demoBanner');
  const appVer = document.getElementById('appVer');

  const SUGGESTED_PRINTER = 'Generic / Text Only';

  extId.textContent = chrome.runtime.id;
  if (appVer) appVer.textContent = C.VERSION || '';

  function setStatus(text, ok) {
    hostStatus.textContent = text;
    hostStatus.className = 'status ' + (ok ? 'ok' : 'err');
  }

  function updateDemoBanner() {
    if (!demoBanner) return;
    demoBanner.hidden = !demoMode.checked;
  }

  function ensurePrinterOption(name) {
    if (!name) return;
    const exists = Array.from(printerName.options).some((o) => o.value === name);
    if (!exists) {
      const opt = document.createElement('option');
      opt.value = name;
      opt.textContent = name + (name === SUGGESTED_PRINTER ? ' (caja)' : '');
      printerName.appendChild(opt);
    }
  }

  function save() {
    chrome.storage.local.set({
      [C.STORAGE_KEYS.PAPER_WIDTH]: parseInt(paperWidth.value, 10),
      [C.STORAGE_KEYS.DEMO_MODE]: demoMode.checked,
      [C.STORAGE_KEYS.PRINTER_NAME]: printerName.value || null,
      [C.STORAGE_KEYS.AUTO_PRINT]: autoPrint ? autoPrint.checked : true,
    });
    updateDemoBanner();
    if (autoPrint) {
      chrome.runtime.sendMessage({
        type: 'CARNELANDIA_SET_AUTO_PRINT',
        enabled: autoPrint.checked,
      });
    }
  }

  function load() {
    chrome.storage.local.get(
      [
        C.STORAGE_KEYS.PAPER_WIDTH,
        C.STORAGE_KEYS.DEMO_MODE,
        C.STORAGE_KEYS.PRINTER_NAME,
        C.STORAGE_KEYS.AUTO_PRINT,
      ],
      (data) => {
        paperWidth.value = String(
          data[C.STORAGE_KEYS.PAPER_WIDTH] || C.DEFAULTS.paperWidthMm
        );
        demoMode.checked =
          data[C.STORAGE_KEYS.DEMO_MODE] !== undefined
            ? !!data[C.STORAGE_KEYS.DEMO_MODE]
            : C.DEFAULTS.demoMode;
        if (autoPrint) {
          autoPrint.checked =
            data[C.STORAGE_KEYS.AUTO_PRINT] !== undefined
              ? !!data[C.STORAGE_KEYS.AUTO_PRINT]
              : C.DEFAULTS.autoPrintEnabled;
        }
        updateDemoBanner();
        ensurePrinterOption(SUGGESTED_PRINTER);
        const saved = data[C.STORAGE_KEYS.PRINTER_NAME] || '';
        if (saved) {
          ensurePrinterOption(saved);
          printerName.value = saved;
        }
      }
    );
  }

  paperWidth.addEventListener('change', save);
  demoMode.addEventListener('change', save);
  printerName.addEventListener('change', save);
  if (autoPrint) autoPrint.addEventListener('change', save);

  document.getElementById('btnCopyId').addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(chrome.runtime.id);
      setStatus('ID copiado', true);
    } catch (_) {
      setStatus('Copiá el ID manualmente', false);
    }
  });

  document.getElementById('btnPing').addEventListener('click', () => {
    setStatus('1/2 ping…', true);
    chrome.runtime.sendMessage({ type: 'CARNELANDIA_PING_HOST' }, (response) => {
      if (chrome.runtime.lastError) {
        setStatus('Extensión: ' + chrome.runtime.lastError.message, false);
        return;
      }
      if (!response || !response.ok) {
        setStatus(
          'FAIL comunicación: ' + (response?.message || 'sin respuesta'),
          false
        );
        return;
      }
      setStatus(
        'OK comunicación · host ' +
          (response.version || '?') +
          ' · protocolo ' +
          response.protocolVersion +
          (response.executable ? ' · ' + response.executable : ''),
        true
      );
    });
  });

  document.getElementById('btnSelfCheck').addEventListener('click', () => {
    setStatus('Self-check…', true);
    chrome.runtime.sendMessage({ type: 'CARNELANDIA_SELF_CHECK' }, (response) => {
      if (chrome.runtime.lastError || !response) {
        setStatus(
          'FAIL self-check: ' +
            (chrome.runtime.lastError?.message || 'sin respuesta'),
          false
        );
        return;
      }
      if (!response.ok) {
        setStatus('FAIL self-check: ' + (response.message || JSON.stringify(response.checks)), false);
        return;
      }
      const path = response.printPath || '?';
      const n = response.checks?.printers?.count;
      setStatus(
        'OK self-check · ruta=' +
          path +
          (n != null ? ' · impresoras=' + n : '') +
          ' · ' +
          (response.message || ''),
        true
      );
    });
  });

  document.getElementById('btnTestPrint').addEventListener('click', () => {
    if (demoMode.checked) {
      setStatus('FAIL: desactivá Modo demostración antes de probar la cola', false);
      return;
    }
    if (!printerName.value) {
      setStatus('FAIL: elegí impresora en la lista', false);
      return;
    }
    setStatus('Enviando prueba a la cola (1 copia)…', true);
    chrome.runtime.sendMessage({ type: 'CARNELANDIA_TEST_PRINT' }, (response) => {
      if (chrome.runtime.lastError || !response) {
        setStatus(
          'FAIL prueba: ' + (chrome.runtime.lastError?.message || 'sin respuesta'),
          false
        );
        return;
      }
      if (!response.ok) {
        setStatus('FAIL cola: ' + (response.message || response.code), false);
        return;
      }
      if (response.outcome === 'queued') {
        setStatus(
          'ENVIADO A LA COLA (no confirma papel físico). ' + (response.message || ''),
          true
        );
        return;
      }
      setStatus('Resultado: ' + (response.outcome || '') + ' — ' + (response.message || ''), true);
    });
  });

  document.getElementById('btnAgent')?.addEventListener('click', () => {
    setStatus('Consultando agente…', true);
    chrome.runtime.sendMessage({ type: 'CARNELANDIA_AGENT_STATUS' }, (response) => {
      if (chrome.runtime.lastError || !response) {
        setStatus(
          'FAIL agente: ' +
            (chrome.runtime.lastError?.message || 'sin respuesta') +
            ' — ejecutá start_agent.bat',
          false
        );
        return;
      }
      if (response.code === 'agent_unavailable' || response.ok === false) {
        setStatus(response.message || 'Agente no disponible', false);
        return;
      }
      setStatus(
        'Agente OK · auto=' +
          response.autoPrintEnabled +
          ' · pending=' +
          response.pendingCount +
          ' · uncertain=' +
          response.uncertainCount +
          ' · printed=' +
          response.printedCount +
          (response.pending && response.pending.length
            ? ' · ids: ' + response.pending.slice(0, 5).join(',')
            : ''),
        true
      );
    });
  });

  document.getElementById('btnUpdates')?.addEventListener('click', () => {
    setStatus('Buscando actualizaciones…', true);
    chrome.runtime.sendMessage({ type: 'CARNELANDIA_CHECK_UPDATES' }, (response) => {
      if (chrome.runtime.lastError || !response) {
        setStatus(
          'FAIL updates: ' + (chrome.runtime.lastError?.message || 'sin respuesta'),
          false
        );
        return;
      }
      setStatus(
        (response.message || JSON.stringify(response)) +
          (response.needsChromeReload
            ? ' — HACE FALTA Recargar la extensión en chrome://extensions'
            : ''),
        !!response.ok
      );
    });
  });

  document.getElementById('btnRefresh').addEventListener('click', () => {
    setStatus('Listando impresoras…', true);
    chrome.runtime.sendMessage({ type: 'CARNELANDIA_LIST_PRINTERS' }, (response) => {
      if (chrome.runtime.lastError || !response || !response.ok) {
        setStatus(
          'FAIL lista: ' +
            (chrome.runtime.lastError?.message ||
              response?.message ||
              'host ausente'),
          false
        );
        ensurePrinterOption(SUGGESTED_PRINTER);
        return;
      }
      const current = printerName.value;
      printerName.innerHTML = '<option value="">— Sin seleccionar —</option>';
      ensurePrinterOption(SUGGESTED_PRINTER);
      (response.printers || []).forEach((p) => {
        ensurePrinterOption(p.name);
      });
      if (current) {
        ensurePrinterOption(current);
        printerName.value = current;
      } else {
        const names = (response.printers || []).map((p) => p.name);
        if (names.includes(SUGGESTED_PRINTER)) {
          printerName.value = SUGGESTED_PRINTER;
        }
      }
      setStatus(
        'OK lista · ' + (response.printers || []).length + ' impresora(s). Elegí una y guardá.',
        true
      );
      save();
    });
  });

  load();
})();
