/**
 * Parser de pedidos Carnelandia Pedidos (texto WhatsApp / objeto JSON).
 * Acepta marcador WEB_V1 (producción) y el bloque <<< >>> documentado.
 */
(function (root) {
  'use strict';

  const MARK_START = '<<<CARNELANDIA_PEDIDO>>>';
  const MARK_END = '<<<FIN_PEDIDO>>>';
  const WEB_MARKER = 'CARNELANDIA_PEDIDO_WEB_V1';
  const ID_RE = /^ID:\s*(\S.+)$/im;
  const ID_PEDIDO_RE = /^ID_PEDIDO:\s*(\S.+)$/im;
  /** CP-… o UUID v4 (se normaliza a CP-…) */
  const ORDER_ID_RE = /^(?:CP-[A-Z0-9][A-Z0-9\-_.]{3,80}|[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12})$/i;

  function normalizeOrderId(id) {
    let t = String(id || '')
      .trim()
      .toUpperCase();
    if (!t) return '';
    if (!t.startsWith('CP-') && /^[0-9A-F]{8}-[0-9A-F]{4}-/i.test(t)) {
      t = 'CP-' + t;
    }
    return t;
  }

  function isValidOrderId(id) {
    const n = normalizeOrderId(id);
    return ORDER_ID_RE.test(n) || ORDER_ID_RE.test(String(id || '').trim());
  }

  function parseWebV1(raw) {
    const text = String(raw || '');
    const lines = text.replace(/\r\n/g, '\n').split('\n');
    if (!lines.length || lines[0].trim() !== WEB_MARKER) return null;
    const idMatch = text.match(ID_PEDIDO_RE);
    if (!idMatch) return null;
    const orderId = normalizeOrderId(idMatch[1]);
    if (!isValidOrderId(orderId)) return null;

    let customerName = '';
    let address = '';
    let notes = '';
    const items = [];
    let inPedido = false;
    for (const line of lines) {
      const t = line.trim();
      if (!t || t === WEB_MARKER || /^ID_PEDIDO:/i.test(t)) continue;
      if (/^NOMBRE:\s*/i.test(t)) {
        customerName = t.replace(/^NOMBRE:\s*/i, '').replace(/^\*|\*$/g, '').trim();
        inPedido = false;
        continue;
      }
      if (/^\*?DIRECCI[OÓ]N:\s*/i.test(t)) {
        address = t
          .replace(/^\*?DIRECCI[OÓ]N:\s*/i, '')
          .replace(/\*$/g, '')
          .trim();
        inPedido = false;
        continue;
      }
      if (/^\*?PEDIDO:\*?$/i.test(t) || /^\*PEDIDO:\*$/i.test(t)) {
        inPedido = true;
        continue;
      }
      if (/^\*?PAGO:/i.test(t) || /^COSTO DE ENV/i.test(t) || /^OBSERVACIONES:/i.test(t)) {
        inPedido = false;
        if (/^OBSERVACIONES:\s*/i.test(t)) {
          notes = t.replace(/^OBSERVACIONES:\s*/i, '').trim();
        }
        continue;
      }
      if (inPedido) {
        items.push(t.replace(/^\*|\*$/g, '').trim());
      }
    }

    return {
      orderId,
      customerName,
      address,
      items: items.filter(Boolean),
      notes,
      raw: text,
      schema: 'carnelandia.pedido.v1',
      source: 'whatsapp_web_v1',
    };
  }

  function parseBracketBlock(raw) {
    const text = String(raw || '');
    const i0 = text.indexOf(MARK_START);
    const i1 = text.indexOf(MARK_END);
    if (i0 < 0 || i1 < 0 || i1 <= i0) return null;
    const block = text.slice(i0 + MARK_START.length, i1).trim();
    const idMatch = block.match(ID_RE) || block.match(ID_PEDIDO_RE);
    if (!idMatch) return null;
    const orderId = normalizeOrderId(idMatch[1]);
    if (!isValidOrderId(orderId)) return null;

    let customerName = '';
    let address = '';
    let notes = '';
    const items = [];
    let mode = null;
    block.split(/\r?\n/).forEach((line) => {
      const t = line.trim();
      if (!t) return;
      if (/^ID(_PEDIDO)?:/i.test(t)) return;
      if (/^CLIENTE:/i.test(t) || /^NOMBRE:/i.test(t)) {
        customerName = t.replace(/^(CLIENTE|NOMBRE):\s*/i, '').trim();
        mode = null;
        return;
      }
      if (/^DIRECCI[OÓ]N:/i.test(t)) {
        address = t.replace(/^DIRECCI[OÓ]N:\s*/i, '').trim();
        mode = null;
        return;
      }
      if (/^ACLARACIONES?:/i.test(t) || /^OBSERVACIONES:/i.test(t)) {
        notes = t.replace(/^(ACLARACIONES?|OBSERVACIONES):\s*/i, '').trim();
        mode = 'notes';
        return;
      }
      if (/^ITEMS?:/i.test(t) || /^PEDIDO:/i.test(t)) {
        mode = 'items';
        return;
      }
      if (mode === 'items') items.push(t);
      else if (mode === 'notes' && notes) notes += ' ' + t;
    });

    return {
      orderId,
      customerName,
      address,
      items,
      notes,
      raw: block,
      schema: 'carnelandia.pedido.v1',
    };
  }

  function parsePedidoText(text) {
    return parseWebV1(text) || parseBracketBlock(text);
  }

  function parsePedidoJson(obj) {
    if (!obj || typeof obj !== 'object') return null;
    if (obj.schema && obj.schema !== 'carnelandia.pedido.v1') return null;
    const orderId = normalizeOrderId(obj.orderId || obj.id);
    if (!isValidOrderId(orderId)) return null;
    const items = Array.isArray(obj.items)
      ? obj.items
          .map((it) => {
            if (typeof it === 'string') return it.trim();
            if (it && it.line) return String(it.line).trim();
            if (it && (it.qty || it.name))
              return [it.qty, it.name].filter(Boolean).join(' ').trim();
            return '';
          })
          .filter(Boolean)
      : [];
    return {
      orderId,
      customerName: String(obj.customerName || obj.cliente || '').trim(),
      address: String(obj.address || obj.direccion || '').trim(),
      items,
      notes: String(obj.notes || obj.aclaraciones || '').trim(),
      raw: JSON.stringify(obj),
      schema: 'carnelandia.pedido.v1',
      source: obj.source || 'json',
    };
  }

  function pedidoToMessages(pedido) {
    const msgs = [];
    if (pedido.customerName) {
      msgs.push({ id: 'nombre', text: 'Nombre: ' + pedido.customerName });
    }
    if (pedido.address) {
      msgs.push({ id: 'dir', text: 'Dirección: ' + pedido.address });
    }
    if (pedido.items && pedido.items.length) {
      msgs.push({ id: 'items', text: pedido.items.join('\n') });
    }
    if (pedido.notes) {
      msgs.push({ id: 'notas', text: 'Aclaración: ' + pedido.notes });
    }
    msgs.push({ id: 'oid', text: 'Pedido: ' + pedido.orderId });
    return msgs;
  }

  const PedidoFormat = {
    MARK_START,
    MARK_END,
    WEB_MARKER,
    normalizeOrderId,
    isValidOrderId,
    parsePedidoText,
    parsePedidoJson,
    pedidoToMessages,
  };

  root.PedidoFormat = PedidoFormat;
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = PedidoFormat;
  }
})(typeof globalThis !== 'undefined' ? globalThis : this);
