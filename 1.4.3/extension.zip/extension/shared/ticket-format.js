/**
 * Formato de comanda térmica — lógica reutilizable (web / futuro móvil).
 * No inventa datos ni modifica el chat: solo formatea el texto seleccionado para imprimir.
 * Impresión: MAYÚSCULAS (es-AR), fondo blanco / texto negro (en el renderizador).
 */
(function (root) {
  'use strict';

  const C = root.CARNELANDIA || {};

  /** ~3 mm entre productos en tipografía grande (~14–16 pt). */
  const PRODUCT_GAP_MM = 3;

  function toPrintUpper(text) {
    return String(text || '').toLocaleUpperCase('es-AR');
  }

  function padCenter(text, width) {
    const t = String(text || '');
    if (t.length >= width) return t.slice(0, width);
    const left = Math.floor((width - t.length) / 2);
    return ' '.repeat(left) + t + ' '.repeat(width - t.length - left);
  }

  function rule(width, char) {
    // ASCII: térmicas Generic/Text Only suelen fallar con ─/box-drawing.
    return (char || '-').repeat(width);
  }

  function wrapLine(text, width) {
    const raw = String(text || '').replace(/\r\n/g, '\n').replace(/\r/g, '\n');
    const out = [];
    for (const paragraph of raw.split('\n')) {
      if (paragraph.length === 0) {
        out.push('');
        continue;
      }
      let remaining = paragraph;
      while (remaining.length > width) {
        let breakAt = remaining.lastIndexOf(' ', width);
        if (breakAt < Math.floor(width * 0.4)) breakAt = width;
        out.push(remaining.slice(0, breakAt).trimEnd());
        remaining = remaining.slice(breakAt).trimStart();
      }
      if (remaining.length) out.push(remaining);
    }
    return out;
  }

  function detectPriceLines(messages) {
    const re = C.PRICE_LINE_RE || /\$/;
    const hits = [];
    messages.forEach((msg, msgIndex) => {
      const lines = String(msg.text || '').split(/\n/);
      lines.forEach((line, lineIndex) => {
        if (re.test(line)) {
          hits.push({
            id: `${msg.id || msgIndex}:${lineIndex}`,
            msgId: msg.id || String(msgIndex),
            msgIndex,
            lineIndex,
            text: line,
            excluded: false,
          });
        }
      });
    });
    return hits;
  }

  function applyPriceExclusions(messages, priceLines) {
    const excluded = new Set(
      (priceLines || []).filter((p) => p.excluded).map((p) => p.id)
    );
    if (excluded.size === 0) {
      return messages.map((m) => ({ ...m, text: String(m.text || '') }));
    }
    return messages.map((msg, msgIndex) => {
      const mid = msg.id || String(msgIndex);
      const lines = String(msg.text || '').split(/\n/);
      const kept = lines.filter((line, lineIndex) => {
        const id = `${mid}:${lineIndex}`;
        return !excluded.has(id);
      });
      return { ...msg, text: kept.join('\n') };
    });
  }

  function looksLikeQtyProduct(line) {
    return /^\s*\d+([.,]\d+)?\s*(kg|g|gr|gramos?|un\.?|u\.?|unidades?|x)?\b/i.test(
      line.trim()
    );
  }

  function looksLikeName(line) {
    return /^\s*nombre\s*[:：]/i.test(line) || /^\s*cliente\s*[:：]/i.test(line);
  }

  function looksLikeAddress(line) {
    return /^\s*(direcci[oó]n|domicilio|dir\.?)\s*[:：]/i.test(line);
  }

  function looksLikeNote(line) {
    return /^\s*(aclaraci[oó]n|nota|obs\.?|observaci[oó]n|sin\s+|por\s+favor)\b/i.test(
      line.trim()
    );
  }

  /**
   * Estilo visual pedido: "1 kg vacío" → "1 KG DE VACÍO".
   * No cambia cantidades ni inventa cortes; solo tipografía de comanda.
   */
  function formatProductPhrase(raw) {
    let s = String(raw || '').trim().replace(/\s+/g, ' ');
    if (!s) return '';
    // "Vacío x1kg" / "Bondiola x500g" (Pedix) → cantidad primero
    let m = s.match(/^(.+?)\s*[x×]\s*(\d+(?:[.,]\d+)?)\s*(kg|g|gr|gramos?)?\s*$/i);
    if (m) {
      const name = m[1].trim();
      const qty = m[2];
      const unit = (m[3] || '').toLowerCase();
      if (unit) s = `${qty} ${unit} ${name}`;
      else s = `${qty} ${name}`;
    }
    m = s.match(
      /^(\d+(?:[.,]\d+)?)\s*(kg|g|gr|gramos?)\s+(?:de\s+)?(.+)$/i
    );
    if (m) {
      const unit = m[2].toLowerCase().startsWith('kg')
        ? 'KG'
        : m[2].toLowerCase().startsWith('gr')
          ? 'G'
          : 'G';
      return toPrintUpper(`${m[1]} ${unit} DE ${m[3]}`);
    }
    return toPrintUpper(s);
  }

  /**
   * Parte el texto seleccionado en bloques (nombre, dirección, productos, notas).
   * Separadores explícitos · | ; no adivina productos mezclados en prosa libre.
   */
  function extractBlocks(messages) {
    const blocks = [];
    const rawLines = [];

    (messages || []).forEach((msg) => {
      String(msg.text || '')
        .replace(/\r\n/g, '\n')
        .replace(/\r/g, '\n')
        .split('\n')
        .forEach((line) => {
          const t = line.trim();
          if (t) rawLines.push(t);
        });
    });

    rawLines.forEach((line) => {
      if (looksLikeName(line)) {
        const rest = line.replace(/^\s*(nombre|cliente)\s*[:：]\s*/i, '').trim();
        blocks.push({
          role: 'name',
          lines: [toPrintUpper(rest ? `NOMBRE: ${rest}` : line)],
          gapAfterMm: 2,
        });
        return;
      }
      if (looksLikeAddress(line)) {
        const rest = line
          .replace(/^\s*(direcci[oó]n|domicilio|dir\.?)\s*[:：]\s*/i, '')
          .trim();
        const body = rest ? `DIRECCIÓN: ${rest}` : line;
        blocks.push({
          role: 'address',
          lines: [toPrintUpper(body)],
          gapAfterMm: 3,
        });
        return;
      }

      // Varios productos en un renglón separados por · o |
      if (/[·|]/.test(line) && looksLikeQtyProduct(line.split(/[·|]/)[0])) {
        const parts = line
          .split(/[·|]/)
          .map((p) => p.trim())
          .filter(Boolean);
        parts.forEach((part, idx) => {
          if (looksLikeNote(part) && blocks.length) {
            const prev = blocks[blocks.length - 1];
            if (prev.role === 'product') {
              prev.lines.push(toPrintUpper(part));
              return;
            }
          }
          blocks.push({
            role: 'product',
            lines: [formatProductPhrase(part)],
            gapAfterMm: PRODUCT_GAP_MM,
          });
          if (idx === parts.length - 1) {
            /* gap already set */
          }
        });
        return;
      }

      if (looksLikeNote(line) && blocks.length) {
        const prev = blocks[blocks.length - 1];
        if (prev.role === 'product' || prev.role === 'address') {
          prev.lines.push(toPrintUpper(line));
          return;
        }
      }

      if (looksLikeQtyProduct(line)) {
        // Posible "producto + aclaración" en la misma línea tras punto
        const noteSplit = line.match(/^(.*?)[.]\s+(Aclaraci[oó]n[:\s].+)$/i);
        if (noteSplit) {
          blocks.push({
            role: 'product',
            lines: [
              formatProductPhrase(noteSplit[1]),
              toPrintUpper(noteSplit[2]),
            ],
            gapAfterMm: PRODUCT_GAP_MM,
          });
          return;
        }
        blocks.push({
          role: 'product',
          lines: [formatProductPhrase(line)],
          gapAfterMm: PRODUCT_GAP_MM,
        });
        return;
      }

      // Resumen Pedix u otras líneas: mayúsculas, sin inventar estructura
      if (/^resumen\b/i.test(line)) {
        blocks.push({
          role: 'section',
          lines: [toPrintUpper(line)],
          gapAfterMm: 2,
        });
        return;
      }

      blocks.push({
        role: 'body',
        lines: [toPrintUpper(line)],
        gapAfterMm: 1.5,
      });
    });

    return blocks;
  }

  function rewrapBlocks(blocks, width) {
    return blocks.map((b) => {
      const wrapped = [];
      b.lines.forEach((ln) => {
        wrapLine(ln, width).forEach((w) => wrapped.push(w));
      });
      return { ...b, lines: wrapped };
    });
  }

  /**
   * Genera una copia de comanda.
   * `lines` estructuradas alimentan PDF/GDI; `text` es fallback legible.
   */
  function formatTicket(opts) {
    const widthMm = opts.paperWidthMm === 58 ? 58 : 80;
    const width =
      (C.CHARS_PER_LINE && C.CHARS_PER_LINE[widthMm]) || (widthMm === 58 ? 24 : 32);
    const copyType = toPrintUpper(opts.copyType || 'PREPARACIÓN');
    const ticketNumber = String(opts.ticketNumber || '0000');
    const isReprint = !!opts.isReprint;
    const when = opts.printedAt ? new Date(opts.printedAt) : new Date();
    const dateStr = toPrintUpper(
      when.toLocaleString('es-AR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      })
    );

    /** @type {Array<{text:string,role:string,gapAfterMm:number,bold?:boolean,size?:string}>} */
    const structured = [];

    function pushMeta(text, role, optsLine) {
      wrapLine(text, width).forEach((w, i, arr) => {
        structured.push({
          text: w,
          role: role || 'meta',
          gapAfterMm: i === arr.length - 1 ? (optsLine && optsLine.gapAfterMm) || 0.8 : 0,
          bold: !optsLine || optsLine.bold !== false,
          size: (optsLine && optsLine.size) || 'normal',
        });
      });
    }

    pushMeta(padCenter('CARNELANDIA', width), 'brand', { size: 'title', gapAfterMm: 0.5 });
    pushMeta(padCenter('COMANDA', width), 'brand', { size: 'title', gapAfterMm: 1 });
    pushMeta(rule(width, '='), 'rule', { bold: false, gapAfterMm: 1 });

    if (isReprint) {
      pushMeta(padCenter('*** REIMPRESIÓN ***', width), 'alert', {
        size: 'large',
        gapAfterMm: 1,
      });
      pushMeta(rule(width, '='), 'rule', { bold: false, gapAfterMm: 1 });
    }

    pushMeta(padCenter(copyType, width), 'copy', { size: 'large', gapAfterMm: 0.5 });
    pushMeta(padCenter(`Nº ${ticketNumber}`, width), 'copy', {
      size: 'large',
      gapAfterMm: 1,
    });
    pushMeta(dateStr, 'meta', { bold: false, gapAfterMm: 0.5 });
    if (opts.contactName) {
      pushMeta(toPrintUpper(`CHAT: ${opts.contactName}`), 'meta', {
        bold: false,
        gapAfterMm: 1,
      });
    }
    pushMeta(rule(width, '-'), 'rule', { bold: false, gapAfterMm: 2 });

    const blocks = rewrapBlocks(extractBlocks(opts.messages || []), width);
    blocks.forEach((b, bi) => {
      b.lines.forEach((ln, li) => {
        const isLast = li === b.lines.length - 1;
        structured.push({
          text: ln,
          role: b.role,
          gapAfterMm: isLast ? b.gapAfterMm || PRODUCT_GAP_MM : 0,
          bold: b.role === 'name' || b.role === 'address' || b.role === 'product',
          size:
            b.role === 'name' || b.role === 'address'
              ? 'large'
              : b.role === 'product'
                ? 'product'
                : 'normal',
        });
      });
      if (bi === blocks.length - 1 && structured.length) {
        // último bloque: un poco menos de aire antes del pie
        structured[structured.length - 1].gapAfterMm = 2;
      }
    });

    pushMeta(rule(width, '='), 'rule', { bold: false, gapAfterMm: 1 });
    pushMeta(padCenter('FIN COMANDA', width), 'footer', { gapAfterMm: 2 });

    // Texto plano: líneas en blanco aproximan ~3 mm entre productos
    const textLines = [];
    structured.forEach((row) => {
      textLines.push(row.text);
      if (row.gapAfterMm >= PRODUCT_GAP_MM - 0.2) {
        textLines.push('');
      }
    });

    return {
      widthMm,
      charsPerLine: width,
      copyType,
      ticketNumber,
      isReprint,
      lines: structured,
      text: textLines.join('\n'),
      protocolVersion: (C.PROTOCOL_VERSION != null ? C.PROTOCOL_VERSION : 1),
    };
  }

  function nextTicketNumber(last) {
    const n = (parseInt(last, 10) || 0) + 1;
    return String(n).padStart(4, '0');
  }

  function buildPrintJob(opts) {
    const filtered = applyPriceExclusions(opts.messages || [], opts.priceLines || []);
    const ticketNumber = opts.ticketNumber || '0001';
    const common = {
      messages: filtered,
      ticketNumber,
      paperWidthMm: opts.paperWidthMm,
      isReprint: opts.isReprint,
      contactName: opts.contactName,
      printedAt: opts.printedAt || new Date().toISOString(),
    };
    const prep = formatTicket({
      ...common,
      copyType: (C.COPY_TYPES && C.COPY_TYPES.PREPARACION) || 'PREPARACIÓN',
    });
    const control = formatTicket({
      ...common,
      copyType: (C.COPY_TYPES && C.COPY_TYPES.CONTROL) || 'CONTROL DE CAJA',
    });
    return {
      ticketNumber,
      paperWidthMm: common.paperWidthMm,
      isReprint: !!opts.isReprint,
      copies: [prep, control],
      demoMode: !!opts.demoMode,
      printerName: opts.printerName || null,
      protocolVersion: C.PROTOCOL_VERSION != null ? C.PROTOCOL_VERSION : 1,
    };
  }

  /** HTML de vista previa que refleja roles (fondo blanco / negro). */
  function renderPreviewHtml(ticket) {
    const rows = ticket.lines || [];
    const parts = rows.map((row) => {
      const cls = ['cl-tline', `cl-role-${row.role || 'body'}`];
      if (row.size) cls.push(`cl-size-${row.size}`);
      if (row.bold) cls.push('cl-bold');
      const gap =
        row.gapAfterMm >= 2.5
          ? 'cl-gap-product'
          : row.gapAfterMm >= 1.5
            ? 'cl-gap-md'
            : '';
      if (gap) cls.push(gap);
      const safe = String(row.text || '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
      return `<div class="${cls.join(' ')}">${safe || '&nbsp;'}</div>`;
    });
    return `<div class="cl-ticket-sheet" data-width="${ticket.widthMm}">${parts.join('')}</div>`;
  }

  const TicketFormat = {
    PRODUCT_GAP_MM,
    toPrintUpper,
    padCenter,
    rule,
    wrapLine,
    detectPriceLines,
    applyPriceExclusions,
    formatProductPhrase,
    extractBlocks,
    formatTicket,
    nextTicketNumber,
    buildPrintJob,
    renderPreviewHtml,
  };

  root.TicketFormat = TicketFormat;
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = TicketFormat;
  }
})(typeof globalThis !== 'undefined' ? globalThis : this);
