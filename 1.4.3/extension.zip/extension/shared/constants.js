/**
 * Constantes compartidas — Carnelandia Comandas
 */
(function (root) {
  'use strict';

  const CARNELANDIA = {
    APP_NAME: 'Carnelandia Comandas',
    VERSION: '1.4.3',
    PROTOCOL_VERSION: 2,
    PROTOCOL_VERSION_MIN: 1,
    PROTOCOL_VERSION_MAX: 2,
    NATIVE_HOST_NAME: 'com.carnelandia.comandas',
    AGENT_BASE_URL: 'http://127.0.0.1:17355',

    COPY_TYPES: {
      PREPARACION: 'PREPARACIÓN',
      CONTROL: 'CONTROL DE CAJA',
    },

    PAPER_WIDTHS_MM: { 58: 58, 80: 80 },
    CHARS_PER_LINE: { 58: 24, 80: 32 },

    STORAGE_KEYS: {
      PAPER_WIDTH: 'paperWidthMm',
      PRINTER_NAME: 'printerName',
      DEMO_MODE: 'demoMode',
      EXTENSION_ID: 'extensionId',
      LAST_TICKET_NUMBER: 'lastTicketNumber',
      AUTO_PRINT: 'autoPrintEnabled',
      PRINTED_ORDERS: 'printedOrderIds',
      PENDING_ORDERS: 'pendingOrders',
      UNCERTAIN_ORDERS: 'uncertainOrders',
      PRINT_LOCK: 'printLock',
      UPDATE_CHANNEL: 'updateChannelUrl',
    },

    DEFAULTS: {
      paperWidthMm: 80,
      demoMode: false,
      autoPrintEnabled: true,
    },

    PRICE_LINE_RE:
      /(?:\$\s*\d|\d+[.,]\d{2}\s*(?:\$|pesos)?|\bprecio\b|\btotal\b|\bsubtotal\b)/i,

    STATUS: {
      IDLE: 'idle',
      SELECTING: 'selecting',
      PREVIEW: 'preview',
      SENDING: 'sending',
      QUEUED: 'queued',
      ERROR: 'error',
      HOST_UNAVAILABLE: 'host_unavailable',
      PRINTER_UNAVAILABLE: 'printer_unavailable',
    },
  };

  root.CARNELANDIA = CARNELANDIA;
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = CARNELANDIA;
  }
})(typeof globalThis !== 'undefined' ? globalThis : this);
