/**
 * Service worker MV3 — Native Messaging + agente HTTP local.
 * Demo y impresión real separados. Autoimpresión vía agente (dedupe autoritativo).
 */
importScripts('../shared/constants.js');

const C = self.CARNELANDIA;
const HOST = C.NATIVE_HOST_NAME;
const AGENT = C.AGENT_BASE_URL;

function protocolCompatible(hostVersion) {
  const v = parseInt(hostVersion, 10);
  if (Number.isNaN(v)) {
    return {
      ok: false,
      message:
        'El componente nativo no informa versión de protocolo. Reinstalá el host con el instalador Windows/Mac.',
    };
  }
  if (v < C.PROTOCOL_VERSION_MIN || v > C.PROTOCOL_VERSION_MAX) {
    return {
      ok: false,
      message: `Protocolo incompatible: la extensión espera ${C.PROTOCOL_VERSION_MIN}–${C.PROTOCOL_VERSION_MAX} y el componente tiene ${v}. Actualizar la extensión NO actualiza el componente nativo.`,
    };
  }
  return { ok: true };
}

function mapCopies(job) {
  return (job.copies || []).map((c) => ({
    copyType: c.copyType,
    text: c.text,
    widthMm: c.widthMm || job.paperWidthMm,
    lines: c.lines || null,
  }));
}

function nativeSend(message) {
  const payload = {
    ...message,
    protocolVersion: C.PROTOCOL_VERSION,
    extensionVersion: C.VERSION,
  };
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendNativeMessage(HOST, payload, (response) => {
        if (chrome.runtime.lastError) {
          resolve({
            ok: false,
            code: 'host_unavailable',
            message:
              chrome.runtime.lastError.message ||
              'No se pudo contactar al componente nativo (Native Messaging).',
          });
          return;
        }
        const res =
          response || { ok: false, code: 'error', message: 'Respuesta vacía del host' };
        if (res.ok && res.protocolVersion != null) {
          const check = protocolCompatible(res.protocolVersion);
          if (!check.ok) {
            resolve({
              ok: false,
              code: 'protocol_mismatch',
              message: check.message,
              protocolVersion: res.protocolVersion,
            });
            return;
          }
        }
        resolve(res);
      });
    } catch (e) {
      resolve({ ok: false, code: 'host_unavailable', message: String(e) });
    }
  });
}

async function agentFetch(path, options) {
  const url = AGENT + path;
  try {
    const res = await fetch(url, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(options && options.headers),
      },
    });
    const data = await res.json().catch(() => ({}));
    return { httpStatus: res.status, ...data };
  } catch (e) {
    return {
      ok: false,
      code: 'agent_unavailable',
      message:
        'Agente local no responde en ' +
        AGENT +
        '. Ejecutá start_agent.bat (o el instalador). Sin agente no hay autoimpresión en chats cerrados. ' +
        String(e.message || e),
    };
  }
}

function hostMissingMessage(forDemo) {
  if (forDemo) {
    return {
      ok: true,
      outcome: 'demo_saved',
      demoOnly: true,
      message:
        'SIMULACIÓN LOCAL (sin componente nativo). No se envió nada a ninguna impresora.',
    };
  }
  return {
    ok: false,
    code: 'host_unavailable',
    message:
      'Falta el componente nativo de impresión. En la PC Windows del local ejecutá install.bat del paquete Carnelandia, reiniciá Chrome y desactivá el modo demo. Sin ese componente no se puede imprimir de verdad.',
  };
}

async function handlePrint(payload) {
  const job = payload?.job;
  if (!job || !Array.isArray(job.copies) || job.copies.length === 0) {
    return { ok: false, code: 'error', message: 'Trabajo de impresión inválido' };
  }

  const stored = await chrome.storage.local.get([
    C.STORAGE_KEYS.DEMO_MODE,
    C.STORAGE_KEYS.PRINTER_NAME,
    C.STORAGE_KEYS.PAPER_WIDTH,
    C.STORAGE_KEYS.PRINT_LOCK,
  ]);

  const demoMode =
    stored[C.STORAGE_KEYS.DEMO_MODE] !== undefined
      ? !!stored[C.STORAGE_KEYS.DEMO_MODE]
      : job.demoMode !== undefined
        ? !!job.demoMode
        : C.DEFAULTS.demoMode;

  const printerName = stored[C.STORAGE_KEYS.PRINTER_NAME] || job.printerName || null;

  if (!demoMode && !printerName) {
    return {
      ok: false,
      code: 'printer_unavailable',
      message:
        'No hay impresora elegida. Abrí el popup de Carnelandia → Actualizar lista → elegí «Generic / Text Only» (u otra) → desactivá modo demo.',
    };
  }

  // Candado multi-pestaña (manual): evita doble envío del mismo trabajo
  const lock = stored[C.STORAGE_KEYS.PRINT_LOCK];
  const now = Date.now();
  if (lock && lock.until > now && lock.fingerprint === job.orderId) {
    return {
      ok: false,
      code: 'error',
      message: 'Otra pestaña está imprimiendo este pedido.',
    };
  }
  if (job.orderId) {
    await chrome.storage.local.set({
      [C.STORAGE_KEYS.PRINT_LOCK]: {
        fingerprint: job.orderId,
        until: now + 20000,
      },
    });
  }

  const base = {
    action: 'print',
    demoMode,
    printerName,
    paperWidthMm: stored[C.STORAGE_KEYS.PAPER_WIDTH] || job.paperWidthMm || 80,
    ticketNumber: job.ticketNumber,
    isReprint: !!job.isReprint,
    orderId: job.orderId || null,
    copies: mapCopies(job),
    cutBetweenCopies: true,
  };

  const response = await nativeSend(base);

  if (job.orderId) {
    await chrome.storage.local.remove(C.STORAGE_KEYS.PRINT_LOCK);
  }

  if (response.code === 'host_unavailable') {
    return hostMissingMessage(demoMode);
  }

  if (demoMode && response.ok) {
    return {
      ...response,
      outcome: 'demo_saved',
      demoOnly: true,
      message:
        (response.message || 'Demo en componente nativo') +
        ' — NO es impresión física.',
    };
  }

  return response;
}

async function rememberPrinted(orderId, meta) {
  if (!orderId) return;
  const data = await chrome.storage.local.get([C.STORAGE_KEYS.PRINTED_ORDERS]);
  const map = data[C.STORAGE_KEYS.PRINTED_ORDERS] || {};
  map[orderId] = meta || { at: new Date().toISOString() };
  // Cap tamaño
  const keys = Object.keys(map);
  if (keys.length > 500) {
    keys
      .sort((a, b) => String(map[a].at || '').localeCompare(String(map[b].at || '')))
      .slice(0, keys.length - 400)
      .forEach((k) => delete map[k]);
  }
  await chrome.storage.local.set({ [C.STORAGE_KEYS.PRINTED_ORDERS]: map });
}

async function handleAgentOrder(pedido) {
  if (!pedido || !pedido.orderId) {
    return { ok: false, message: 'Pedido inválido' };
  }
  const stored = await chrome.storage.local.get([
    C.STORAGE_KEYS.AUTO_PRINT,
    C.STORAGE_KEYS.PRINTED_ORDERS,
    C.STORAGE_KEYS.DEMO_MODE,
  ]);
  const printed = stored[C.STORAGE_KEYS.PRINTED_ORDERS] || {};
  if (printed[pedido.orderId]) {
    return { ok: true, outcome: 'duplicate', orderId: pedido.orderId };
  }
  const auto =
    stored[C.STORAGE_KEYS.AUTO_PRINT] !== undefined
      ? !!stored[C.STORAGE_KEYS.AUTO_PRINT]
      : C.DEFAULTS.autoPrintEnabled;
  if (!auto) {
    return {
      ok: true,
      outcome: 'pending',
      message: 'Autoimpresión desactivada; use impresión manual o active el interruptor.',
      orderId: pedido.orderId,
    };
  }
  if (stored[C.STORAGE_KEYS.DEMO_MODE]) {
    return {
      ok: false,
      outcome: 'pending',
      message: 'Modo demo activo: autoimpresión real bloqueada.',
    };
  }

  const body = {
    schema: 'carnelandia.pedido.v1',
    orderId: pedido.orderId,
    customerName: pedido.customerName || '',
    address: pedido.address || '',
    items: pedido.items || [],
    notes: pedido.notes || '',
    source: pedido.source || 'extension',
  };
  const res = await agentFetch('/v1/orders', {
    method: 'POST',
    body: JSON.stringify(body),
  });
  if (res.outcome === 'queued' || res.outcome === 'duplicate') {
    await rememberPrinted(pedido.orderId, {
      at: new Date().toISOString(),
      outcome: res.outcome,
    });
  }
  return res;
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || message.type !== 'CARNELANDIA_PRINT') return false;
  handlePrint(message.payload)
    .then(sendResponse)
    .catch((e) =>
      sendResponse({ ok: false, code: 'error', message: String(e) })
    );
  return true;
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(
    [
      C.STORAGE_KEYS.DEMO_MODE,
      C.STORAGE_KEYS.PAPER_WIDTH,
      C.STORAGE_KEYS.PRINTER_NAME,
      C.STORAGE_KEYS.AUTO_PRINT,
    ],
    (data) => {
      const patch = {};
      if (data[C.STORAGE_KEYS.DEMO_MODE] === undefined) {
        patch[C.STORAGE_KEYS.DEMO_MODE] = C.DEFAULTS.demoMode;
      }
      if (data[C.STORAGE_KEYS.PAPER_WIDTH] === undefined) {
        patch[C.STORAGE_KEYS.PAPER_WIDTH] = C.DEFAULTS.paperWidthMm;
      }
      if (data[C.STORAGE_KEYS.AUTO_PRINT] === undefined) {
        patch[C.STORAGE_KEYS.AUTO_PRINT] = C.DEFAULTS.autoPrintEnabled;
      }
      if (Object.keys(patch).length) chrome.storage.local.set(patch);
    }
  );
});

function withHostGuard(response, offlineMsg) {
  if (response && response.code === 'host_unavailable') {
    return {
      ok: false,
      code: 'host_unavailable',
      message: offlineMsg,
    };
  }
  if (response && response.ok && response.protocolVersion == null) {
    return {
      ok: false,
      code: 'protocol_mismatch',
      message: 'Host antiguo sin protocolVersion. Reinstalá el componente nativo.',
    };
  }
  return response;
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === 'CARNELANDIA_PING_HOST') {
    nativeSend({ action: 'ping' }).then((response) => {
      sendResponse(
        withHostGuard(
          response,
          'Componente nativo no instalado o Chrome no lo encuentra. Ejecutá VALIDAR.bat / install.bat y reiniciá Chrome.'
        )
      );
    });
    return true;
  }
  if (message?.type === 'CARNELANDIA_LIST_PRINTERS') {
    nativeSend({ action: 'list_printers' }).then((response) => {
      sendResponse(
        withHostGuard(
          response,
          'Sin componente nativo: no se pueden listar impresoras del sistema.'
        )
      );
    });
    return true;
  }
  if (message?.type === 'CARNELANDIA_SELF_CHECK') {
    nativeSend({ action: 'self_check' }).then((response) => {
      sendResponse(
        withHostGuard(response, 'Sin componente nativo: self_check imposible.')
      );
    });
    return true;
  }
  if (message?.type === 'CARNELANDIA_TEST_PRINT') {
    chrome.storage.local.get(
      [C.STORAGE_KEYS.DEMO_MODE, C.STORAGE_KEYS.PRINTER_NAME, C.STORAGE_KEYS.PAPER_WIDTH],
      (stored) => {
        if (stored[C.STORAGE_KEYS.DEMO_MODE]) {
          sendResponse({
            ok: false,
            code: 'error',
            message:
              'Modo demo activo: la prueba de cola esta bloqueada. Desactiva el demo en el popup.',
          });
          return;
        }
        const printer = stored[C.STORAGE_KEYS.PRINTER_NAME] || message.printerName || null;
        if (!printer) {
          sendResponse({
            ok: false,
            code: 'printer_unavailable',
            message: 'Elegí una impresora antes de la prueba de cola.',
          });
          return;
        }
        nativeSend({
          action: 'test_print',
          printerName: printer,
          paperWidthMm: stored[C.STORAGE_KEYS.PAPER_WIDTH] || 80,
        }).then((response) => {
          sendResponse(
            withHostGuard(
              response,
              'Sin componente nativo: no se puede enviar prueba a la cola.'
            )
          );
        });
      }
    );
    return true;
  }
  if (message?.type === 'CARNELANDIA_SET_AUTO_PRINT') {
    const enabled = !!message.enabled;
    chrome.storage.local.set({ [C.STORAGE_KEYS.AUTO_PRINT]: enabled }, () => {
      agentFetch('/v1/auto', {
        method: 'POST',
        body: JSON.stringify({ enabled }),
      }).then((res) => {
        sendResponse({ ok: true, autoPrintEnabled: enabled, agent: res });
      });
    });
    return true;
  }
  if (message?.type === 'CARNELANDIA_AGENT_ORDER') {
    handleAgentOrder(message.pedido).then(sendResponse);
    return true;
  }
  if (message?.type === 'CARNELANDIA_AGENT_STATUS') {
    agentFetch('/v1/status', { method: 'GET' }).then(sendResponse);
    return true;
  }
  if (message?.type === 'CARNELANDIA_CHECK_UPDATES') {
    nativeSend({ action: 'check_updates' }).then(sendResponse);
    return true;
  }
  return false;
});

// Sincronizar toggle con agente al despertar
chrome.alarms.create('carnelandia-sync-auto', { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name !== 'carnelandia-sync-auto') return;
  chrome.storage.local.get([C.STORAGE_KEYS.AUTO_PRINT], (data) => {
    const enabled =
      data[C.STORAGE_KEYS.AUTO_PRINT] !== undefined
        ? !!data[C.STORAGE_KEYS.AUTO_PRINT]
        : C.DEFAULTS.autoPrintEnabled;
    agentFetch('/v1/auto', {
      method: 'POST',
      body: JSON.stringify({ enabled }),
    }).catch(() => {});
  });
});
