/**
 * Content script — WhatsApp Web / página demo.
 * Orquesta selección, preview e impresión. No modifica conversaciones.
 */
(function () {
  'use strict';

  const S = globalThis.WhatsAppSelectors;
  const TF = globalThis.TicketFormat;
  const C = globalThis.CARNELANDIA;
  const PF = globalThis.PedidoFormat;

  if (!S || !TF || !C) {
    console.error('[Carnelandia] Faltan módulos compartidos');
    return;
  }

  const state = {
    selecting: false,
    selected: new Map(), // id -> { id, text, order }
    conversationKey: null,
    printInFlight: false,
    lastPrintedKey: null,
    lastPrintedAt: 0,
    settings: {
      paperWidthMm: C.DEFAULTS.paperWidthMm,
      demoMode: C.DEFAULTS.demoMode,
      printerName: null,
      autoPrintEnabled: C.DEFAULTS.autoPrintEnabled,
    },
    /** orderIds vistos al iniciar / al activar auto: no se imprimen (evita histórico) */
    baselineOrderIds: new Set(),
    submittedOrderIds: new Set(),
    autoScanReady: false,
    observer: null,
    convObserver: null,
    autoObserver: null,
  };

  function isDemoPage() {
    return document.documentElement.hasAttribute('data-carnelandia-demo');
  }

  function loadSettings() {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get(
          [
            C.STORAGE_KEYS.PAPER_WIDTH,
            C.STORAGE_KEYS.DEMO_MODE,
            C.STORAGE_KEYS.PRINTER_NAME,
            C.STORAGE_KEYS.LAST_TICKET_NUMBER,
            C.STORAGE_KEYS.AUTO_PRINT,
            C.STORAGE_KEYS.PRINTED_ORDERS,
          ],
          (data) => {
            state.settings.paperWidthMm =
              data[C.STORAGE_KEYS.PAPER_WIDTH] || C.DEFAULTS.paperWidthMm;
            state.settings.demoMode =
              data[C.STORAGE_KEYS.DEMO_MODE] !== undefined
                ? !!data[C.STORAGE_KEYS.DEMO_MODE]
                : C.DEFAULTS.demoMode;
            state.settings.printerName = data[C.STORAGE_KEYS.PRINTER_NAME] || null;
            state.settings.autoPrintEnabled =
              data[C.STORAGE_KEYS.AUTO_PRINT] !== undefined
                ? !!data[C.STORAGE_KEYS.AUTO_PRINT]
                : C.DEFAULTS.autoPrintEnabled;
            state.lastTicketNumber = data[C.STORAGE_KEYS.LAST_TICKET_NUMBER] || '0000';
            const printed = data[C.STORAGE_KEYS.PRINTED_ORDERS] || {};
            Object.keys(printed).forEach((id) => state.submittedOrderIds.add(id));
            resolve();
          }
        );
      } catch (e) {
        state.lastTicketNumber = '0000';
        resolve();
      }
    });
  }

  function persistAutoPrint(enabled) {
    state.settings.autoPrintEnabled = !!enabled;
    try {
      chrome.storage.local.set({ [C.STORAGE_KEYS.AUTO_PRINT]: !!enabled });
    } catch (_) {
      /* demo sin storage */
    }
    try {
      chrome.runtime.sendMessage({
        type: 'CARNELANDIA_SET_AUTO_PRINT',
        enabled: !!enabled,
      });
    } catch (_) {
      /* ignore */
    }
    updateAutoToggleUi();
  }

  function saveLastTicket(num) {
    state.lastTicketNumber = num;
    try {
      chrome.storage.local.set({ [C.STORAGE_KEYS.LAST_TICKET_NUMBER]: num });
    } catch (_) {
      /* popup/demo sin chrome.storage en file:// */
    }
  }

  /* ---------- Toolbar ---------- */

  function ensureToolbar() {
    let bar = document.getElementById('carnelandia-toolbar');
    if (bar) return bar;

    bar = document.createElement('div');
    bar.id = 'carnelandia-toolbar';
    bar.innerHTML = `
      <span class="cl-brand">Carnelandia</span>
      <button type="button" id="cl-btn-auto" class="cl-auto" aria-pressed="true">Impresión automática activada</button>
      <button type="button" id="cl-btn-select">Seleccionar pedido</button>
      <button type="button" id="cl-btn-preview" class="cl-secondary" disabled>Vista previa</button>
      <button type="button" id="cl-btn-cancel" class="cl-danger" hidden>Cancelar selección</button>
      <span class="cl-status" id="cl-status"></span>
      <span class="cl-hint" id="cl-hint">Manual: seleccioná mensajes. Auto: cola remota Pedidos (2 copias). WhatsApp visible no reimprime el mismo ID.</span>
    `;

    const mount = findToolbarMount();
    mount.prepend(bar);

    bar.querySelector('#cl-btn-select').addEventListener('click', toggleSelecting);
    bar.querySelector('#cl-btn-preview').addEventListener('click', openPreview);
    bar.querySelector('#cl-btn-cancel').addEventListener('click', () => stopSelecting(true));
    bar.querySelector('#cl-btn-auto').addEventListener('click', () => {
      const next = !state.settings.autoPrintEnabled;
      if (next) {
        // Al activar: baseline = visibles actuales (no imprimir histórico de golpe)
        refreshBaselineFromVisible(true);
      }
      persistAutoPrint(next);
      setStatus(
        next
          ? 'Auto ON — solo pedidos nuevos (no histórico)'
          : 'Auto OFF — impresión manual disponible',
        next ? 'cl-ok' : 'cl-error'
      );
    });
    updateAutoToggleUi();

    return bar;
  }

  function updateAutoToggleUi() {
    const btn = document.getElementById('cl-btn-auto');
    if (!btn) return;
    const on = !!state.settings.autoPrintEnabled;
    btn.textContent = on
      ? 'Impresión automática activada'
      : 'Impresión automática desactivada';
    btn.classList.toggle('cl-auto-on', on);
    btn.classList.toggle('cl-auto-off', !on);
    btn.setAttribute('aria-pressed', on ? 'true' : 'false');
  }

  function findToolbarMount() {
    if (isDemoPage()) {
      return document.getElementById('carnelandia-demo-mount') || document.body;
    }
    const main = S.mainPanel();
    if (main && main.parentElement) {
      // Insertar encima del panel de chat sin alterar mensajes
      const existing = document.getElementById('carnelandia-toolbar-host');
      if (existing) return existing;
      const host = document.createElement('div');
      host.id = 'carnelandia-toolbar-host';
      main.parentElement.insertBefore(host, main);
      return host;
    }
    return document.body;
  }

  function setStatus(text, kind) {
    const el = document.getElementById('cl-status');
    if (!el) return;
    el.textContent = text || '';
    el.classList.remove('cl-error', 'cl-ok');
    if (kind) el.classList.add(kind);
  }

  function updateToolbar() {
    const btnSelect = document.getElementById('cl-btn-select');
    const btnPreview = document.getElementById('cl-btn-preview');
    const btnCancel = document.getElementById('cl-btn-cancel');
    if (!btnSelect) return;

    if (state.selecting) {
      btnSelect.textContent = 'Seleccionando…';
      btnCancel.hidden = false;
    } else {
      btnSelect.textContent = 'Seleccionar pedido';
      btnCancel.hidden = true;
    }
    btnPreview.disabled = state.selected.size === 0;
    const n = state.selected.size;
    if (state.selecting) {
      setStatus(n ? `${n} mensaje(s) marcado(s)` : 'Marcá los mensajes del pedido');
    }
  }

  /* ---------- Selección ---------- */

  function toggleSelecting() {
    if (state.selecting) {
      if (state.selected.size > 0) {
        openPreview();
      } else {
        stopSelecting(true);
      }
      return;
    }
    startSelecting();
  }

  function startSelecting() {
    if (!isDemoPage() && !S.hasOpenChat()) {
      setStatus('Abrí un chat primero', 'cl-error');
      return;
    }
    state.selecting = true;
    state.conversationKey = isDemoPage() ? 'demo' : S.conversationKey();
    injectCheckboxes();
    observeMessages();
    updateToolbar();
    setStatus('Marcá nombre, dirección, productos y aclaraciones');
  }

  function stopSelecting(clear) {
    state.selecting = false;
    if (clear) {
      state.selected.clear();
      removeCheckboxes();
    } else {
      // Mantener selección visual hasta preview cerrada
      document.querySelectorAll('.carnelandia-check-wrap input').forEach((cb) => {
        cb.disabled = true;
      });
    }
    if (state.observer) {
      state.observer.disconnect();
      state.observer = null;
    }
    updateToolbar();
  }

  function clearSelectionFull() {
    state.selected.clear();
    removeCheckboxes();
    state.selecting = false;
    updateToolbar();
    setStatus('Selección limpiada (cambio de chat)');
  }

  function removeCheckboxes() {
    document.querySelectorAll('.carnelandia-check-wrap').forEach((wrap) => {
      const node = wrap._clMessageNode;
      if (node && wrap.parentElement) {
        wrap.replaceWith(node);
      } else {
        wrap.remove();
      }
    });
  }

  function getMessageNodes() {
    if (isDemoPage()) {
      return Array.from(document.querySelectorAll('[data-cl-demo-msg]'));
    }
    return S.messageNodes();
  }

  function getMessageText(node) {
    if (isDemoPage()) {
      return (node.innerText || node.textContent || '').trim();
    }
    return S.messageText(node);
  }

  function getMessageId(node, index) {
    if (isDemoPage()) {
      return node.getAttribute('data-cl-demo-msg') || `demo:${index}`;
    }
    return S.messageId(node, index);
  }

  function injectCheckboxes() {
    const nodes = getMessageNodes();
    nodes.forEach((node, index) => {
      if (node.closest('.carnelandia-check-wrap')) return;
      if (node.parentElement?.classList?.contains('carnelandia-check-wrap')) return;

      const text = getMessageText(node);
      if (!text) return;

      const id = getMessageId(node, index);
      const wrap = document.createElement('div');
      wrap.className = 'carnelandia-check-wrap';
      wrap._clMessageNode = node;
      wrap.dataset.clMsgId = id;

      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.title = 'Incluir en la comanda';
      cb.checked = state.selected.has(id);
      if (cb.checked) wrap.classList.add('cl-selected');

      cb.addEventListener('change', () => {
        if (cb.checked) {
          state.selected.set(id, {
            id,
            text,
            order: index,
            rawOrder: Array.from(state.selected.keys()).length,
          });
          wrap.classList.add('cl-selected');
        } else {
          state.selected.delete(id);
          wrap.classList.remove('cl-selected');
        }
        updateToolbar();
      });

      const parent = node.parentElement;
      if (!parent) return;
      parent.insertBefore(wrap, node);
      wrap.appendChild(cb);
      wrap.appendChild(node);
    });
  }

  function observeMessages() {
    if (state.observer) state.observer.disconnect();
    const list = isDemoPage()
      ? document.getElementById('carnelandia-demo-messages')
      : S.messageList();
    if (!list) return;
    state.observer = new MutationObserver(() => {
      if (state.selecting) injectCheckboxes();
    });
    state.observer.observe(list, { childList: true, subtree: true });
  }

  function watchConversationChanges() {
    if (isDemoPage()) return;
    const tick = () => {
      if (!state.selecting && state.selected.size === 0) {
        state.conversationKey = S.conversationKey();
        return;
      }
      const key = S.conversationKey();
      if (state.conversationKey && key !== state.conversationKey) {
        clearSelectionFull();
        closePreview();
        state.conversationKey = key;
      }
    };
    setInterval(tick, 800);
  }

  /* ---------- Preview ---------- */

  function selectedMessagesInOrder() {
    const nodes = getMessageNodes();
    const orderMap = new Map();
    nodes.forEach((node, index) => {
      const id = getMessageId(node, index);
      orderMap.set(id, index);
    });
    return Array.from(state.selected.values())
      .map((m) => ({
        ...m,
        order: orderMap.has(m.id) ? orderMap.get(m.id) : m.order,
      }))
      .sort((a, b) => a.order - b.order);
  }

  function openPreview() {
    const messages = selectedMessagesInOrder();
    if (!messages.length) {
      setStatus('Seleccioná al menos un mensaje', 'cl-error');
      return;
    }
    stopSelecting(false);

    closePreview();
    const priceLines = TF.detectPriceLines(messages);
    const overlay = document.createElement('div');
    overlay.id = 'carnelandia-preview-overlay';
    overlay.innerHTML = `
      <div id="carnelandia-preview-panel" role="dialog" aria-label="Vista previa de comanda">
        <h2>Vista previa del pedido</h2>
        <p class="cl-sub">Orden de la conversación. No se envía nada al cliente. Papel: ${state.settings.paperWidthMm} mm${state.settings.demoMode ? ' · Modo demostración' : ''}.</p>
        <div class="cl-messages" id="cl-preview-msgs"></div>
        <div class="cl-prices" id="cl-preview-prices"></div>
        <p class="cl-sub">Vista del ticket (PREPARACIÓN) — mismo formato que enviará a imprimir:</p>
        <div class="cl-ticket-preview" id="cl-ticket-preview"></div>
        <p class="cl-sub" style="margin-top:8px;">Segunda copia: CONTROL DE CAJA (mismo Nº).</p>
        <div class="cl-ticket-preview" id="cl-ticket-preview-control"></div>
        <label style="font-size:13px;display:flex;gap:6px;align-items:center;margin:8px 0;">
          <input type="checkbox" id="cl-is-reprint" /> Marcar como REIMPRESIÓN
        </label>
        <div class="cl-actions">
          <button type="button" class="cl-print" id="cl-btn-print">Imprimir dos copias</button>
          <button type="button" class="cl-cancel" id="cl-btn-close-preview">Cerrar</button>
        </div>
        <div class="cl-result" id="cl-print-result"></div>
      </div>
    `;
    document.body.appendChild(overlay);

    const msgsEl = overlay.querySelector('#cl-preview-msgs');
    messages.forEach((m) => {
      const block = document.createElement('div');
      block.className = 'cl-msg-block';
      block.textContent = m.text;
      msgsEl.appendChild(block);
    });

    const pricesEl = overlay.querySelector('#cl-preview-prices');
    if (priceLines.length) {
      const title = document.createElement('div');
      title.innerHTML = '<strong>Posibles precios detectados</strong> — desmarcá para excluirlos de la impresión (no se calculan totales):';
      pricesEl.appendChild(title);
      priceLines.forEach((p) => {
        const lab = document.createElement('label');
        const cb = document.createElement('input');
        cb.type = 'checkbox';
        cb.checked = true;
        cb.dataset.priceId = p.id;
        cb.addEventListener('change', () => {
          p.excluded = !cb.checked;
          refreshTicketPreview(messages, priceLines);
        });
        lab.appendChild(cb);
        lab.appendChild(document.createTextNode(p.text));
        pricesEl.appendChild(lab);
      });
    }

    function refreshTicketPreview(msgs, prices) {
      const job = TF.buildPrintJob({
        messages: msgs,
        priceLines: prices,
        ticketNumber: TF.nextTicketNumber(state.lastTicketNumber),
        paperWidthMm: state.settings.paperWidthMm,
        isReprint: overlay.querySelector('#cl-is-reprint').checked,
        contactName: isDemoPage() ? 'Demo Cliente' : S.contactName(),
        demoMode: state.settings.demoMode,
      });
      const prepEl = overlay.querySelector('#cl-ticket-preview');
      const ctrlEl = overlay.querySelector('#cl-ticket-preview-control');
      if (TF.renderPreviewHtml) {
        prepEl.innerHTML = TF.renderPreviewHtml(job.copies[0]);
        ctrlEl.innerHTML = TF.renderPreviewHtml(job.copies[1]);
      } else {
        prepEl.textContent = job.copies[0].text;
        ctrlEl.textContent = job.copies[1].text;
      }
      overlay._clJobBuilder = () =>
        TF.buildPrintJob({
          messages: msgs,
          priceLines: prices,
          ticketNumber: TF.nextTicketNumber(state.lastTicketNumber),
          paperWidthMm: state.settings.paperWidthMm,
          isReprint: overlay.querySelector('#cl-is-reprint').checked,
          contactName: isDemoPage() ? 'Demo Cliente' : S.contactName(),
          demoMode: state.settings.demoMode,
          printerName: state.settings.printerName,
        });
    }

    overlay.querySelector('#cl-is-reprint').addEventListener('change', () => {
      refreshTicketPreview(messages, priceLines);
    });
    refreshTicketPreview(messages, priceLines);

    overlay.querySelector('#cl-btn-close-preview').addEventListener('click', () => {
      closePreview();
      removeCheckboxes();
      state.selected.clear();
      updateToolbar();
    });
    overlay.querySelector('#cl-btn-print').addEventListener('click', () => {
      handlePrint(overlay);
    });
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) {
        /* no cerrar al click fuera para evitar pérdida accidental */
      }
    });
  }

  function closePreview() {
    document.getElementById('carnelandia-preview-overlay')?.remove();
  }

  /* ---------- Impresión ---------- */

  function handlePrint(overlay) {
    const btn = overlay.querySelector('#cl-btn-print');
    const result = overlay.querySelector('#cl-print-result');
    result.className = 'cl-result';
    result.textContent = '';

    if (state.printInFlight) {
      result.classList.add('cl-error');
      result.textContent = 'Ya hay un trabajo en curso. Evitá doble clic.';
      return;
    }

    const job = overlay._clJobBuilder ? overlay._clJobBuilder() : null;
    if (!job) {
      result.classList.add('cl-error');
      result.textContent = 'No se pudo armar el trabajo de impresión.';
      return;
    }

    // Huella sin número de ticket ni fecha (cambian en cada clic y anularían el guard).
    const fingerprint = JSON.stringify({
      bodies: (job.copies || []).map((c) =>
        String(c.text || '')
          .replace(/Nº\s*\d+/g, 'Nº')
          .replace(/\d{2}\/\d{2}\/\d{4}[^\n]*/g, 'FECHA')
      ),
      reprint: !!job.isReprint,
      width: job.paperWidthMm,
    });
    const now = Date.now();
    if (state.lastPrintedKey === fingerprint && now - state.lastPrintedAt < 5000) {
      result.classList.add('cl-error');
      result.textContent = 'Duplicado bloqueado: el mismo pedido se envió hace menos de 5 s.';
      return;
    }

    state.printInFlight = true;
    btn.disabled = true;
    result.textContent = state.settings.demoMode
      ? 'Modo demo: generando comanda de prueba…'
      : 'Enviando a la cola de impresión…';

    const payload = {
      action: 'print',
      job,
    };

    sendPrintRequest(payload)
      .then((response) => {
        state.printInFlight = false;
        btn.disabled = false;
        if (!response || !response.ok) {
          result.classList.add('cl-error');
          const code = response?.code || 'error';
          const msg = response?.message || 'Error desconocido';
          if (code === 'host_unavailable') {
            result.textContent =
              'No impreso: falta el componente nativo. En Windows ejecutá install.bat del paquete, reiniciá Chrome, desactivá «Modo demostración» en el popup y elegí la impresora.';
          } else if (code === 'printer_unavailable') {
            result.textContent =
              'No impreso: impresora no disponible. En el popup → Actualizar lista → elegí «Generic / Text Only» (u otra instalada). No se cambió la predeterminada del sistema.';
          } else if (code === 'protocol_mismatch') {
            result.textContent = `No impreso (protocolo): ${msg}`;
          } else {
            result.textContent = `No impreso: ${msg}`;
          }
          // No reintentar automáticamente
          return;
        }

        // Distinguir demo / cola / confirmación física
        const outcome = response.outcome || 'queued';
        const isDemo =
          outcome === 'demo_saved' ||
          response.demoOnly === true ||
          state.settings.demoMode === true;

        saveLastTicket(job.ticketNumber);
        state.lastPrintedKey = fingerprint;
        state.lastPrintedAt = Date.now();

        if (isDemo) {
          result.classList.add('cl-error'); // estilo aviso: no confundir con éxito de impresora
          result.style.color = '#8a5a00';
          result.textContent =
            `MODO DEMO — ticket Nº ${job.ticketNumber}. NO se envió a ninguna impresora. ` +
            (response.message || '') +
            ' Para imprimir de verdad: popup → desactivar Modo demostración (requiere componente nativo).';
          setStatus(`Demo ${job.ticketNumber} (sin papel)`, 'cl-error');
          return;
        }

        result.classList.add('cl-ok');
        if (outcome === 'queued') {
          result.textContent =
            `Enviado a la cola de impresión (Nº ${job.ticketNumber}, 2 copias). ` +
            `Esto confirma el envío al spooler de Windows, NO la salida física del papel. ` +
            (response.message || '');
          setStatus(`Cola ${job.ticketNumber}`, 'cl-ok');
        } else if (outcome === 'printed') {
          result.textContent = `El sistema confirmó impresión (Nº ${job.ticketNumber}).`;
          setStatus(`Impreso ${job.ticketNumber}`, 'cl-ok');
        } else {
          result.textContent = `Resultado «${outcome}» (Nº ${job.ticketNumber}). No se asume papel físico.`;
          setStatus(`Ticket ${job.ticketNumber} — ${outcome}`, 'cl-ok');
        }
      })
      .catch((err) => {
        state.printInFlight = false;
        btn.disabled = false;
        result.classList.add('cl-error');
        result.textContent = `Error: ${err.message || err}. No se reintenta automáticamente.`;
      });
  }

  function sendPrintRequest(payload) {
    // En demo page sin extensión: simular localmente
    if (isDemoPage() && !chrome?.runtime?.id) {
      return Promise.resolve(localDemoPrint(payload.job));
    }

    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage({ type: 'CARNELANDIA_PRINT', payload }, (response) => {
          if (chrome.runtime.lastError) {
            resolve({
              ok: false,
              code: 'host_unavailable',
              message: chrome.runtime.lastError.message,
            });
            return;
          }
          resolve(response);
        });
      } catch (e) {
        resolve({ ok: false, code: 'host_unavailable', message: String(e) });
      }
    });
  }

  function localDemoPrint(job) {
    const key = 'carnelandia_demo_prints';
    const prev = JSON.parse(sessionStorage.getItem(key) || '[]');
    prev.push({
      at: new Date().toISOString(),
      ticketNumber: job.ticketNumber,
      copies: job.copies.map((c) => ({ copyType: c.copyType, text: c.text })),
    });
    sessionStorage.setItem(key, JSON.stringify(prev));
    console.log('[Carnelandia Demo] Ticket', job.ticketNumber, job);
    const out = document.getElementById('carnelandia-demo-output');
    if (out) {
      out.textContent = job.copies.map((c) => c.text).join('\n\n' + '='.repeat(40) + '\n\n');
    }
    return {
      ok: true,
      outcome: 'demo_saved',
      message: 'Guardado en sessionStorage / panel demo',
    };
  }

  /* ---------- Autoimpresión (secundario: solo chat visible) ---------- */
  /*
   * LIMITACIÓN WhatsApp Web: no hay API fiable para leer mensajes de
   * conversaciones no abiertas sin manipular la UI / foco. La vía primaria
   * para Chrome minimizado + chat cerrado es el agente HTTP local
   * (Carnelandia Pedidos → POST http://127.0.0.1:17355/v1/orders).
   * Este escaneo solo cubre mensajes ya cargados en el DOM del chat abierto.
   */

  function collectVisiblePedidoIds() {
    const ids = new Set();
    if (!PF) return ids;
    getMessageNodes().forEach((node, index) => {
      const text = getMessageText(node);
      const pedido = PF.parsePedidoText(text);
      if (pedido) ids.add(pedido.orderId);
    });
    return ids;
  }

  function refreshBaselineFromVisible(clearSubmittedForNew) {
    const ids = collectVisiblePedidoIds();
    ids.forEach((id) => state.baselineOrderIds.add(id));
    state.autoScanReady = true;
  }

  function submitPedidoToAgent(pedido) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(
          { type: 'CARNELANDIA_AGENT_ORDER', pedido },
          (response) => {
            if (chrome.runtime.lastError) {
              resolve({
                ok: false,
                code: 'host_unavailable',
                message: chrome.runtime.lastError.message,
              });
              return;
            }
            resolve(response || { ok: false, message: 'Sin respuesta' });
          }
        );
      } catch (e) {
        resolve({ ok: false, message: String(e) });
      }
    });
  }

  function scanVisiblePedidos() {
    /*
     * Solo baseline anti-histórico. NO enviar a imprimir desde el DOM de WA:
     * la cola remota Pedidos ya imprime 2 copias; imprimir también aquí
     * duplicaba el mismo orderId (4 tickets). Impresión manual intacta.
     */
    if (!PF || !state.autoScanReady) return;
    getMessageNodes().forEach((node) => {
      const text = getMessageText(node);
      const pedido = PF.parsePedidoText(text);
      if (!pedido) return;
      state.baselineOrderIds.add(pedido.orderId);
      state.submittedOrderIds.add(pedido.orderId);
    });
  }

  function startAutoScan() {
    refreshBaselineFromVisible(false);
    if (state.autoObserver) state.autoObserver.disconnect();
    const list = isDemoPage()
      ? document.getElementById('carnelandia-demo-messages')
      : S.messageList && S.messageList();
    if (list) {
      state.autoObserver = new MutationObserver(() => {
        scanVisiblePedidos();
      });
      state.autoObserver.observe(list, { childList: true, subtree: true });
    }
    setInterval(scanVisiblePedidos, 2500);
  }

  /* ---------- Init ---------- */

  async function init() {
    await loadSettings();
    ensureToolbar();
    updateToolbar();
    updateAutoToggleUi();
    watchConversationChanges();
    startAutoScan();

    // Re-montar toolbar si WA re-renderiza
    if (!isDemoPage()) {
      const boot = setInterval(() => {
        if (!document.getElementById('carnelandia-toolbar')) {
          ensureToolbar();
          updateToolbar();
          updateAutoToggleUi();
        }
      }, 2000);
      setTimeout(() => clearInterval(boot), 60000);
    }

    chrome.storage?.onChanged?.addListener((changes, area) => {
      if (area !== 'local') return;
      if (changes[C.STORAGE_KEYS.PAPER_WIDTH]) {
        state.settings.paperWidthMm = changes[C.STORAGE_KEYS.PAPER_WIDTH].newValue;
      }
      if (changes[C.STORAGE_KEYS.DEMO_MODE]) {
        state.settings.demoMode = !!changes[C.STORAGE_KEYS.DEMO_MODE].newValue;
      }
      if (changes[C.STORAGE_KEYS.PRINTER_NAME]) {
        state.settings.printerName = changes[C.STORAGE_KEYS.PRINTER_NAME].newValue;
      }
      if (changes[C.STORAGE_KEYS.AUTO_PRINT]) {
        state.settings.autoPrintEnabled = !!changes[C.STORAGE_KEYS.AUTO_PRINT].newValue;
        updateAutoToggleUi();
      }
    });

    setStatus(
      state.settings.demoMode
        ? 'Listo (modo demo)'
        : state.settings.autoPrintEnabled
          ? 'Listo · auto ON'
          : 'Listo · auto OFF'
    );
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
