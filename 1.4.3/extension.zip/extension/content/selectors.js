/**
 * Selectores de WhatsApp Web — AISLADOS.
 * Cuando Meta cambie la UI, actualizar SOLO este archivo.
 * No hardcodear estos selectores en el resto del código.
 *
 * Estado: heurísticas basadas en DOM público de WhatsApp Web (2024–2025).
 * PENDIENTE: validar contra la versión real en producción.
 */
(function (root) {
  'use strict';

  const WhatsAppSelectors = {
    VERSION_NOTE: '2026-03 — heurística; verificar en WA Web real',

    /** Panel principal del chat abierto */
    mainPanel: () =>
      document.querySelector('#main') ||
      document.querySelector('[data-testid="conversation-panel-wrapper"]'),

    /** Contenedor scrolleable de mensajes */
    messageList: () => {
      const main = WhatsAppSelectors.mainPanel();
      if (!main) return null;
      return (
        main.querySelector('[data-testid="conversation-panel-messages"]') ||
        main.querySelector('div[role="application"]') ||
        main.querySelector('.copyable-area') ||
        main
      );
    },

    /** Nodos de mensaje individuales (solo visibles/cargados) */
    messageNodes: () => {
      const list = WhatsAppSelectors.messageList();
      if (!list) return [];
      const nodes = list.querySelectorAll(
        [
          'div[data-testid="msg-container"]',
          'div.message-in',
          'div.message-out',
          'div[class*="message-"]',
        ].join(', ')
      );
      // Deduplicar por elemento
      return Array.from(new Set(nodes));
    },

    /** Texto legible de un nodo mensaje */
    messageText: (node) => {
      if (!node) return '';
      const selectable =
        node.querySelector('[data-testid="selectable-text"]') ||
        node.querySelector('span.selectable-text') ||
        node.querySelector('.copyable-text') ||
        node.querySelector('span[dir="ltr"], span[dir="auto"]');
      if (selectable) {
        return (selectable.innerText || selectable.textContent || '').trim();
      }
      // Fallback: texto del contenedor sin botones de UI
      const clone = node.cloneNode(true);
      clone.querySelectorAll('button, svg, [role="button"]').forEach((el) => el.remove());
      return (clone.innerText || '').trim();
    },

    /** Id estable-ish del mensaje (data-id si existe) */
    messageId: (node, index) => {
      const dataId =
        node.getAttribute('data-id') ||
        node.closest('[data-id]')?.getAttribute('data-id');
      if (dataId) return dataId;
      const pre =
        node.querySelector('[data-pre-plain-text]')?.getAttribute('data-pre-plain-text') ||
        node.querySelector('.copyable-text')?.getAttribute('data-pre-plain-text');
      if (pre) return `pre:${pre.slice(0, 80)}`;
      return `idx:${index}:${(WhatsAppSelectors.messageText(node) || '').slice(0, 40)}`;
    },

    /** Nombre del contacto / chat abierto */
    contactName: () => {
      const header =
        document.querySelector('#main header') ||
        document.querySelector('[data-testid="conversation-info-header"]');
      if (!header) return '';
      const title =
        header.querySelector('[data-testid="conversation-info-header-chat-title"]') ||
        header.querySelector('span[dir="auto"]') ||
        header.querySelector('span');
      return (title?.innerText || title?.textContent || '').trim();
    },

    /** Detectar cambio de conversación (clave de identidad del chat) */
    conversationKey: () => {
      const name = WhatsAppSelectors.contactName();
      const main = WhatsAppSelectors.mainPanel();
      const aria = main?.getAttribute('aria-label') || '';
      return `${name}||${aria}`;
    },

    /** ¿Está abierto un chat? */
    hasOpenChat: () => !!WhatsAppSelectors.mainPanel(),
  };

  root.WhatsAppSelectors = WhatsAppSelectors;
})(typeof globalThis !== 'undefined' ? globalThis : this);
