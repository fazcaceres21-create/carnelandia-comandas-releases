# Actualizaciones por internet — canal real

## Enlaces publicados — **1.4.2** (formato / corte)

| Recurso | URL |
|---------|-----|
| **Manifiesto (SHA-256)** | https://raw.githubusercontent.com/fazcaceres21-create/carnelandia-comandas-releases/main/update-manifest.json |
| Release | https://github.com/fazcaceres21-create/carnelandia-comandas-releases/releases/tag/v1.4.2 |
| Página | https://fazcaceres21-create.github.io/carnelandia-comandas-releases/ |

Canal en la PC — archivo `%USERPROFILE%\CarnelandiaComandas\update_channel.txt`:

```
https://raw.githubusercontent.com/fazcaceres21-create/carnelandia-comandas-releases/main/update-manifest.json
```

## Actualizar Windows por internet (caja)

1. Sin impresión en curso.
2. Abrí `C:\CarnelandiaComandas\native-host\update_check.bat` → debe ofrecer **1.4.2**.
3. Ejecutá `update_apply.bat` (verifica SHA-256, respalda, reemplaza host + extensión).
4. Cerrá el agente anterior y abrí `start_agent.bat`.
5. `chrome://extensions` → confirmá que la ruta de la extensión es la que imprimió el apply (típicamente `C:\CarnelandiaComandas\extension`) → **Recargar**.
6. Popup → versión **1.4.2** / ping host **1.4.2**.

### Ruta de la extensión (no asumir = solo el host)

El apply escribe/lee `%USERPROFILE%\CarnelandiaComandas\extension_path.txt` y actualiza esa carpeta (si no hay marcador: hermano del host = `C:\CarnelandiaComandas\extension`).  
Si Chrome tiene cargada **otra** carpeta, Recargar no trae el cambio: cargá/recargá la ruta que actualizó el apply.

## Qué se actualiza solo vs qué requiere acción

| Componente | Tras `update_apply` |
|------------|---------------------|
| Host + agente | Archivos nuevos; **reiniciar** `start_agent.bat` |
| Extensión unpacked | Archivos nuevos; **Recargar** en Chrome (no hay auto-update MV3) |
| Config / token / cola / printed | Conservados |

## Verificado en código vs pendiente físico

| Verificación | Estado |
|--------------|--------|
| Manifiesto 1.4.2 + SHA-256 de host.zip / extension.zip vía raw.githubusercontent | OK (descarga = hash) |
| Updater `--check` ve 1.4.2 | OK en este Mac |
| Formato/corte en papel, Chrome minimizado | **Pendiente en la PC de caja** |
