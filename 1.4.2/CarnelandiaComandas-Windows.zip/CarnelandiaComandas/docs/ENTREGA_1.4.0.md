# Entrega 1.4.0 — Autoimpresión + corte + actualizaciones

## Incluye

- Interruptor **Impresión automática activada/desactivada** (verde/rojo), default ON, persistente.
- Agente HTTP `127.0.0.1:17355` para Carnelandia Pedidos (chats cerrados / Chrome minimizado).
- Escaneo secundario en WhatsApp solo del chat **visible** (con baseline anti-histórico).
- Dedupe por `orderId` persistente; pendientes / uncertain; sin reintento ciego.
- Dos copias + avance/corte configurable (`cutMode`: ESC/POS RAW con fallback feed).
- Actualizador host con SHA-256 + respaldo; extensión unpacked requiere Recargar.
- Impresión manual intacta.

## Limitación documentada

WhatsApp Web no permite leer chats no abiertos de forma fiable. La prueba final del negocio **requiere** que Pedidos envíe `POST /v1/orders` (ver `PEDIDOS_FORMATO.md`). El proyecto Pedidos **no está** en este repo.

## Comprobado en este Mac vs pendiente en PC caja

| Ítem | Estado |
|------|--------|
| Sintaxis Python host/agent/updater | Comprobado aquí |
| Parser pedido + build 2 copias | Comprobado aquí |
| Empaquetado zip + manifiestos SHA-256 | Comprobado aquí |
| Impresión física + corte térmico | **Pendiente PC Windows** |
| Chrome minimizado + StarPOS + chat cerrado | **Pendiente** (depende integración Pedidos→agente) |
| Update apply desde HTTPS real | **Pendiente** (falta hosting con URL) |

## Instalación inicial (una vez, puede ser por internet)

1. Descargar `dist/windows/CarnelandiaComandas-1.4.0.zip`.
2. Descomprimir → `install.bat` (conserva config si reinstalás).
3. Cargar/recargar extensión; reiniciar Chrome.
4. Verificar agente (startup + `start_agent.bat`).
5. Configurar canal: `update_channel.txt` con URL del manifiesto cuando publiques releases.
