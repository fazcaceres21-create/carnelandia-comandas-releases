# Instalación en la PC Windows del local (impresión real) — v1.4

Paquete: `dist/windows/CarnelandiaComandas-1.4.0.zip` → carpeta `CarnelandiaComandas`.

**No cambia** la impresora predeterminada, el puerto USB, el controlador ni StarPOS.

## Qué copiar (instalación inicial)

Podés bajar el zip por internet (no hace falta pendrive si la PC tiene red):

1. Descomprimí en p. ej. `C:\CarnelandiaComandas\`
2. Seguí A → B → C abajo.
3. Después de esta vez, las actualizaciones del **host** pueden venir por el canal HTTPS (`docs/ACTUALIZACIONES.md`). La extensión en modo desarrollador sigue necesitando **Recargar**.

## Orden de pasos

### A) Extensión en Chrome

1. Chrome → `chrome://extensions` → Modo desarrollador
2. **Cargar descomprimida** → `C:\CarnelandiaComandas\extension`
3. Popup Carnelandia → **Copiar ID**

### B) Componente nativo + agente

1. `check_syntax.bat` (opcional) → `OK: sintaxis valida`
2. `install.bat` → pegá el ID de la extensión
3. El instalador registra Native Messaging, conserva config si reinstalás, inicia el **agente** (`127.0.0.1:17355`) y lo deja en el inicio de sesión
4. **Cerrá Chrome por completo** y volvé a abrirlo
5. `chrome://extensions` → Recargar Carnelandia

### C) Activar impresión real + auto

1. Popup → desmarcar Modo demostración
2. Actualizar lista → elegí la térmica (p. ej. Generic / Text Only)
3. Pasos 2–5 del diagnóstico (host, self-check, cola, **estado agente**)
4. En WhatsApp Web el interruptor debe decir **Impresión automática activada** (verde). Podés apagarlo (rojo); la impresión manual sigue
5. Impresión manual: Seleccionar → Vista previa → Imprimir dos copias

### D) Carnelandia Pedidos (obligatorio para chat cerrado / Chrome minimizado)

Integrá el POST documentado en `docs/PEDIDOS_FORMATO.md`.  
Sin ese POST, la extensión **no** puede imprimir pedidos de chats no abiertos.

### E) Canal de actualizaciones (una vez)

1. Publicá releases desde tu Mac: `python3 scripts/build_release.py --base-url https://TU-DOMINIO/.../`
2. En la caja, creá  
   `%USERPROFILE%\CarnelandiaComandas\update_channel.txt`  
   con la URL del `update-manifest.json`
3. Futuras versiones: `native-host\update_check.bat` / `update_apply.bat`  
   (conserva impresora, pendientes, printed; pide reiniciar agente / Recargar extensión)

## Corte entre copias

Por defecto `cutMode: escpos_full` (GS V) vía RAW tras cada copia.  
Si la impresora/driver no corta, en `native-host\config\config.json` probá `"formfeed"` o `"feed"` (no inventamos modelo: hay que validar en la térmica real).

## Prueba final del negocio

| Escenario | Esperado |
|-----------|----------|
| Chrome minimizado, StarPOS adelante, pedido nuevo vía Pedidos→agente | 2 copias + corte, sin foco a Chrome |
| Mismo `orderId` reenviado | `duplicate`, no reimprime |
| Auto OFF | No imprime auto; manual OK; pedido queda pendiente |
| Fallo impresora/host | Error visible; pendiente/uncertain; sin reintento ciego |

## Comprobado vs pendiente

Ver `docs/ENTREGA_1.4.0.md` y `docs/PROBADO.md`.
