# Probado vs pendiente (1.4.0)

## Probado en Mac (desarrollo) — esta entrega

| Ítem | Resultado |
|------|-----------|
| Sintaxis Python host / agent / updater | OK |
| `build_print_job_from_messages` → 2 copias | OK |
| Parser pedido JSON + texto (JS + agent) | OK |
| Empaque `CarnelandiaComandas-1.4.0.zip` + `host.zip`/`extension.zip` + SHA-256 | OK |
| Formato ticket / impresión manual (código intacto + cut flag) | Lógica OK; papel no |
| Respaldo pre-cambio `backups/carnelandia_pre_auto_*.tar.gz` | OK |

## Heredado (1.3.x Windows caja, no reejecutado aquí)

| Ítem | Estado |
|------|--------|
| Ping host + listar impresoras + cola Generic/Text Only | Relatado por usuario en 1.3 |
| Correcciones pywin32 / instalador PS | En código |

## Pendiente SOLO en PC física del negocio

1. Instalar 1.4.0 / Recargar extensión / reiniciar Chrome  
2. Agente en `17355` + Pedidos enviando `POST /v1/orders`  
3. Chrome minimizado + StarPOS adelante + chat **no** abierto → 2 copias con corte  
4. Dedupe del mismo `orderId`; auto OFF + manual  
5. Validar `cutMode` real (ESC/POS vs formfeed) en la térmica  
6. Canal HTTPS real + `update_apply.bat` (una vez configurado `update_channel.txt`)

**No declarar “impresión automática probada en caja” hasta completar 3–4 allí.**  
**No declarar “actualización por internet lista en producción” hasta completar 6 con URL real.**
