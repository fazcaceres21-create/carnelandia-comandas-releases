# Instalación y prueba — Carnelandia Comandas

## Probar ahora en esta Mac (sin térmica ni WhatsApp)

1. Abrí en el navegador el archivo:
   `demo/demo.html`
   (doble clic o arrastralo a Chrome).
2. Pulsá **Seleccionar pedido**, marcá mensajes, **Vista previa**, excluí precios si querés, **Imprimir dos copias**.
3. Revisá el panel “Salida demo” (dos bloques: PREPARACIÓN y CONTROL DE CAJA).

No se imprime papel. No se modifica nada del sistema.

## Cargar la extensión en Chrome (Mac o Windows)

1. Abrí `chrome://extensions`.
2. Activá **Modo de desarrollador**.
3. **Cargar descomprimida** → elegí la carpeta `extension/`.
4. Abrí el icono de la extensión (popup):
   - Dejá **Modo demostración** activado al principio.
   - Elegí papel **80 mm** o **58 mm** (una sola vez).
   - Copiá el **ID de la extensión**.

## Instalar el componente nativo en esta Mac

```bash
cd "native-host"
chmod +x install_macos.sh
./install_macos.sh
```

Pegá el ID cuando lo pida. Reiniciá Chrome. En el popup: **Probar componente nativo**.

Opcional Unicode PDF: `pip3 install --user reportlab`

## Instalar en Windows 10

1. Instalá [Python 3](https://www.python.org/downloads/) marcando **Add to PATH**.
2. Copiá toda la carpeta del proyecto a la PC de caja.
3. Cargá la extensión como arriba y copiá el ID.
4. PowerShell en `native-host`:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\install_windows.ps1
```

5. Opcional: `pip install pywin32 reportlab`
6. Reiniciá Chrome → **Probar componente nativo**.

## Conectar la térmica (cuando digas)

1. La impresora debe estar **instalada en el SO** (preferencias del sistema / dispositivos).
2. En el popup: desactivá demo → **Actualizar lista** → elegí la térmica.
3. Probá **un** trabajo de prueba cuando lo indiques (este desarrollo **no** imprime físico sin tu OK).
4. No hace falta elegir impresora en cada pedido.

StarPOS y la impresora predeterminada del sistema **no se tocan**.

## WhatsApp Web

1. Entrá a https://web.whatsapp.com con la extensión activa.
2. Abrí un chat con mensajes visibles.
3. **Seleccionar pedido** → casillas → vista previa → imprimir.

**Limitación:** solo mensajes ya cargados/visibles en el DOM. Si falta historia, scrolleá hacia arriba para cargarlos antes de seleccionar.

Los selectores están en `extension/content/selectors.js` para poder actualizarlos si WhatsApp cambia la interfaz.
