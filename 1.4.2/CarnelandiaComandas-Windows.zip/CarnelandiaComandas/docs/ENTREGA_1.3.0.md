# Entrega 1.3.0 — Diagnóstico integral y correcciones

## Hechos comprobados (evidencia)

| Hecho | Evidencia |
|-------|-----------|
| Sin host nativo, con demo, la extensión simulaba éxito | Mensaje visto: «Modo demo sin componente nativo… no hay impresión física» + código `service-worker.js` `hostMissingMessage(true)` → `ok: true`, `demo_saved` |
| El instalador falló por **análisis PowerShell**, no por Python | Errores `UnexpectedToken` / `ParentContainsErrorRecordException` en `install_windows.ps1`; causa: `\|` dentro de `"...(2\|4)..."` y UTF-8 sin BOM |
| Tras instalar Python/pywin32, falló verify por **comillas escapadas** en `python -c` | `SyntaxError: unexpected character after line continuation character` con `print(\"…\")` |
| Ping y lista de impresoras funcionaron en Chrome | Usuario: «OK — Carnelandia host activo (Windows), protocolo 1» + lista con Generic / Text Only |
| Al imprimir: «Falta pywin32» pese a pywin32 instalado | Código GDI hacía `import win32print, win32ui, win32con` y **cualquier** `ImportError` devolvía ese texto genérico. Listar impresoras solo usa `win32print` → coherente con win32print OK + **win32ui** fallando |
| Prueba de Windows imprime con acentos mal | Dato del usuario sobre página de prueba del SO (driver Generic/Text Only), no inventado |

## Hipótesis (no demostradas en Mac)

| Hipótesis | Cómo comprobar en caja |
|-----------|------------------------|
| Falta `pywin32_postinstall` (DLLs de win32ui) | `diagnose.bat` / verify: `IMPORT_FAIL win32ui` |
| El wrapper usa el mismo `python.exe` que pip | VALIDAR.bat muestra `python del wrapper=` vs `sys.executable` |
| TEXT/cp1252 mejora o empeora acentos vs GDI | Prueba de cola del popup + inspección del ticket |

## Causas corregidas en código

1. Separación demo vs real (sin éxito falso si se pide impresión real).
2. Instalador PS 5.1 sin `-c` anidado; helpers `.py`; BOM+CRLF.
3. Imports Windows **uno a uno** + mensaje con módulo/excepción/`sys.executable`.
4. Método **`auto`**: GDI → TEXT cp1252 → TEXT utf-16le; sin reintentos que dupliquen tras éxito.
5. Logs solo a archivo (`CarnelandiaComandas\logs\host.log`).
6. Acciones host: `self_check`, `test_print`; popup con pasos 1–4.
7. `VALIDAR.bat`: no declara éxito si faltan registro/manifiesto/verify/self_check.

## Qué NO se declara solucionado desde Mac

- Salida **física** de papel en la térmica del local.
- Calidad final de acentos en Generic / Text Only (depende del driver).
- Native Messaging extremo a extremo en esa PC tras esta entrega (hay que correr VALIDAR + popup).

## Distribución elegida (mínima fricción manual)

**Extensión Chrome cargada una vez** + **host Python registrado por Native Messaging**, instalado/reparado por `install.bat` / `VALIDAR.bat`.

Justificación: Chrome Web Store no distribuye host nativo; un `.exe` embebido exigiría firma Windows y build cruzado desde Mac. Python 3 + pywin32 ya está en la caja; el instalador **omite pip** si verify ya pasa y repara registro/wrapper/postinstall.

## Secuencia única en el local

1. Reemplazar archivos del paquete **sin tocar** `extension\` (mismo ID).
2. `VALIDAR.bat` → debe decir `RESULTADO=EXITO` (lee el TXT si falla).
3. Si FALLO → `install.bat` (mismo ID) → otra vez `VALIDAR.bat`.
4. Cerrar Chrome por completo → abrir.
5. Popup: demo OFF → 1 lista → 2 ping → 3 self-check → 4 prueba cola.
6. WhatsApp: imprimir dos copias; mensaje esperado «Enviado a la cola…».
7. Si acentos mal: en `native-host\config\config.json` probar `"windowsPrintMethod": "gdi"` o `"text_utf16"` tras postinstall; no asumir ESC/POS.

StarPOS y la impresora predeterminada del sistema **no se modifican**.
