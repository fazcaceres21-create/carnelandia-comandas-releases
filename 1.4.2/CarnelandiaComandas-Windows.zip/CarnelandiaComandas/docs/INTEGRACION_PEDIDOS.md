# Integración Pedidos ↔ Comandas

## Confirmación vs impresión

| Evento | Efecto |
|--------|--------|
| Resumen en pantalla | Borrador. No imprime. |
| **ENVIAR PEDIDO POR WHATSAPP** + enqueue OK | Mismo `CP-<uuid>` en WA y cola. **Habilita impresión automática.** |
| Enviar en WhatsApp | Confirmación operativa (humano / horario). |
| Agente Windows (pull) | Imprime 2 copias + ack. |

## Implementado y publicado

- Cola en https://carnelandia-pedidos.fly.dev (enqueue / pull / ack) — **deploy hecho**, APIs verificadas con HTTP 200.
- Agente Windows con poller HTTPS (`remoteQueueUrl` + token).
- Parsers WEB_V1 en la extensión.
- Paquete Windows + manifiesto SHA-256 en GitHub Releases v1.4.1.

## Enlaces

- Instalación: https://fazcaceres21-create.github.io/carnelandia-comandas-releases/1.4.1/CarnelandiaComandas-Windows.zip  
- Manifiesto updates: https://fazcaceres21-create.github.io/carnelandia-comandas-releases/update-manifest.json  

## Pendiente en la PC de la caja

1. Instalar/actualizar con el zip de arriba (conserva impresora).
2. Copiar `.secrets/remote_queue.for-caja.json` → `%USERPROFILE%\CarnelandiaComandas\remote_queue.json`  
   (o pegar el token en `config.json` → `remoteQueueToken`).
3. Copiar `.secrets/update_channel.txt` → `%USERPROFILE%\CarnelandiaComandas\update_channel.txt`
4. Reiniciar `start_agent.bat` / Chrome.
5. Probar: pedido real con Chrome minimizado + StarPOS.

Token generado en este equipo: ver `.secrets/` (no subir a git).
