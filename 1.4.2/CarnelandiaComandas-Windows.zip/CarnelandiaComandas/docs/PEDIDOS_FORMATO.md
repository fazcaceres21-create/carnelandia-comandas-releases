# Formato Carnelandia Pedidos → Comandas

Proyecto Pedidos: `/Users/franco/LINK DE PEDIDOS CARNELANDIA`  
Producción: https://carnelandia-pedidos.fly.dev

## Circuito principal (celulares → servidor → PC)

Los teléfonos **no** pueden hablar con `127.0.0.1` de la caja.

1. Cliente toca **ENVIAR PEDIDO POR WHATSAPP** → `POST /api/public/print-queue/enqueue`
2. PC Windows (agente) → `GET /api/print-agent/pull` con `Authorization: Bearer <PRINT_AGENT_TOKEN>`
3. Tras imprimir → `POST /api/print-agent/ack`

Mismo `orderId` (`CP-<uuid>`) en WhatsApp y en la cola.

**Impresión habilitada:** solo tras el enqueue del paso 1 (`printEligible`).

## WhatsApp (detalle completo, mismo ID)

```
CARNELANDIA_PEDIDO_WEB_V1
ID_PEDIDO: CP-3f2a9c1e-8b44-4d2a-9f01-a7c6e2b1d904

PEDIDO CARNELANDIA
…
```

La extensión puede detectar este marcador en el chat **abierto** (secundario).  
Chats cerrados / Chrome minimizado → solo el pull remoto.

## Config en la PC

`native-host/config/config.json` o `%USERPROFILE%\CarnelandiaComandas\remote_queue.json`:

```json
{
  "url": "https://carnelandia-pedidos.fly.dev",
  "token": "<mismo PRINT_AGENT_TOKEN del Fly>",
  "pollSeconds": 8,
  "enabled": true
}
```

## Localhost 17355

Sigue existiendo para pruebas locales / herramientas en la misma PC. No es el camino de los celulares.
