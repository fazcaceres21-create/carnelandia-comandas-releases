# Publicar en Chrome Web Store (preparación — no publicado aún)

La instalación “cargar descomprimida” es **solo para desarrollo**. En producción las cajeras deberían recibir actualizaciones de la **extensión** vía Chrome Web Store, sin descargar ZIP a mano.

## Qué necesitás (checklist)

1. **Cuenta de desarrollador de Google Chrome Web Store**  
   - Pago único de registro (valor actual en el sitio de Google; verificar al momento).  
   - Acceso a [Chrome Developer Dashboard](https://chrome.google.com/webstore/devconsole).

2. **Identidad estable de la extensión**  
   - Al publicar la **primera** vez, Chrome asigna un ID permanente.  
   - Para conservar el mismo ID entre versiones de desarrollo y store: generar un par de claves y fijar `"key"` en el manifiesto **solo en builds de store**, o usar el ID que dé el dashboard tras el primer upload.  
   - El ID debe coincidir con el permitido en el manifiesto Native Messaging del host.

3. **Paquete ZIP** de la carpeta `extension/` (sin archivos de desarrollo innecesarios).  
   - No incluir el host nativo dentro del ZIP de la extensión (Chrome no lo instala).

4. **Ficha de la tienda**  
   - Nombre, descripción corta/larga en español.  
   - Capturas de pantalla (WhatsApp Web + toolbar + vista previa).  
   - Ícono 128×128 (ya hay en `extension/icons/`).  
   - Categoría (p. ej. Productividad).  
   - Política de privacidad (URL pública): dejar claro que **no** se suben chats a servidores.

5. **Permisos justificados**  
   - `host_permissions` → `https://web.whatsapp.com/*`  
   - `storage`, `nativeMessaging`  
   - Explicar en la ficha: Native Messaging habla solo con el componente local Carnelandia.

6. **Revisión de Google**  
   - Puede pedir justificación de nativeMessaging y del acceso a WhatsApp Web.  
   - Preparar un video corto del flujo en modo demo.

## Qué NO hace la Web Store

- **No instala ni actualiza el componente nativo** (impresor).  
- Actualizar la extensión **no** actualiza el host: ver `docs/ACTUALIZACIONES.md`.

## Estado

| Ítem | Estado |
|------|--------|
| Código listo para empaquetar `extension/` | Preparado |
| Cuenta / pago / ficha / publicación | **Pendiente** (no publicar todavía) |
| ID de producción fijado en host | Pendiente tras primer upload |
