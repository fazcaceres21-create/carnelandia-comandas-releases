#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Agente local Carnelandia Comandas (Windows).
- HTTP 127.0.0.1:17355 para Carnelandia Pedidos (chats no abiertos / Chrome minimizado).
- Cola persistente + dedupe por orderId.
- Imprime 2 copias reutilizando carnelandia_print_host.
- No escribe el protocolo Native Messaging en stdout de Chrome: proceso aparte.

Inicio: start_agent.bat (instalador puede registrarlo al inicio de sesión).
"""
from __future__ import annotations

import json
import os
import sys
import threading
import traceback
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict, Optional
from urllib.parse import urlparse

APP_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(APP_DIR))

import carnelandia_print_host as host  # noqa: E402

DATA_DIR = Path.home() / "CarnelandiaComandas"
QUEUE_PATH = DATA_DIR / "queue" / "state.json"
TOKEN_PATH = DATA_DIR / "agent_token.txt"
REMOTE_CFG_PATH = DATA_DIR / "remote_queue.json"
LOG_PATH = DATA_DIR / "logs" / "agent.log"
HOST_ADDR = "127.0.0.1"
PORT = 17355
DEFAULT_REMOTE_QUEUE_URL = "https://carnelandia-pedidos.fly.dev"

_lock = threading.RLock()
_state: Dict[str, Any] = {
    "autoPrintEnabled": True,
    "printed": {},  # orderId -> {at, outcome}
    "pending": {},  # orderId -> order
    "uncertain": {},  # orderId -> {at, reason}
    "printing": False,
    "remoteLastPull": None,
    "remoteLastError": None,
}


def agent_log(msg: str) -> None:
    try:
        LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(f"{datetime.now().isoformat()} {msg}\n")
    except Exception:
        pass


def load_state() -> None:
    global _state
    try:
        if QUEUE_PATH.is_file():
            data = json.loads(QUEUE_PATH.read_text(encoding="utf-8"))
            with _lock:
                for k in ("autoPrintEnabled", "printed", "pending", "uncertain"):
                    if k in data:
                        _state[k] = data[k]
    except Exception as e:
        agent_log(f"load_state error: {e}")


def save_state() -> None:
    try:
        QUEUE_PATH.parent.mkdir(parents=True, exist_ok=True)
        with _lock:
            payload = {
                "autoPrintEnabled": _state["autoPrintEnabled"],
                "printed": _state["printed"],
                "pending": _state["pending"],
                "uncertain": _state["uncertain"],
                "savedAt": datetime.now().isoformat(),
            }
        QUEUE_PATH.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
        )
    except Exception as e:
        agent_log(f"save_state error: {e}")


def ensure_token() -> str:
    TOKEN_PATH.parent.mkdir(parents=True, exist_ok=True)
    if TOKEN_PATH.is_file():
        return TOKEN_PATH.read_text(encoding="utf-8").strip()
    import secrets

    tok = secrets.token_hex(16)
    TOKEN_PATH.write_text(tok, encoding="utf-8")
    return tok


def canonical_order_id(raw: str) -> str:
    import re

    oid = str(raw or "").strip().upper()
    if not oid:
        return ""
    if not oid.startswith("CP-") and re.match(
        r"^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}$", oid
    ):
        oid = "CP-" + oid
    return oid


def is_valid_order_id(oid: str) -> bool:
    import re

    o = canonical_order_id(oid)
    return bool(re.match(r"^CP-[A-Z0-9][A-Z0-9\-_.]{3,80}$", o))


def pedido_from_body(body: dict) -> Optional[dict]:
    # Mirror PedidoFormat.parsePedidoJson lightly
    if not isinstance(body, dict):
        return None
    if body.get("schema") and body.get("schema") != "carnelandia.pedido.v1":
        return None
    oid = canonical_order_id(str(body.get("orderId") or body.get("id") or ""))
    if not is_valid_order_id(oid):
        return None
    items = []
    for it in body.get("items") or []:
        if isinstance(it, str):
            items.append(it.strip())
        elif isinstance(it, dict):
            if it.get("line"):
                items.append(str(it["line"]).strip())
            else:
                items.append(
                    " ".join(
                        str(x) for x in (it.get("qty"), it.get("name")) if x
                    ).strip()
                )
    items = [i for i in items if i]
    # Si viene messageText WEB_V1 sin items, armar desde texto
    if not items and body.get("messageText"):
        items = [
            ln.strip()
            for ln in str(body["messageText"]).splitlines()
            if ln.strip() and not ln.strip().startswith("CARNELANDIA")
        ][:40]
    return {
        "orderId": oid,
        "customerName": str(body.get("customerName") or body.get("cliente") or "").strip(),
        "address": str(body.get("address") or body.get("direccion") or "").strip(),
        "items": items,
        "notes": str(body.get("notes") or body.get("aclaraciones") or "").strip(),
        "source": body.get("source") or "http",
        "claimToken": body.get("claimToken"),
        "messageText": body.get("messageText") or "",
        "receivedAt": datetime.now().isoformat(),
    }


def load_remote_config() -> dict:
    """URL + token para pull saliente hacia Pedidos (Fly)."""
    cfg = host.load_config()
    out = {
        "url": str(
            cfg.get("remoteQueueUrl") or DEFAULT_REMOTE_QUEUE_URL
        ).rstrip("/"),
        "token": str(cfg.get("remoteQueueToken") or ""),
        "pollSeconds": int(cfg.get("remoteQueuePollSeconds") or 8),
        "enabled": bool(cfg.get("remoteQueueEnabled", True)),
    }
    if REMOTE_CFG_PATH.is_file():
        try:
            data = json.loads(REMOTE_CFG_PATH.read_text(encoding="utf-8"))
            if data.get("url"):
                out["url"] = str(data["url"]).rstrip("/")
            if data.get("token"):
                out["token"] = str(data["token"])
            if data.get("pollSeconds"):
                out["pollSeconds"] = int(data["pollSeconds"])
            if "enabled" in data:
                out["enabled"] = bool(data["enabled"])
        except Exception as e:
            agent_log(f"remote_queue.json: {e}")
    env_tok = os.environ.get("CARNELANDIA_PRINT_AGENT_TOKEN", "").strip()
    if env_tok:
        out["token"] = env_tok
    return out


def remote_ack(order_id: str, outcome: str, detail: str = "", claim_token: str = "") -> None:
    import urllib.request

    rc = load_remote_config()
    if not rc.get("token") or not rc.get("url"):
        return
    payload = json.dumps(
        {
            "orderId": order_id,
            "outcome": outcome,
            "detail": detail,
            "claimToken": claim_token or None,
        }
    ).encode("utf-8")
    req = urllib.request.Request(
        rc["url"] + "/api/print-agent/ack",
        data=payload,
        method="POST",
        headers={
            "Content-Type": "application/json",
            "Authorization": "Bearer " + rc["token"],
            "User-Agent": "CarnelandiaAgent/1.4",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            agent_log(f"remote ack {order_id} {outcome} http={resp.status}")
    except Exception as e:
        agent_log(f"remote ack error: {e}")


def remote_pull_once() -> None:
    """Conexión saliente autenticada: trae elegibles y los imprime."""
    import urllib.request

    rc = load_remote_config()
    if not rc.get("enabled"):
        return
    if not rc.get("token"):
        with _lock:
            _state["remoteLastError"] = "Sin remoteQueueToken / PRINT_AGENT_TOKEN"
        return
    if not _state.get("autoPrintEnabled", True):
        return

    url = rc["url"] + "/api/print-agent/pull?limit=5"
    req = urllib.request.Request(
        url,
        method="GET",
        headers={
            "Authorization": "Bearer " + rc["token"],
            "User-Agent": "CarnelandiaAgent/1.4",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=25) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        with _lock:
            _state["remoteLastPull"] = datetime.now().isoformat()
            _state["remoteLastError"] = None
    except Exception as e:
        with _lock:
            _state["remoteLastError"] = str(e)
        agent_log(f"remote pull error: {e}")
        return

    if not data.get("ok"):
        with _lock:
            _state["remoteLastError"] = data.get("error") or "pull no ok"
        return

    for raw in data.get("orders") or []:
        pedido = pedido_from_body(raw if isinstance(raw, dict) else {})
        if not pedido:
            continue
        claim = str(raw.get("claimToken") or "")
        result = try_print_pedido(pedido)
        outcome = result.get("outcome")
        if outcome == "queued" or (
            result.get("ok") and outcome == "duplicate"
        ):
            remote_ack(pedido["orderId"], "printed", result.get("message") or "", claim)
        elif outcome == "uncertain":
            remote_ack(
                pedido["orderId"],
                "uncertain",
                result.get("message") or "",
                claim,
            )
        elif outcome == "busy":
            # Servidor vuelve el pedido a eligible (detail empieza con busy)
            remote_ack(pedido["orderId"], "failed", "busy", claim)
        else:
            remote_ack(
                pedido["orderId"],
                "failed",
                result.get("message") or "print failed",
                claim,
            )


def remote_poll_loop() -> None:
    while True:
        try:
            rc = load_remote_config()
            secs = max(4, int(rc.get("pollSeconds") or 8))
            if rc.get("enabled") and rc.get("token"):
                remote_pull_once()
            else:
                secs = max(secs, 30)
        except Exception:
            agent_log(traceback.format_exc())
            secs = 15
        import time

        time.sleep(secs)


def build_job_from_pedido(pedido: dict, config: dict) -> dict:
    """Arma 2 copias con el formateador del host (espejo de ticket-format.js)."""
    width = int(config.get("paperWidthMm") or 80)
    msgs = []
    # Preferir el mensaje WA completo (mismo ID) si vino en la cola remota
    raw_msg = str(pedido.get("messageText") or "").strip()
    if raw_msg and "PEDIDO CARNELANDIA" in raw_msg.upper():
        # Cuerpo tras el encabezado de protocolo WEB_V1
        body = raw_msg
        marker = "CARNELANDIA_PEDIDO_WEB_V1"
        if marker in body:
            parts = body.split("\n\n", 1)
            body = parts[1] if len(parts) > 1 else body
        msgs.append(body)
    else:
        if pedido.get("customerName"):
            msgs.append(f"Nombre: {pedido['customerName']}")
        if pedido.get("address"):
            msgs.append(f"Dirección: {pedido['address']}")
        if pedido.get("items"):
            msgs.append("\n".join(pedido["items"]))
        if pedido.get("notes"):
            msgs.append(f"Aclaración: {pedido['notes']}")
        msgs.append(f"Pedido: {pedido['orderId']}")

    # Nº legible: últimos 4 dígitos del UUID si existen; si no, 0001
    import re

    digits = re.sub(r"\D", "", pedido["orderId"])
    ticket = digits[-4:].rjust(4, "0") if digits else "0001"

    return host.build_print_job_from_messages(
        messages=[{"id": str(i), "text": t} for i, t in enumerate(msgs)],
        ticket_number=ticket,
        paper_width_mm=width,
        contact_name=pedido.get("customerName") or "",
        order_id=pedido["orderId"],
    )


def try_print_pedido(pedido: dict) -> dict:
    config = host.load_config()
    with _lock:
        if _state["printing"]:
            return {
                "ok": False,
                "outcome": "busy",
                "message": "Impresion en curso; pedido queda pendiente",
            }
        oid = pedido["orderId"]
        if oid in _state["printed"]:
            return {
                "ok": True,
                "outcome": "duplicate",
                "message": "Pedido ya registrado como enviado a cola",
            }
        _state["printing"] = True
    try:
        job = build_job_from_pedido(pedido, config)
        printer = host.safe_printer_name(config.get("printerName"))
        if not printer:
            with _lock:
                _state["pending"][pedido["orderId"]] = pedido
            save_state()
            return {
                "ok": False,
                "outcome": "pending",
                "code": "printer_unavailable",
                "message": "Sin impresora configurada; pedido en pendientes",
            }
        # Print via host handle_print shape
        msg = {
            "action": "print",
            "demoMode": False,
            "printerName": printer,
            "paperWidthMm": job.get("paperWidthMm") or 80,
            "ticketNumber": job.get("ticketNumber"),
            "orderId": pedido["orderId"],
            "copies": job["copies"],
            "windowsPrintMethod": config.get("windowsPrintMethod") or "auto",
            "cutBetweenCopies": True,
        }
        result = host.handle_print(msg, config)
        if result.get("ok") and result.get("outcome") == "queued":
            with _lock:
                _state["printed"][pedido["orderId"]] = {
                    "at": datetime.now().isoformat(),
                    "outcome": "queued",
                }
                _state["pending"].pop(pedido["orderId"], None)
                _state["uncertain"].pop(pedido["orderId"], None)
            save_state()
            return {
                "ok": True,
                "outcome": "queued",
                "message": result.get("message"),
                "note": "queued != confirmacion fisica de papel",
            }
        if result.get("ok") is False and result.get("code") in (
            "error",
            "printer_unavailable",
        ):
            # fallo claro
            with _lock:
                _state["pending"][pedido["orderId"]] = {
                    **pedido,
                    "lastError": result.get("message"),
                }
            save_state()
            return {
                "ok": False,
                "outcome": "pending",
                "message": result.get("message"),
                "code": result.get("code"),
            }
        # resultado ambiguo
        with _lock:
            _state["uncertain"][pedido["orderId"]] = {
                "at": datetime.now().isoformat(),
                "reason": result.get("message") or "resultado incierto",
                "pedido": pedido,
            }
            _state["pending"][pedido["orderId"]] = pedido
        save_state()
        return {
            "ok": False,
            "outcome": "uncertain",
            "message": "Resultado incierto: revisar manualmente. No se reintenta en automatico.",
            "detail": result,
        }
    except Exception as e:
        agent_log(traceback.format_exc())
        with _lock:
            _state["uncertain"][pedido["orderId"]] = {
                "at": datetime.now().isoformat(),
                "reason": str(e),
                "pedido": pedido,
            }
            _state["pending"][pedido["orderId"]] = pedido
        save_state()
        return {
            "ok": False,
            "outcome": "uncertain",
            "message": f"Excepcion al imprimir: {e}",
        }
    finally:
        with _lock:
            _state["printing"] = False


class Handler(BaseHTTPRequestHandler):
    server_version = "CarnelandiaAgent/1.4"

    def log_message(self, fmt: str, *args) -> None:
        agent_log("http " + (fmt % args))

    def _auth_ok(self) -> bool:
        expected = ensure_token()
        got = self.headers.get("X-Carnelandia-Token") or ""
        # Token opcional si el cliente no lo envia? Mejor exigir para Pedidos;
        # extension puede leer el token via NM. Por simplicidad local: aceptar
        # sin token SOLO desde 127.0.0.1 (ya restringido).
        if not got:
            return True
        return got.strip() == expected

    def _send(self, code: int, obj: dict) -> None:
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Carnelandia-Token")
        self.end_headers()
        self.wfile.write(data)

    def do_OPTIONS(self) -> None:
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Carnelandia-Token")
        self.end_headers()

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        if path == "/v1/health":
            self._send(
                200,
                {
                    "ok": True,
                    "service": "carnelandia-agent",
                    "version": host.HOST_VERSION,
                    "protocolVersion": host.PROTOCOL_VERSION,
                },
            )
            return
        if path == "/v1/status":
            rc = load_remote_config()
            with _lock:
                st = {
                    "ok": True,
                    "autoPrintEnabled": _state["autoPrintEnabled"],
                    "printing": _state["printing"],
                    "pendingCount": len(_state["pending"]),
                    "printedCount": len(_state["printed"]),
                    "uncertainCount": len(_state["uncertain"]),
                    "pending": list(_state["pending"].keys()),
                    "uncertain": list(_state["uncertain"].keys()),
                    "remoteQueue": {
                        "enabled": rc.get("enabled"),
                        "url": rc.get("url"),
                        "hasToken": bool(rc.get("token")),
                        "lastPull": _state.get("remoteLastPull"),
                        "lastError": _state.get("remoteLastError"),
                    },
                }
            self._send(200, st)
            return
        self._send(404, {"ok": False, "message": "not found"})

    def do_POST(self) -> None:
        if not self._auth_ok():
            self._send(401, {"ok": False, "message": "token invalido"})
            return
        length = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(length) if length else b"{}"
        try:
            body = json.loads(raw.decode("utf-8"))
        except Exception:
            self._send(400, {"ok": False, "message": "JSON invalido"})
            return

        path = urlparse(self.path).path
        if path == "/v1/auto":
            enabled = bool(body.get("enabled"))
            with _lock:
                _state["autoPrintEnabled"] = enabled
            save_state()
            agent_log(f"autoPrintEnabled={enabled}")
            self._send(200, {"ok": True, "autoPrintEnabled": enabled})
            return

        if path == "/v1/orders":
            pedido = pedido_from_body(body)
            if not pedido:
                self._send(
                    400,
                    {
                        "ok": False,
                        "message": "Pedido invalido: requiere schema carnelandia.pedido.v1 y orderId CP-...",
                    },
                )
                return
            with _lock:
                if pedido["orderId"] in _state["printed"]:
                    self._send(
                        200,
                        {
                            "ok": True,
                            "outcome": "duplicate",
                            "orderId": pedido["orderId"],
                        },
                    )
                    return
                auto = _state["autoPrintEnabled"]
            if not auto:
                with _lock:
                    _state["pending"][pedido["orderId"]] = pedido
                save_state()
                self._send(
                    200,
                    {
                        "ok": True,
                        "outcome": "pending",
                        "message": "Autoimpresion desactivada; pedido guardado pendiente",
                        "orderId": pedido["orderId"],
                    },
                )
                return
            result = try_print_pedido(pedido)
            result["orderId"] = pedido["orderId"]
            self._send(200 if result.get("ok") or result.get("outcome") == "pending" else 500, result)
            return

        if path == "/v1/print-pending":
            # Imprime pendientes uno a uno solo si auto ON y no fuerza rafaga historica
            # salvo request explicita flush=true
            flush = bool(body.get("flush"))
            if not flush:
                self._send(
                    400,
                    {
                        "ok": False,
                        "message": "Requiere flush=true para no vaciar historicos por accidente",
                    },
                )
                return
            with _lock:
                ids = list(_state["pending"].keys())
            results = []
            for oid in ids:
                with _lock:
                    ped = _state["pending"].get(oid)
                if ped:
                    results.append(try_print_pedido(ped))
            self._send(200, {"ok": True, "results": results})
            return

        self._send(404, {"ok": False, "message": "not found"})


def main() -> int:
    load_state()
    ensure_token()
    rc = load_remote_config()
    agent_log(
        f"agent start {HOST_ADDR}:{PORT} auto={_state['autoPrintEnabled']} "
        f"remote={rc.get('url')} token={'yes' if rc.get('token') else 'NO'}"
    )
    t = threading.Thread(target=remote_poll_loop, name="remote-pull", daemon=True)
    t.start()
    httpd = ThreadingHTTPServer((HOST_ADDR, PORT), Handler)
    print(f"Carnelandia agent http://{HOST_ADDR}:{PORT}", flush=True)
    print(
        f"Remote queue: {rc.get('url')} token={'configured' if rc.get('token') else 'MISSING'}",
        flush=True,
    )
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
