@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo Carnelandia Comandas - instalador (raiz)
echo.
where powershell >nul 2>&1
if errorlevel 1 (
  echo ERROR: No se encuentra powershell.exe
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0native-host\install_windows.ps1" %*
set PS_EXIT=%ERRORLEVEL%
if %PS_EXIT%==0 goto OK_DONE
echo.
echo LA INSTALACION FALLO - codigo %PS_EXIT%
pause
exit /b %PS_EXIT%
:OK_DONE
echo.
echo Instalacion finalizada. Ejecuta VALIDAR.bat antes de usar Chrome.
pause
exit /b 0
