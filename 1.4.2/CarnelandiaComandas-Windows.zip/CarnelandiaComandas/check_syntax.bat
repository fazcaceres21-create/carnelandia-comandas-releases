@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0native-host\check_syntax.ps1"
set PS_EXIT=%ERRORLEVEL%
if %PS_EXIT%==0 goto OK_SYN
echo FALLO sintaxis.
pause
exit /b %PS_EXIT%
:OK_SYN
echo Sintaxis OK.
pause
exit /b 0
