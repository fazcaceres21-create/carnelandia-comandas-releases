@echo off
setlocal
cd /d "%~dp0"
call "%~dp0native-host\VALIDAR.bat" %*
